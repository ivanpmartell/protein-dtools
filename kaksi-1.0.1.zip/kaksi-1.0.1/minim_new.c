#include <stdio.h>
#include <math.h>

#include "minim_new.h"
#include "centroid.h"
#include "principal_axis.h"
#include "simul.h"
#include "m1qn3.h"

/******************************************************************************
 *
 ******************************************************************************/
/**
 * Find the best axis for the stretch of residues lim1:lim2
 * Last modification: 22/11/95
 * Try to get rid of the problem of local minima
 * 1) Add singular value decomposition to get a
 *    first estimate of the axis then
 * 2) minimize
 * 3) restart the minimization from the minimum foubd above to make
 *    sure that it's a local minimum.
 *
 * ==> C READY <==
 */
int minim_new_(int lim1, int lim2, double *cax, int natoms, double *dd,
    double *resmax, int *mode, double *pt1, double *pt2, int *ierr)
{
  int c__2 = 2;
  int c__100 = 100;
  int io = 6;
  int impres = 0;
  int izs[3];
  int niter_ini__ = 1000;
  int nsim_ini__ = 1200;
  int iperso = 0;
  int i__1;
  int nsim;
  int k, ifail;
  int niter;
  int kz, diff;
  int mid, iat;
  double dxmin = 1e-6;
  double df1 = 100.;
  double epsg_ini__ = 1e-6;
  double pi = 3.14159265358979;
  double d__1;
  double grad[2];
  double epsg;
  double vnew[3], work[100];
  double scal1, scal2;
  double theta;
  double s1, v1[3], v2[3], fc, cg[3], gp, dx, fckeep, dy, dz;
  double vv[3];
  double rskeep, cg1[3], cg2[3];
  double phi, var[2], dzs[3], tmp;
  double varkeep[2], rzs[6000];

/* Minimization control parameters */

/* logical number of the output file */
/* level of impression */
/* absolute precision for the variables */
/* max expected decreasing of the function */
/* relative precision for the gradient */
/* number of iterations */
/* number of calls to simul (function and/or g */

/* number of special iterations */
/* Calculate the centroid of the current segment */

  diff = lim2 - lim1 + 1;

  centroid_(lim1, lim2, cax, cg);

/* First guess for the axis */

  if (diff == 1) {
    *ierr = 4;
    return 0;
  } else if (diff == 2) {
    *dd = 0.0;
    *resmax = 0.0;
    for (k = 0; k < 3; k++) {
      pt1[k] = cax[k + lim1 * 3];
      pt2[k] = cax[k + lim2 * 3];
    }
    *mode = 0;
    return 0;
  } else if (diff == 3) {
    for (k = 0; k < 3; k++) {
      vv[k] = (cax[k + lim2 * 3] - cax[k + lim1 * 3]) * 0.5;
    }
    vector_norm_(vv);
  } else {
    ifail = 0;
    principal_axis_(lim1, lim2, cax, vv, &ifail);

/* If the singular value decomposition failed use as initial vector the line */
/* joining the centroids of the two halves of the SSE */

    if (ifail != 0) {
      mid = diff / 2 + lim1 - 1;
      centroid_(lim1, mid, cax, cg1);
      i__1 = mid + 1;
      centroid_(i__1, lim2, cax, cg2);
      for (k = 0; k < 3; k++) {
        vv[k] = cg2[k] - cg1[k];
      }
      vector_norm_(vv);
    }
  }

  if (vv[2] > 1.0) {
    vv[2] = 1.0;
  }
  if (vv[2] < -1.0) {
    vv[2] = -1.0;
  }

  phi = acos(vv[2]);
  s1 = sin(phi);
  if (fabs(s1) > 1e-6) {
    tmp = vv[0] / s1;
    if (tmp > 1.0) {
      tmp = 1.0;
    }
    if (tmp < -1.0) {
      tmp = -1.0;
    }
    theta = acos(tmp);
    if (vv[1] < 0.0) {
      theta = -theta;
    }
  } else {
    theta = 0.0;
  }
  var[0] = theta;
  var[1] = phi;

/* Find the best axis for the segment considered. This best axis is defined as the axis */
/* minimizing the following function: D = 1/n Sum{(di-<d>)*(di-<d>)} where n is the number */
/* of Ca's, the summation is taken over n, di is the distance of the ith Ca to the axis */
/* and <d> is the average value of these distances, i.e., <d> = 1/n Sum{di}. */
/* Note that there are only 2 variables, phi and psi since the axis has to go through the */
/* previously defined centroid. */

  func_(lim1, lim2, cax, cg, var, &fc, resmax);

  df1 = fc;

/* The function is expected to decrease to zero ideally */
  gradient_(lim1, lim2, cax, cg, var, grad);

  niter = niter_ini__;
  nsim = nsim_ini__;
  epsg = epsg_ini__;
  izs[0] = lim1;
  izs[1] = lim2;
  izs[2] = natoms;

  for (iat = 0; iat < natoms; iat++) {
    for (k = 0; k < 3; k++) {
      rzs[iat * 3 + k] = cax[k + iat * 3];
    }
  }

  for (k = 0; k < 3; k++) {
    dzs[k] = cg[k];
  }

  m1qn3_(simul_, prosca_, &c__2, var, &fc, grad, &dxmin, &df1, &epsg, &impres,
      &io, mode, &niter, &nsim, &iperso, work, &c__100, izs, rzs, dzs);

/* Theta = var(0) is always expressed between -pi and pi and */
/* Phi   = var(1) between 0 and pi. */

  d__1 = pi * 2.0;
  var[0] = d_mod(var[0], d__1);
  d__1 = pi * 2.0;
  var[1] = d_mod(var[1], d__1);
  if (var[0] > pi) {
    var[0] -= pi * 2.0;
  }

/* Restart the minimization from the minimum point found so far in order */
/* to avoid, as far as possible, the problem of local minima. */

  func_(lim1, lim2, cax, cg, var, &fc, resmax);

/* Keep the variables of the first minimum found and the value of the */
/* function at this point. */

  for (k = 0; k < 2; k++) {
    varkeep[k] = var[k];
  }
  fckeep = fc;
  rskeep = *resmax;

  df1 = fc;

/* The function is expected to decrease to zero ideally */
  gradient_(lim1, lim2, cax, cg, var, grad);

  niter = niter_ini__;
  nsim = nsim_ini__;
  epsg = epsg_ini__;
  izs[0] = lim1;
  izs[1] = lim2;
  izs[2] = natoms;

  for (iat = 0; iat < natoms; iat++) {
    for (k = 0; k < 3; k++) {
      rzs[iat * 3 + k] = cax[k + iat * 3];
    }
  }

  for (k = 0; k < 3; k++) {
    dzs[k] = cg[k];
  }

  m1qn3_(simul_, prosca_, &c__2, var, &fc, grad, &dxmin, &df1, &epsg, &impres,
      &io, mode, &niter, &nsim, &iperso, work, &c__100, izs, rzs, dzs);

/* Theta   = var(0) is always expressed between -pi and pi */
/* and phi = var(1) between 0 and pi. */

  d__1 = pi * 2.0;
  var[0] = d_mod(var[0], d__1);
  d__1 = pi * 2.0;
  var[1] = d_mod(var[1], d__1);
  if (var[0] > pi) {
    var[0] -= pi * 2.0;
  }

  func_(lim1, lim2, cax, cg, var, dd, resmax);

/* If a second lower minimum has been found this can be due to the fact that */
/* the SSE is short and that, strictly speaking, there is no principal axis. */
/* This is typically the case for 6 residue helices for which several more or */
/* less orthogonal axes can be fit through the structure. In the following the */
/* axis that is the most parallel to the N-term C-term vector is used. */

  if ((d__1 = (*dd - fckeep) / *dd, fabs(d__1)) > 0.001) {
    mid = diff / 2 + lim1 - 1;
    centroid_(lim1, mid, cax, cg1);
    i__1 = mid + 1;
    centroid_(i__1, lim2, cax, cg2);
    for (k = 0; k < 3; k++) {
      vv[k] = cg2[k] - cg1[k];
    }
    vector_norm_(vv);

    v1[0] = cos(varkeep[0]) * sin(varkeep[1]);
    v1[1] = sin(varkeep[0]) * sin(varkeep[1]);
    v1[2] = cos(varkeep[1]);
    vector_norm_(v1);

    v2[0] = cos(var[0]) * sin(var[1]);
    v2[1] = sin(var[0]) * sin(var[1]);
    v2[2] = cos(var[1]);
    vector_norm_(v2);

    scal1 = (d__1 = vv[0] * v1[0] + vv[1] * v1[1] + vv[2] * v1[2], fabs(d__1));
    scal2 = (d__1 = vv[0] * v2[0] + vv[1] * v2[1] + vv[2] * v2[2], fabs(d__1));

    if (scal1 > scal2) {
      vnew[0] = cos(varkeep[0]) * sin(varkeep[1]);
      vnew[1] = sin(varkeep[0]) * sin(varkeep[1]);
      vnew[2] = cos(varkeep[1]);
      *dd = fckeep;
      *resmax = rskeep;
    } else {
      vnew[0] = cos(var[0]) * sin(var[1]);
      vnew[1] = sin(var[0]) * sin(var[1]);
      vnew[2] = cos(var[1]);
    }

  } else {
    vnew[0] = cos(var[0]) * sin(var[1]);
    vnew[1] = sin(var[0]) * sin(var[1]);
    vnew[2] = cos(var[1]);
  }

/* The axis is bounded by two points, the projection of the first Ca onto the axis */
/* and the projection of the last Ca onto the axis. */

  dx = cax[lim1 * 3 + 0] - cg[0];
  dy = cax[lim1 * 3 + 1] - cg[1];
  dz = cax[lim1 * 3 + 2] - cg[2];
  gp = dx * vnew[0] + dy * vnew[1] + dz * vnew[2];
  for (kz = 0; kz < 3; ++kz) {
    pt1[kz] = cg[kz] + gp * vnew[kz];
  }
  dx = cax[lim2 * 3 + 0] - cg[0];
  dy = cax[lim2 * 3 + 1] - cg[1];
  dz = cax[lim2 * 3 + 2] - cg[2];
  gp = dx * vnew[0] + dy * vnew[1] + dz * vnew[2];
  for (kz = 0; kz < 3; ++kz) {
    pt2[kz] = cg[kz] + gp * vnew[kz];
  }

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/*
 * ==> C READY <==
 */
double d_mod(double x, double y)
{
  double quotient;

  quotient = x / y;
  if (quotient >= 0) {
    quotient = floor(quotient);
  } else {
    quotient = -floor(-quotient);
  }

  return (x - y * quotient);
}
