/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "kaksi.h"
#include "parse_PDB_file.h"
#include "read_PDB_file.h"
#include "process_SEQRES_record.h"
#include "process_ATOM_record.h"
#include "compare_SEQRES_ATOM.h"
#include "transfer_data.h"
#include "process_SSE_record.h"
#include "compute_phi_psi.h"
#include "extract_CA.h"
#include "assign_sse.h"
#include "curvature.h"
#include "util.h"
#include "output.h"

#define VERSION "1.0.1"

/*******************************************************************************
 * TODO
 *
 * - Check beta neighbors (more than 2 neighbors should never arise).
 * - Option to print to output to file?
 */

/*******************************************************************************
 * LOCAL FUNCTIONS
 ******************************************************************************/
static void locate_data_matrices(kaksi_args_t *args);
static int is_readable(char *fname);
static void parse_command_line(int argc, char **argv, kaksi_args_t *args);
static void init_arguments(kaksi_args_t *args);
static void fprint_usage(FILE *fp, char **argv, kaksi_args_t *args);

/*******************************************************************************
 *
 ******************************************************************************/
int main (int argc, char *argv[])
{
  int i, ncS, nrS;
  int helixMat[36][36], strandMat[36][36];
  struct RecordTransfer *SEQRESrec = NULL, *ATOMrec = NULL;
  struct NODES heads;
  struct CHUNK *headchunk = NULL;
  struct MiscTransfer *MT = NULL;
  struct PHIPSI *PhiPsi = NULL;
  pdb_t *pdb = NULL, *pdb_tmp = NULL;
  struct SEQUENCE *sseSeq = NULL;
  struct SEQUENCE *strandOrient = NULL;
  char ***contact = NULL;
  double ***coo_CA = NULL;
  FILE *fp = NULL;
  kaksi_args_t args;
  ppf_args_t *pargs = NULL;

  pargs = &args.pargs;
  init_arguments(&args);
  parse_command_line(argc, argv, &args);
  locate_data_matrices(&args);
  set_pdb_file(pargs->pdb_fname, pargs->pdb_dir, pargs->pdb_code);

/*******************************************************************************
 * Parse PDB file (this should be the same code as in parse_PDB_file)
 */
  CALLOC(pdb, 1);
  CALLOC(MT, 1);
  CALLOC(SEQRESrec, 1);
  CALLOC(ATOMrec, 1);
  heads.headHelix = NULL;
  heads.headSheet = NULL;
  heads.headTurn = NULL;

  Read_PDB(pargs, pdb, &heads, &headchunk, SEQRESrec, ATOMrec, MT);
  process_SEQRES_record(headchunk, SEQRESrec, MT);
  process_ATOM_record(pdb, MT, SEQRESrec, ATOMrec);
  compare_SEQRES_ATOM(MT, pdb, SEQRESrec, ATOMrec);
  transfer_data(pdb, MT, SEQRESrec, ATOMrec);
  process_SSE_record(pdb, &heads, MT, SEQRESrec, ATOMrec, pargs);
  ALLOC(PhiPsi, pdb->Nchains);
  compute_phi_psi(pdb, PhiPsi);

  FREE(ATOMrec);
  FREE(SEQRESrec);
/*
 * End of parse PDB file
 ******************************************************************************/

  CALLOC(pdb->curvature, pdb->Nchains);
  ALLOC(sseSeq, pdb->Nchains);
  ALLOC(strandOrient, pdb->Nchains);
  CALLOC(contact, pdb->Nchains);

/*
 * Read data matrices
 */
  read_mat(helixMat, args.helix_mat_fname);
  read_mat(strandMat, args.strand_mat_fname);

/* --[ DS ]--
 * NOTE: this is a "dirty strategy" since the pdb structure is not
 *       good. Talk to me if you want to know why (A. Marin)
 *       The code should be as simple as:
 *
 *       curvature(&args, pdb);
 *       assign_sse(&pargs, &args, pdb);
 */
/* --[ DS ]--
 * Backup some original values of PDB structure
 */
/*
  printf("pdb->Nchains = %d, pdb->nat = %d, pdb->max_nrS = %d\n",
      pdb->Nchains, pdb->nat, pdb->max_nrS);
  fflush(stdout);
*/
  CALLOC(pdb_tmp, 1);

  if (pdb->max_nrS > pdb->nat) {
    pdb_tmp->nat = pdb->max_nrS;
  } else {
    pdb_tmp->nat = pdb->nat;
  }

  ALLOC2(pdb_tmp->coo, pdb_tmp->nat, 3);
  ALLOC2(pdb_tmp->resname, pdb_tmp->nat, 4);
  ALLOC(pdb_tmp->numres, pdb_tmp->nat);
  ALLOC3(coo_CA, pdb->Nchains, pdb->max_nrS, 3);

  memcpy(pdb_tmp->coo[0], pdb->coo[0], pdb->nat * 3 * sizeof(double));
  memcpy(pdb_tmp->resname[0], pdb->resname[0], 4 * pdb->nat * sizeof(char));
  memcpy(pdb_tmp->numres, pdb->numres, pdb->nat * sizeof(int));

  if (pdb->max_nrS > pdb->nat) {
    pdb->nat = pdb->max_nrS;

    FREE2(pdb->coo);
    ALLOC2(pdb->coo, pdb->nat, 3);
    FREE2(pdb->resname);
    ALLOC2(pdb->resname, pdb->nat, 4);
    FREE(pdb->numres);
    ALLOC(pdb->numres, pdb->nat);

    memcpy(pdb->coo[0], pdb_tmp->coo[0], pdb->nat * 3 * sizeof(double));
    memcpy(pdb->resname[0], pdb_tmp->resname[0], pdb->nat * 4 * sizeof(char));
    memcpy(pdb->numres, pdb_tmp->numres, pdb->nat * sizeof(int));
  }

/*
 * Calculate curvature and secondary structure for each chain
 */
  pdb->prot_Nchains = 0;
  for (ncS = 0; ncS < pdb->Nchains; ncS++) {
    if (pdb->status[ncS] != 0) {
      continue;
    }
    if (pargs->user_chain_id != '�'
        && pdb->chainNames[ncS] != pargs->user_chain_id) {
      continue;
    }
    pdb->prot_Nchains++;
    nrS = pdb->chain_nres[ncS];

  /* --[ DS ]--
   * Copy back original values in PDB structure
   */
    pdb->nat = pdb_tmp->nat;
    memcpy(pdb->coo[0], pdb_tmp->coo[0], pdb->nat * 3 * sizeof(double));
    memcpy(pdb->resname[0], pdb_tmp->resname[0], 4 * pdb->nat * sizeof(char));
    memcpy(pdb->numres, pdb_tmp->numres, pdb->nat * sizeof(int));

  /* --[ DS ]--
   * Extract CA for the current chain
   */
    extract_CA(pdb, coo_CA[ncS], ncS);

  /* --[ DS ]--
   * Copy the right things in PDB structure
   */
    for (i = 0; i < nrS; i++) {
      pdb->coo[i][0] = coo_CA[ncS][i][0];
      pdb->coo[i][1] = coo_CA[ncS][i][1];
      pdb->coo[i][2] = coo_CA[ncS][i][2];
      strcpy(pdb->resname[i], aa1_to_aa3(pdb->seq[ncS][i]));
      pdb->numres[i] = pdb->SEQRESnumres[ncS][i];
    }
    pdb->nat = i;

  /*
   * Calculate the curvature
   */
    curvature(&args, pdb, ncS);

  /*
   * assign secondary structure.
   */
    sseSeq[ncS].length = nrS;
    ALLOC(sseSeq[ncS].seq, nrS + 1);
    for (i = 0; i < nrS; i++) {
      sseSeq[ncS].seq[i] = 'X';
    }
    sseSeq[ncS].seq[i] = '\0';
    ALLOC(strandOrient[ncS].seq, nrS);
    strandOrient[ncS].length = nrS;
    for (i = 0; i < nrS; i++) {
      strandOrient[ncS].seq[i] = 'X';
    }
    ALLOC2(contact[ncS], nrS, nrS);
/*
    printf("ncS = %d, nrS = %d\n", ncS, nrS);
    fflush(stdout);
*/
    Assign_SSE(&PhiPsi[ncS], helixMat, strandMat, &sseSeq[ncS],
        &strandOrient[ncS], contact[ncS], pargs, &args, coo_CA[ncS], nrS);
  }

  if (pdb->prot_Nchains == 0) {
    ERROR_TAG;
    fprintf(stderr, "Error: Unable to find chain '%c' in PDB file whose "
        "chains are: ", pargs->user_chain_id);
    for (i = 0; i < pdb->Nchains; i++) {
      fprintf(stderr, "'%c' ", pdb->chainNames[i]);
    }
    exit(1);
  }

/*
 * Output
 */
  if (strcmp(args.output_fname, "stdout") == 0) {
    fp = stdout;
  } else {
    FOPEN(fp, args.output_fname, "w");
  }
  fprint_results(fp, &args, pdb, PhiPsi, coo_CA, sseSeq, contact);
  if (fp != stdout) {
    FCLOSE(fp);
  }

  exit(0);
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Locate data matrices
 *
 * Priority:
 * - local directory
 * - environment variables STRANDMAT and HELIXMAT
 * - home/.kaksi directory
 * - system = /usr/share/kaksi
 */
static void locate_data_matrices(kaksi_args_t *args)
{
  char *fp = NULL;
  int a_flag = 0, b_flag = 0;

/*
 * STRAND MATRIX
 */
  if (args->strand_mat_fname[0] == '\0') {
  /* local directory */
    strcpy(args->strand_mat_fname, "StrandMat.data");
    if (is_readable(args->strand_mat_fname) == 0) {
      b_flag = 1;
    } else {

    /* environment variables */
      fp = getenv("STRANDMAT");
      if (fp != NULL) {
        strcpy(args->strand_mat_fname, fp);
      }
      if (args->strand_mat_fname[0] != '\0'
          && is_readable(args->strand_mat_fname) == 0) {
        b_flag = 1;
      } else {

      /* home directory */
        fp = getenv("HOME");
        if (fp != NULL) {
          sprintf(args->strand_mat_fname, "%s/.kaksi/StrandMat.data", fp);
        }
        if (args->strand_mat_fname[0] != '\0'
            && is_readable(args->strand_mat_fname) == 0) {
          b_flag = 1;
        } else {

        /* system directory */
          strcpy(args->strand_mat_fname, "/usr/share/kaksi/StrandMat.data");
          if (args->strand_mat_fname[0] != '\0'
              && is_readable(args->strand_mat_fname) == 0) {
            b_flag = 1;
          }
        }
      }
    }
  } else {
    if (is_readable(args->strand_mat_fname) == 0) {
      b_flag = 1;
    }
  }

/*
 * HELIX MATRIX
 */
  if (args->helix_mat_fname[0] == '\0') {
  /* local directory */
    strcpy(args->helix_mat_fname, "HelixMat.data");
    if (args->helix_mat_fname[0] != '\0'
        && is_readable(args->helix_mat_fname) == 0) {
      a_flag = 1;
    } else {

    /* environment variables */
      fp = getenv("HELIXMAT");
      if (fp != NULL) {
        strcpy(args->helix_mat_fname, fp);
      }
      if (args->helix_mat_fname[0] != '\0'
          && is_readable(args->helix_mat_fname) == 0) {
        a_flag = 1;
      } else {

      /* home directory */
        fp = getenv("HOME");
        if (fp != NULL) {
          sprintf(args->helix_mat_fname, "%s/.kaksi/HelixMat.data", fp);
        }
        if (args->helix_mat_fname[0] != '\0'
            && is_readable(args->helix_mat_fname) == 0) {
          a_flag = 1;
        } else {

        /* system directory */
          strcpy(args->helix_mat_fname, "/usr/share/kaksi/HelixMat.data");
          if (args->helix_mat_fname[0] != '\0'
              && is_readable(args->helix_mat_fname) == 0) {
            a_flag = 1;
          }
        }
      }
    }
  } else {
    if (is_readable(args->helix_mat_fname) == 0) {
      a_flag = 1;
    }
  }

  if (a_flag == 0 || b_flag == 0) {
    Erreur(1, "Error: Impossible to find kaksi parameter files "
        "(StrandMat.data and HelixMat.data)\nOne of the following locations "
        "is REQUIRED:\n"
        "- command line (options -hdm for helix data matrix and -sdm for strand)\n"
        "- local directory (the directory you're running the program)\n"
        "- environment variables (STRANDMAT and HELIXMAT)\n"
        "- home directory (%s/.kaksi)\n"
        "- system directory (/usr/share/kaksi)\n", getenv("HOME"));
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static int is_readable(char *fname)
{
  FILE *fp;

  if ((fp = fopen(fname, "r")) == NULL) {
    return 1;
  }
  fclose(fp);
  return 0;
}

/*******************************************************************************
 *
 ******************************************************************************/
static void parse_command_line(int argc, char **argv, kaksi_args_t *args)
{
  int i;
  ppf_args_t *pargs;

  if (argc == 1) {
    fprint_usage(stderr, argv, args);
    exit (1);
  }

  pargs = &args->pargs;
  for (i = 1; i < argc; i++) {
    if (strcmp (argv[i], "-adt") == 0) {
      i++;
      args->alpha_dist_thresh = atof(argv[i]);	
    } else if (strcmp (argv[i], "-bat") == 0) {
      i++;
      args->beta_angle_thresh = atof(argv[i]);	
    } else if (strcmp (argv[i], "-bdt") == 0) {
      i++;
      args->beta_dist_thresh = atof(argv[i]);		
    } else if (strcmp(argv[i], "-c") == 0) {
      i++;
      pargs->user_chain_id = argv[i][0];
      if (pargs->user_chain_id == '�') {
        ERROR_TAG;
        Erreur(1, "Error: Your chain name (%c) corresponds to the "
            "sentinel value in the program.\nChange the sentinel value "
            "in the program and recompile it\n", pargs->user_chain_id);
      }
    } else if (strcmp(argv[i], "-h") == 0
        || strcmp(argv[i], "--help") == 0) {
      fprint_usage(stdout, argv, args);
      exit(0);
    } else if (strcmp(argv[i], "-hdm") == 0) {
      i++;
      strcpy(args->helix_mat_fname, argv[i]);
    } else if (strcmp (argv[i], "-lb") == 0) {
      i++;
      pargs->length_b = atoi(argv[i]);
    } else if (strcmp (argv[i], "-lH") == 0) {
      i++;
      pargs->length_H = atoi(argv[i]);
    } else if (strcmp (argv[i], "-mode") == 0) {
      i++;
      args->modecorrec = atoi(argv[i]);
    } else if (strcmp(argv[i], "-pc") == 0) {
      i++;
      strcpy(pargs->pdb_code, argv[i]);
    } else if (strcmp(argv[i], "-pf") == 0) {
      i++;
      strcpy(pargs->pdb_fname, argv[i]);
    } else if (strcmp(argv[i], "-ppc") == 0) {
      args->print_pdb_curv = 1;
    } else if (strcmp(argv[i], "-rem") == 0) {
      i++;
      pargs->remove_sse = atoi(argv[i]);
    } else if (strcmp(argv[i], "-sdm") == 0) {
      i++;
      strcpy(args->strand_mat_fname, argv[i]);
    } else if (strcmp(argv[i], "-sep") == 0) {
      i++;
      pargs->separate_sse = atoi(argv[i]);
    } else if (strcmp (argv[i], "-turn") == 0) {
      i++;
      pargs->turn = atoi(argv[i]);
    } else if (strcmp(argv[i], "-v") == 0
        || strcmp(argv[i], "--version") == 0) {
      printf("This is %s release number %s\n", basename(argv[0]), VERSION);
      exit(0);
    } else {
      printf("Unknown tag : %s\n", argv[i]);
      exit(1);
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void init_arguments(kaksi_args_t *args)
{
  init_ppf_arguments(&args->pargs);
  args->seq_name[0] = '\0';
  args->strand_mat_fname[0] = '\0';
  args->helix_mat_fname[0] = '\0';
  strcpy(args->output_fname, "stdout");
  args->modecorrec = 3;
  args->print_pdb_curv = 0;
  args->beta_dist_thresh = 2.58;
  args->alpha_dist_thresh = 1.96;
  args->beta_angle_thresh = 5;
}

/*******************************************************************************
 *
 ******************************************************************************/
static void fprint_usage(FILE *fp, char **argv, kaksi_args_t *args)
{
  ppf_args_t *pargs;

  pargs = &args->pargs;
  fprintf(fp, "\nUsage: %s [options] {-pc pdb_code, -pf pdb_file}\n\n",
      basename(argv[0]));
  fprintf(fp, "pdb_code          : PDB code for the PDB file to be processed.\n");
  fprintf(fp, "pdb_file          : name of the PDB file (if not specified, "
      "it must be found in dir: %s).\n\n", pargs->pdb_dir);
  fprintf(fp, " Options:\n\n");
  fprintf(fp, "  -adt num        : alpha distances threshold.\n"
              "                    [default: %.2f]\n", args->alpha_dist_thresh);
  fprintf(fp, "  -bat num        : beta angles threshold.\n"
              "                    [default: %.2f]\n", args->beta_angle_thresh);
  fprintf(fp, "  -bdt num        : beta distances threshold.\n"
              "                    [default: %.2f]\n", args->beta_dist_thresh);
  fprintf(fp, "  -h, --help      : print this help\n");
  fprintf(fp, "  -hdm file       : alpha helix data matrix file.\n"
              "                    [default: %s]\n", args->helix_mat_fname);
  fprintf(fp, "  -lb length      : minimum length for beta strands.\n"
              "                    [default: %d]\n", pargs->length_b);
  fprintf(fp, "  -lH length      : minimum length for alpha helices.\n"
              "                    [default: %d]\n", pargs->length_H);
  fprintf(fp, "  -mode num       : alpha helix correction "
      "(0: none, 1: distance only, 2: axis only, 3: both.\n"
              "                    [default: %d]\n", args->modecorrec);
  fprintf(fp, "  -ppc            : print curvature in a PDB-like file\n");
  fprintf(fp, "  -rem bool       : 1 or 0. If 1, remove SSEs with length "
      "inferior to minimum lengths.\n"
              "                    [default: %d]\n", pargs->remove_sse);
  fprintf(fp, "  -sdm file       : beta strand data matrix file.\n"
              "                    [default: %s]\n", args->strand_mat_fname);
  fprintf(fp, "  -sep bool       : 1 or 0. If 1, contiguous SSEs "
      "are separated by a coil (in the longest one).\n"
              "                    [default: %d]\n", pargs->separate_sse);
  fprintf(fp, "  -turn bool      : if 1, turns are also described.\n"
              "                    [default: %d]\n", pargs->turn);
  fprintf(fp, "  -v, --version   : print the program release number\n\n");
}
