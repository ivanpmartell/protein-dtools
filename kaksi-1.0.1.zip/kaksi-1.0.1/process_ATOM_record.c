/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

/*******************************************************************************
 * LOCAL DATA STRUCTURES
 ******************************************************************************/
typedef struct altloc_s {
  int NaltLocs;     /**< number of alternate locations */
  char altLoc[10];  /**< name of the alternate locations */
  int Natoms[10];   /**< number of atoms in alternate locations */
} altloc_t;

/*******************************************************************************
 * LOCAL FUNCTIONS
 ******************************************************************************/
static int modified_residue(pdb_t *pdb, int pos);
static void check_chain_order(int Nchains, char *chain_name, int Nchain1,
    char *chainName1, int *chain_nres1, int *nucleic, int *hetatmInSeqres,
    char **seq1);
static void check_alternate_locations(int Nchains, char *chain_name,
    pdb_t *pdb);
static int get_chain_number(char chainId, char *chainNames, int Nchains);
static void check_hetatm(pdb_t *pdb, int *validATOMchains);

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Process the sequences found in ATOM records
 * Note: the values in ATOMrec->chain_nres are wrong
 * if alternate locations exists for CA atoms.
 */
void process_ATOM_record(pdb_t *pdb, struct MiscTransfer *MT,
    struct RecordTransfer *SEQRESrec, struct RecordTransfer *ATOMrec)
{
  char prevchainId;
  int i, iat, nrA, unk;
/*
 * two distinct index : nc_Seqres for array of size SEQRES->Nchain
 * (ie MT->hetatmInSeqres) and nc for array of ATOM->Nchain size (ie others)
 */
  int ncA, ncS;
  char restype;

  check_hetatm(pdb, MT->validATOMchains);

/*
 * Determine the name and number of residues 
 * for each chain according to ATOM records.
 */
  nrA = 0;
  prevchainId = pdb->chainID[0];
  ATOMrec->chainName[0] = pdb->chainID[0];
  for (iat = 0, ncA = 0; iat < pdb->nat; iat++) {
    if (prevchainId != pdb->chainID[iat]) {
      ATOMrec->chain_nres[ncA] = nrA;
      nrA = 0;
      ncA++;
      ATOMrec->chainName[ncA] = pdb->chainID[iat];
    }
    if (strcmp(pdb->atomname[iat], " CA ") == 0) {
      nrA++;
    }
    prevchainId = pdb->chainID[iat];
  }
  ATOMrec->chain_nres[ncA] = nrA; /* Process last chain */

/*
 * Check the consistency of SEQRES and ATOM records.
 * If required reorder arrays corresponding to SEQRES
 * data, i.e., SEQRESrec->chainName, SEQRESrec->chain_nres, 
 * MT->hetatmInSeqres, MT->nucleic and SEQRESrec->seq
 */
  check_chain_order(ATOMrec->Nchain, ATOMrec->chainName, SEQRESrec->Nchain,
      SEQRESrec->chainName, SEQRESrec->chain_nres, MT->nucleic,
      MT->hetatmInSeqres, SEQRESrec->seq);

/*
 * Check alternate locations
 */
  ALLOC(pdb->selectedAltLoc, ATOMrec->Nchain);
  check_alternate_locations(ATOMrec->Nchain, ATOMrec->chainName, pdb);

/*
 * Extract the sequence from ATOM records
 * Recalculate ATOMrec->chain_nres.
 * Important note: the number of residues
 * calculated previously is only indicative,
 * if there are AltLoc there will be more
 * residues than there is in reality. On
 * the contrary if there are non standard
 * residues there will be less residues
 * than it should be. The exact number
 * is calculated below. For array allocation
 * we take an arbitrary 20% margin except
 * for chains having less than 10 residues
 * where we double the size. Therefore
 * we have to check for a (not very likely)
 * array overflow in the code below.
 */
  ALLOC(ATOMrec->seq, ATOMrec->Nchain);
  ALLOC(MT->numres, ATOMrec->Nchain);
  ALLOC(MT->iCode, ATOMrec->Nchain);
  for (i = 0; i < ATOMrec->Nchain; i++) {
    nrA = ATOMrec->chain_nres[i];
    if (nrA > 0) {
      ALLOC(ATOMrec->seq[i], nrA + 1);
      ALLOC(MT->numres[i], nrA);
      ALLOC(MT->iCode[i], nrA);
    } else {
      ATOMrec->seq[i] = NULL;
      MT->numres[i] = NULL;
      MT->iCode[i] = NULL;
    }
  }

  ncA = 0;
  ncS = 0;
  nrA = 0;
  prevchainId = pdb->chainID[0];
  for (iat = 0; iat < pdb->nat; iat++) {
    if (prevchainId != pdb->chainID[iat]) {
      if (nrA > 0) {
        ATOMrec->chain_nres[ncA] = nrA;
        ATOMrec->seq[ncA][nrA] = '\0';
      }
      if (nrA < MIN_PARSE_SSE_LEN) {
        MT->validATOMchains[ncA] = 0;
      }
      for (i = 0, unk = 0; i < nrA; i++) {
        if (ATOMrec->seq[ncA][i] == 'X') {
          unk++;
        }
      }
      if ((double) unk / (double) ATOMrec->chain_nres[ncA] > 0.5) {
        MT->validATOMchains[ncA] = 0;
      }
/*
      printf("ATOM   chain %2d '%c', nr = %5d, valid   = %d\n", ncA,
          prevchainId, nrA, MT->validATOMchains[ncA]);
      fflush(stdout);
*/
      if (MT->validATOMchains[ncA] == 1) {
        ncS++;
      }
      nrA = 0;
      ncA++;
    }

    /*
     * If the chain contains only standard residues (MT->hetatmInSeqres[nc_Seqres] == 0)
     * it is sufficient to look in ATOM records for Ca coordinates.
     * If the chain contains non standard residues HETATM records can appear
     * inside the ATOM records so HETATM records must be taken into account.
     * An additional check is performed to make sure that these heteroatoms
     * do correspond to a modified residue: backbone atoms N and C are searched
     * for in the neighborhood of the CA atom if a CA atom was found.
     */
    if (MT->validATOMchains[ncA] == 1) {
/*
      printf("%6s%5d %4s%c%3s %c%4d%c SaltLoc '%c'\n",
          pdb->atomtype[iat], pdb->numatom[iat],
          pdb->atomname[iat], pdb->altLoc[iat], pdb->resname[iat],
          pdb->chainID[iat], pdb->numres[iat], pdb->iCode[iat],
          pdb->selectedAltLoc[ncA]);
*/
      if (ncS < SEQRESrec->Nchain
          && MT->hetatmInSeqres[ncS] == 0
          && strncmp(pdb->atomtype[iat], "ATOM  ", 6) == 0
          && strncmp(pdb->atomname[iat], " CA ", 4) == 0
          && (pdb->altLoc[iat] == ' '
            || pdb->altLoc[iat] == pdb->selectedAltLoc[ncA])) {
/*
        printf("(+) ncA = %d, ncS = %d\n", ncA, ncS);
*/
        restype = residue_type(pdb->resname[iat]);
        if (restype != 'X') {
          ATOMrec->seq[ncA][nrA] = residue_type(pdb->resname[iat]);
          MT->numres[ncA][nrA] = pdb->numres[iat];
          MT->iCode[ncA][nrA] = pdb->iCode[iat];
          nrA++;
        }
      } else if (ncS < SEQRESrec->Nchain
          && MT->hetatmInSeqres[ncS] > 0
          && (strcmp(pdb->atomtype[iat], "ATOM  ") == 0
            || strcmp(pdb->atomtype[iat], "HETATM") == 0)
          && strcmp(pdb->atomname[iat], " CA ") == 0
          && (pdb->altLoc[iat] == ' '
            || pdb->altLoc[iat] == pdb->selectedAltLoc[ncA])) {
/*
        printf("(-) ncA = %d, ncS = %d\n", ncA, ncS);
*/
        restype = residue_type(pdb->resname[iat]);
        if (restype != 'X' || modified_residue(pdb, iat)) {
          ATOMrec->seq[ncA][nrA] = restype;
          MT->numres[ncA][nrA] = pdb->numres[iat];
          MT->iCode[ncA][nrA] = pdb->iCode[iat];
          nrA++;
        } else {
          fprintf(stderr, "process_ATOM_record : WARNING a CA atom that does "
              "not appear to belong to a modified residue has been found "
              "for chain '%c' at position %d\n", pdb->chainID[iat], nrA);
        }
      }
    }

    prevchainId = pdb->chainID[iat];

  } /* End of loop on atoms (iat) */

  if (nrA > 0) {
    ATOMrec->chain_nres[ncA] = nrA;
    ATOMrec->seq[ncA][nrA] = '\0';
  }
  if (nrA < MIN_PARSE_SSE_LEN) {
    MT->validATOMchains[ncA] = 0;
  }
  for (i = 0, unk = 0; i < nrA; i++) {
    if (ATOMrec->seq[ncA][i] == 'X') {
      unk++;
    }
  }
  if ((double) unk / (double) ATOMrec->chain_nres[ncA] > 0.5) {
    MT->validATOMchains[ncA] = 0;
  }
/*
  printf("ATOM   chain %2d '%c', nr = %5d, valid   = %d\n", ncA, prevchainId,
      nrA, MT->validATOMchains[ncA]);
  fflush(stdout);
*/
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Look for N and C atoms 
 */
static int modified_residue(pdb_t *pdb, int pos)
{
  int i;
  char resname[4];
  int found[2];

  strcpy(resname, pdb->resname[pos]);
  found[0] = found[1] = 0;

/*
 * Search towards the N-term direction
 */
  i = pos - 1;
  while (i >= 0 && strcmp(pdb->atomname[i], " N  ") != 0 &&
      strcmp(resname, pdb->resname[i]) == 0) {
    i--;
  }
  if (i >= 0) {
    if (strcmp(pdb->atomname[i], " N  ") == 0 &&
        strcmp(resname, pdb->resname[i]) == 0) {
      found[0] = 1;
    } else if (strcmp(pdb->atomname[i], " C  ") == 0 &&
        strcmp(resname, pdb->resname[i]) == 0) {
      found[1] = 1;
    }
  }

/*
 * do it twice in case of the both C and N are in the N-term Direction
 */
  while (i >= 0 && strcmp(pdb->atomname[i], " C  ") != 0 &&
      strcmp(resname, pdb->resname[i]) == 0) {
    i--;
  }
  if (i >= 0) {
    if (strcmp(pdb->atomname[i], " N  ") == 0 &&
        strcmp(resname, pdb->resname[i]) == 0) {
      found[0] = 1;
    } else if (strcmp(pdb->atomname[i], " C  ") == 0 &&
        strcmp(resname, pdb->resname[i]) == 0) {
      found[1] = 1;
    }
  }

/*
 * Search towards the C-term direction
 */
  i = pos + 1;
  while (i < pdb->nat && strcmp(pdb->atomname[i], " N  ") != 0) {
    i++;
  }
  if (i < pdb->nat) {
    if (strcmp(pdb->atomname[i], " N  ") == 0) {
      found[0] = 1;
    } else if (strcmp(pdb->atomname[i], " C  ") == 0) {
      found[1] = 1;
    }
  }

/*
 * do it twice in case of the both C and N are in the N-term Direction
 */
  i = pdb->nat - 1;
  while (i >= 0 && strcmp(pdb->atomname[i], " C  ") != 0) {
    i--;
  }
  if (i >= 0) {
    if (strcmp(pdb->atomname[i], " N  ") == 0) {
      found[0] = 1;
    } else if (strcmp(pdb->atomname[i], " C  ") == 0) {
      found[1] = 1;
    }
  }

  if (found[0] && found[1])
    return 1;

  return 0;
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * This function checks the consistency of SEQRES and ATOM records.
 *
 * At this point it has already been verified that the number of chains
 * in SEQRES and ATOM records is consistent (Nchains = number of chains
 * in ATOM records, can be greater than Nchain1 = the number of chain in
 * SEQRES records, by 1 ... see function check_hetatm for explanations).
 *
 * The name and order of the chains must be identical. If the order
 * is different, arrays corresponding to SEQRES records are reordered 
 * according to the order found in ATOM records.
 * Note: if the converse was done this would create problems later on
 * in the function extract_CA that expects ATOM records ordering.
 *
 * Arrays chainName1, chain_nres1, nucleic, hetatmInSeqres and seq1 are
 * susceptible to be reordered in this function.
 *
 */
static void check_chain_order(int Nchains, char *chain_name, int Nchain1,
    char *chainName1, int *chain_nres1, int *nucleic, int *hetatmInSeqres,
    char **seq1)
{
  int i, j, ii, found, reorder, nerr, maxres;
  int *indx = NULL;
  int *iswap1 = NULL, *iswap2 = NULL, *iswap3 = NULL;
  char *cswap1 = NULL, **cswap2 = NULL;

  ALLOC(indx, Nchain1);

/*
 * Check that all chains in SEQRES records are found in ATOM records
 * and fill ordering array indx.
 */
  nerr = 0;
  for (i = 0; i < Nchain1; i++) {
    found = 0;
    for (j = 0; j < Nchains; j++) {
      if (chainName1[i] == chain_name[j]) {
        found = 1;
        indx[i] = j;
        break;
      }
    }
    if (!found) {
      fprintf(stderr, "Chain '%c' in SEQRES records cannot be found in "
          "ATOM records\n", chainName1[i]);
      nerr++;
    }
  }
  if (nerr > 0) {
    ERROR_TAG;
    Erreur(1, "Error: %d chains above were not found!\n", nerr);
  }

/*
 * Check whether reordering needs to be performed
 */
  reorder = 0;
  for (i = 0; i < Nchain1; i++) {
    if (i != indx[i]) {
      reorder = 1;
      break;
    }
  }

  if (reorder) {
    /*
     * Calculate maximum size for arrays cswap2[i]
     */
    maxres = chain_nres1[0];
    for (i = 1; i < Nchain1; i++) {
      if (maxres < chain_nres1[i])
        maxres = chain_nres1[i];
    }
    /*
     * Allocate swap arrays
     */
    ALLOC(iswap1, Nchains);
    ALLOC(iswap2, Nchains);
    ALLOC(iswap3, Nchains);
    ALLOC(cswap1, Nchains);
    ALLOC2(cswap2, Nchains, maxres + 1);
    /*
     * iswap1 is used as a flag to indicate
     * positions in swap arrays that are not 
     * used when transfering data from old 
     * arrays to swap arrays.
     */
    for (i = 0; i < Nchains; i++) {
      iswap1[i] = -1;
    }
    /*
     * Move from old array to swap arrays
     */
    for (i = 0; i < Nchain1; i++) {
      ii = indx[i];
      iswap1[ii] = nucleic[i];
      iswap2[ii] = hetatmInSeqres[i];
      iswap3[ii] = chain_nres1[i];
      cswap1[ii] = chainName1[i];
      strcpy(cswap2[ii], seq1[i]);
      FREE(seq1[i]);
    }
    /*
     * ... and back to the old arrays
     */
    for (ii = 0, i = -1; ii < Nchains; ii++) {
      if (iswap1[ii] >= 0) {
        i++;
        nucleic[i] = iswap1[ii];
        hetatmInSeqres[i] = iswap2[ii];
        chain_nres1[i] = iswap3[ii];
        chainName1[i] = cswap1[ii];
        ALLOC(seq1[i], strlen(cswap2[ii]) + 1);
        strcpy(seq1[i], cswap2[ii]);
      }
    }
  }

/*
 * Free arrays no longer needed
 */
  FREE(indx);
  if (reorder) {
    FREE(iswap1);
    FREE(iswap2);
    FREE(iswap3);
    FREE(cswap1);
    FREE2(cswap2);
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Look for alternate location, i.e., atoms in the 3D structure
 * that have several possible conformations. These atoms are
 * tagged by the field altLoc in the ATOM record. There are as
 * many tags as different conformations. If this is not taken
 * into account the number of residues will appear artificially
 * larger than it is.
 *
 * The function returns selectedAltLoc that indicates for each chain which
 * alternate location is to be retained.
 */
static void check_alternate_locations(int Nchains, char *chain_name,
    pdb_t *pdb)
{
  int i, j, max_atoms, nc, found;
  altloc_t *al = NULL;

  CALLOC(al, Nchains);

/*
 * Count CA atoms and set the name for each alternate location
 */
  for (i = 0; i < pdb->nat; i++) {
    if (pdb->altLoc[i] != ' ') {
      nc = get_chain_number(pdb->chainID[i], chain_name, Nchains);
      found = 0;
      for (j = 0; j < al[nc].NaltLocs; j++) {
        if (al[nc].altLoc[j] == pdb->altLoc[i]) {
          found = 1;
          break;
        }
      }
      if (!found) {
        al[nc].NaltLocs++;
        if (al[nc].NaltLocs >= 10) {
          ERROR_TAG;
          Erreur(1, "Error: Increase the number of possible alternate "
              "locations in the data structure!\n");
        }
        al[nc].altLoc[al[nc].NaltLocs - 1] = pdb->altLoc[i];
        if (strcmp(pdb->atomname[i], " CA ") == 0) {
          al[nc].Natoms[al[nc].NaltLocs - 1]++;
        }
      } else {
        if (strcmp(pdb->atomname[i], " CA ") == 0) {
          al[nc].Natoms[j]++;
        }
      }
    }
  }

/*
 * For each chain select the alternate location that contains the maximum
 * number of CA atoms
 */
  for (i = 0; i < Nchains; i++) {
    pdb->selectedAltLoc[i] = ' ';
    if (al[i].NaltLocs != 0) {
      max_atoms = 0;
      for (j = 0; j < al[i].NaltLocs; j++) {
        if (al[i].Natoms[j] > max_atoms) {
          max_atoms = al[i].Natoms[j];
          pdb->selectedAltLoc[i] = al[i].altLoc[j];
        }
      }
    }
  }

  FREE(al);
}

/*******************************************************************************
 *
 ******************************************************************************/
static int get_chain_number(char chainId, char *chainNames, int Nchains)
{
  int i;

  for (i = 0; i < Nchains; i++) {
    if (chainId == chainNames[i]) {
      return i;
    }
  }

  ERROR_TAG;
  Erreur(1, "Error: Unable to find chain '%c' \n", chainId);

  return -1;
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * The program enters into this function when Nchain2 (the number of chains found
 * in ATOM records) is greater than Nchain1 (the number of chains found in SEQRES
 * records). This can be due to the presence of "trailing" hetero atoms such as
 * water molecules or ions etc. without a sidechain identification or trailing
 * hetero atoms with the same chain identification but located after another chain
 * (all sort of weird things happen in PDB file!!). The purpose of this function 
 * is to check this case and to set the corresponding position in validATOMchains 
 * to zero for the offending chain.
 * NOTE: array validATOMchains is used in the rest of the program every time a loop 
 *       on Nchain2 is performed to only consider valid chains.
 */
static void check_hetatm(pdb_t *pdb, int *validATOMchains)
{
  int i;
  char prevChainID;
  int Nhetero;
  int Natoms;
  int Nchain2;

  prevChainID = pdb->chainID[0];
  Nchain2 = 0;
  Nhetero = Natoms = 0;

/*
 * Check whether a chain contains only hetero atoms.
 * If this is the case flag it in 'validATOMchains'
 */
  for (i = 0; i < pdb->nat; i++) {
    if (pdb->chainID[i] != prevChainID) {
      if (Nhetero == Natoms) {
        validATOMchains[Nchain2] = 0;
      }
      Nchain2++;
      Nhetero = Natoms = 0;
    }
    if (strcmp(pdb->atomtype[i], "HETATM") == 0) {
      Nhetero++;
    }
    Natoms++;
    prevChainID = pdb->chainID[i];
  }
/*
 * Process last chain
 */
  if (Nhetero == Natoms) {
    validATOMchains[Nchain2] = 0;
  }
  Nchain2++;
}
