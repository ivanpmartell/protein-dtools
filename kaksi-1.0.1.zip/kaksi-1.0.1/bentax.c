#include <math.h>

#include "centroid.h"

/******************************************************************************
 *
 ******************************************************************************/
/**
 * This functions calculates the angle between two consecutive axes
 *
 * ==> C READY <==
 */
double bentax_(int kx, double *pstore1, double *pstore2)
{
  int k;
  double conv = 57.29577951308238;
  double scal;
  double v1[3], v2[3];

  for (k = 0; k < 3; k++) {
    v1[k] = pstore2[k + kx * 3] - pstore1[k + kx * 3];
    v2[k] = pstore2[k + (kx + 1) * 3] - pstore1[k + (kx + 1) * 3];
  }

  vector_norm_(v1);
  vector_norm_(v2);

  scal = v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2];
  if (scal > 1.0) {
    scal = 1.0;
  }
  if (scal < -1.0) {
    scal = -1.0;
  }

  return acos(scal) * conv;
}
