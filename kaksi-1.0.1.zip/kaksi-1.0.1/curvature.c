/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "kaksi.h"
#include "minim_new.h"

#define VLEN 3
#define RADCONV 57.29578
#define MAXCURV 25.0
#undef OLD_STYLE

/*******************************************************************************
 * LOCAL FUNCTIONS
 ******************************************************************************/
static int missing_CA(pdb_t *pdb, int iaa);
static double dotprod(double *u, double *v);
static double norm(double *u);
static void Write_PDB(char *fname, pdb_t *pdb, double **vectors,
    double **vcenter, int *ivec, int nc);
static double calc_curv(int iaa, double *uu, double *vv, double *pt1, double *pt2);
static double vlen(double *u, double *v);

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * This function computes the curvature of the polypeptide backbone.
 * The definition of curvature for a curve is:
 * C = alpha / Dl
 * where alpha is the angle between the curve tangents at points P and P'
 * and Dl is the arc length between P and P'
 * Here we compute vectors going through 5 or 7 points and assign these
 * vectors to the central point. The curvature between residues i and j
 * is given by the angle between the 2 vectors assigned to i and j divided 
 * by the distance between i and j.
 * The final curvature assigned to residue i is the mean of the curvatures
 * calculated between i-1 and i and i, i+1.
 * With this definition the curvature cannot be calculated for the first
 * 3 and last 3 residues in the sequence.
 *
 * NOTE:
 *   dd     : objective function value
 *   rexmax : max distance between a CA and the axis of the vector
 *   mode   : return value, should be 6
 */
void curvature(kaksi_args_t *args, pdb_t *pdb, int nc)
{
  char fname[256];
  int k, iaa, iv, isel;
  int ierr, mode;
  int lim1, lim2;
  int *ivec1 = NULL;
  double *tmp = NULL;
  double **vect1 = NULL;
  double **vcen1 = NULL;
  double keep_vec[VLEN][6];
  double keep_dd[VLEN];
  double keep_resmax[VLEN];
  double ddmin;
  double pt3[3], pt4[3];
  double *curvature = NULL;
  double dd, resmax;
  double pt1[3], pt2[3];

  CALLOC(pdb->curvature[nc], pdb->nat);
  CALLOC(curvature, pdb->nat);
  ALLOC(tmp, pdb->nat);
  ALLOC(ivec1, pdb->nat);
  ALLOC2(vect1, pdb->nat, 6);
  ALLOC2(vcen1, pdb->nat, 3);

  for (iaa = 0; iaa < pdb->nat; iaa++) {
    ivec1[iaa] = -1;
  }

/*
 * Computes the vectors (try vectors of length 5, 7, etc up to VLEN * 2 + 1)
 */
  for (iaa = 0; iaa < pdb->nat; iaa++) {
    if (missing_CA(pdb, iaa) != 0) {
      continue;
    }
/*
    printf("iaa = %5d, CAx = %7.3f, CAy = %7.3f, CAz = %7.3f\n", iaa,
        pdb->coo[iaa][0], pdb->coo[iaa][1], pdb->coo[iaa][2]);
    fflush(stdout);
*/
    /*
     * Do not use a vector of length 3 (iv == 1)
     */
    ivec1[iaa] = 1;
    for (iv = 2; iv <= VLEN; iv++) {
      lim1 = iaa - iv;
      lim2 = iaa + iv;
      ierr = 0;
      minim_new_(lim1, lim2, pdb->coo[0], pdb->nat, &dd, &resmax, &mode,
          pt1, pt2, &ierr);
      if (ierr > 0) {
        fprintf(stderr, "Error: %d in minim_new for residue %d dd = %f "
            "resmax = %f mode = %d\n", ierr, iaa + 1, dd, resmax, mode);
        ivec1[iaa] = -2.0;
        continue;
      }
/*
      printf("vector length=%d for residue %d dd=%f resmax=%f mode=%d\n",
          2 * iv + 1, iaa + 1, dd, resmax, mode);
      fflush(stdout);
*/
      for (k = 0; k < 3; k++) {
        keep_vec[iv - 1][k] = pt1[k];
        keep_vec[iv - 1][3 + k] = pt2[k];
      }
      keep_dd[iv - 1] = dd;
      keep_resmax[iv - 1] = resmax;
    }
    /*
     * Select the vector providing the best results in terms of dd
     */
    isel = 2;
    ddmin = keep_dd[isel - 1];
    for (iv = 2; iv <= VLEN; iv++) {
      if (keep_dd[iv - 1] < ddmin &&
          vlen(keep_vec[iv - 1], keep_vec[iv - 1] + 3) > 3.8) {
        ddmin = keep_dd[iv - 1];
        isel = iv;
      }
    }
/*
    printf("for residue %d vector of length %d selected\n", iaa, 2 * isel + 1);
    fflush(stdout);
*/
    for (k = 0; k < 3; k++) {
      vect1[iaa][k] = keep_vec[isel - 1][k];
      vect1[iaa][k + 3] = keep_vec[isel - 1][k + 3];
      vcen1[iaa][k] = 0.5 * (keep_vec[isel - 1][k] + keep_vec[isel - 1][k + 3]);
    }
  }

/*
 * Compute the curvature between 2 consecutive vectors
 */
  for (iaa = 0; iaa < pdb->nat - 1; iaa++) {
    if (ivec1[iaa] != 1 || ivec1[iaa + 1] != 1) {
      tmp[iaa] = pdb->curvature[nc][iaa];
      continue;
    }
    for (k = 0; k < 3; k++) {
      pt3[k] = (double) pdb->coo[iaa][k];
      pt4[k] = (double) pdb->coo[iaa + 1][k];
    }
    tmp[iaa] = calc_curv(iaa, vect1[iaa], vect1[iaa + 1], pt3, pt4);
/*
    printf("tmp[%4d] = %7.3f\n", iaa, tmp[iaa]);
    fflush(stdout);
*/
  }

/*
 * Because the curvature is calculated between two vectors (two CA),
 * the curvature of a CA is the mean of two curvatures
 */
  for (iaa = 0; iaa < pdb->nat - 1; iaa++) {
#ifdef OLD_STYLE
    curvature[iaa] = tmp[iaa];
#else
    if (tmp[iaa] > 0.0 && tmp[iaa + 1] > 0.0) {
      curvature[iaa + 1] = (tmp[iaa] + tmp[iaa + 1]) / 2.0;
/*
      printf("curvature[%4d] = %7.3f\n", iaa + 1, curvature[iaa + 1]);
      fflush(stdout);
*/
    }
#endif
  }

/*
 * Assign the mean curvature to the central point
 * Do not do that (A. Marin) to see...
 */
  for (iaa = 1; iaa < pdb->nat - 1; iaa++) {
#ifdef OLD_STYLE
    if (curvature[iaa - 1] > 0.0
        && curvature[iaa] > 0.0
        && curvature[iaa + 1] > 0.0) {
      pdb->curvature[nc][iaa] = (curvature[iaa - 1] + curvature[iaa]
          + curvature[iaa + 1]) / 3.0;
/*
      printf("pdb->curvature[%4d] = %7.3f\n", iaa, pdb->curvature[nc][iaa]);
      fflush(stdout);
*/
    }
#else
    if (curvature[iaa] > 0.0) {
      pdb->curvature[nc][iaa] = curvature[iaa];
/*
      printf("pdb->curvature[%4d] = %7.3f\n", iaa, pdb->curvature[nc][iaa]);
      fflush(stdout);
*/
    }
#endif
  }

/*
 * Print coordinates, vectors and curvature in a PDB-like file.
 */
  if (args->print_pdb_curv == 1) {
    if (pdb->chainNames[nc] != ' ') {
      sprintf(fname, "%s%c_curv.pdb", pdb->pdb_code, pdb->chainNames[nc]);
    } else {
      sprintf(fname, "%s_curv.pdb", pdb->pdb_code);
    }
    Write_PDB(fname, pdb, vect1, vcen1, ivec1, nc);
  }

  FREE(vect1);
  FREE(vcen1);
  FREE(tmp);
  FREE(ivec1);
  FREE(curvature);
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Return the number of missing residues in the [iaa-VLEN, iaa+VLEN] interval.
 */
static int missing_CA(pdb_t *pdb, int iaa)
{
  int i, k;
  int missing = 0;

  for (i = iaa - VLEN; i <= iaa + VLEN; i++) {
    if (i < 0 || i >= pdb->nat) {
      return 1;
    }
    for (k = 0; k < 3; k++) {
      if (pdb->coo[i][k] < (double) -999.0) {
        missing++;
      }
    }
  }

  return missing;
}

/*******************************************************************************
 *
 ******************************************************************************/
static double calc_curv(int iaa, double *uu, double *vv, double *pt1, double *pt2)
{
  int k;
  double scal;
  double vv1[3], vv2[3];
  double nv1, nv2;
  double angle;

  for (k = 0; k < 3; k++) {
    vv1[k] = uu[k + 3] - uu[k];
    vv2[k] = vv[k + 3] - vv[k];
  }
  nv1 = norm(vv1);
  nv2 = norm(vv2);
  if (nv1 < 0.000001 || nv2 < 0.000001) {
    fprintf(stderr, "Eroor: For residue %d the norm of a vector is nought: "
        "nv1 = %f and nv2 = %f\n", iaa + 1, nv1, nv2);
    return -2.0;
  }
  scal = dotprod(vv1, vv2) / (nv1 * nv2);
  angle = acos(scal);
  for (k = 0; k < 3; k++) {
    vv1[k] = pt2[k] - pt1[k];
  }

  return (RADCONV * angle / sqrt(dotprod(vv1, vv1)));
}

/*******************************************************************************
 *
 ******************************************************************************/
static double vlen(double *u, double *v)
{
  double z[3];
  int k;

  for (k = 0; k < 3; k++) {
    z[k] = v[k] - u[k];
  }
  return sqrt(z[0] * z[0] + z[1] * z[1] + z[2] * z[2]);
}

/*******************************************************************************
 *
 ******************************************************************************/
static double dotprod(double *u, double *v)
{
  return (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]);
}

/*******************************************************************************
 *
 ******************************************************************************/
static double norm(double *u)
{
  return sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]);
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Write structure PDB in PDB format in a file
 */
static void Write_PDB(char *fname, pdb_t *pdb, double **vectors,
    double **vcenter, int *ivec, int nc)
{
  FILE *fp;
  int iat, jat, keep_jat;
  char fmt1[] = "ATOM %6d %s %s %c %3d    %8.3f%8.3f%8.3f%6.2f%6.2f\n";
  char fmt2[] = "HETATM %4d %s %s %c %3d    %8.3f%8.3f%8.3f%6.2f%6.2f\n";
  char atomname[5] = " CA ";
  char chain;
  double occupancy = 1.0;
  int numres;
  int nvect;
  double curvature;

  chain = pdb->chainNames[nc];

  if (pdb->nat == 0) {
    fprintf(stderr, "Warning: no atoms in chain '%c'\n", chain);
    return;
  }

  FOPEN(fp, fname, "w");

/*
 * Write the CA
 */
  for (iat = 0; iat < pdb->nat; iat++) {
    curvature = pdb->curvature[nc][iat];
    if (iat == pdb->nat - 1) {
      /*
       * The curvature of the last residue in the structure is assigned to
       * MAXCURV (the maximum curvature observed in a number of structures, 
       * that turns out to be 25�/A).
       * This is done for having a consistent color scheme for the curvature 
       * in RASMOL in different structures.
       * The color code goes from blue for the min value to red for the max
       * value read in the temperature field of the PDB file.  Here the min
       * is always 0., for the first, and last, four residues for which the 
       * curvature cannot be calculated, and the max is thus fixed to MAXCURV.
       */
      curvature = MAXCURV;
    }
    fprintf(fp, fmt1, iat + 1, atomname, pdb->resname[iat],
	    chain, pdb->numres[iat], pdb->coo[iat][0], pdb->coo[iat][1],
	    pdb->coo[iat][2], occupancy, curvature);
  }
  fprintf(fp, "TER   %5d      %s %c %3d\n", pdb->nat,
      pdb->resname[pdb->nat - 1], chain, pdb->numres[pdb->nat - 1]);

/*
 * Write the vectors
 */
  jat = pdb->nat;
  numres = pdb->numres[0];

  nvect = 0;
  for (iat = 0; iat < pdb->nat; iat++) {
    if (ivec[iat] != 1) {
      numres++;
      continue;
    }
    fprintf(fp, fmt2, ++jat, " C1 ", "VEC", ' ', numres, vectors[iat][0],
        vectors[iat][1], vectors[iat][2], 0.0, occupancy);
    fprintf(fp, fmt2, ++jat, " C1 ", "VEC", ' ', numres, vectors[iat][3],
        vectors[iat][4], vectors[iat][5], 0.0, occupancy);
    numres++;
    nvect++;
  }

  keep_jat = jat;

/*
 * Write the vector centers
 */
  numres = pdb->numres[0];

  for (iat = 0; iat < pdb->nat; iat++) {
    if (ivec[iat] != 1) {
      numres++;
      continue;
    }
    fprintf(fp, fmt2, ++jat, " CC ", "TRA", '$', numres, vcenter[iat][0],
        vcenter[iat][1], vcenter[iat][2], 1.0, pdb->curvature[nc][iat]);
    numres++;
  }

/*
 * Write the CONECT records
 */
  for (iat = pdb->nat + 1; iat <= pdb->nat + 2 * nvect; iat += 2) {
    fprintf(fp, "CONECT %4d %4d\n", iat, iat + 1);
  }
  for (iat = pdb->nat + 2 * nvect + 1; iat <= pdb->nat + 3 * nvect; iat++) {
    fprintf(fp, "CONECT %4d %4d\n", iat, iat + 1);
  }

  fprintf(fp, "END\n");

  FCLOSE(fp);
}
