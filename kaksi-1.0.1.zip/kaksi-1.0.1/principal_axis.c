#include "bstfit.h"

/******************************************************************************
 *
 ******************************************************************************/
/**
 * Determine the principal axis of a secondary structure element
 * The algorithm is based on the singular value decomposition of
 * the coordinate matrix. The routine used is similar to the one
 * used in bstfit.f (svdd).
 * Last modification 19/08/96
 * Note: I havn't the foggiest idea of the purpose of parameter
 * isw in svdd. It seems to work with the value 3!
 *
 * ==> C READY <==
 */
int principal_axis_(int lim1, int lim2, double *cax, double *vnew, int *ierr)
{
  int isw = 3;
  int i, j, k;
  int ii;
  int iat, nat;
  int c__200 = 200;
  int c__3 = 3;
  double aa[600]; /* was [200][3] */
  double dd[3];
  double uu[600]; /* was [200][3] */
  double vv[9]; /* was [3][3] */
  double ww[3], ave;

  nat = lim2 - lim1 + 1;

  if (2 * nat > 200) {
    *ierr = 10;
    return 0;
  }

  for (i = 0; i < 3; i++) {
    dd[i] = 0.0;
    ww[i] = 0.0;
    for (k = 0; k < 3; k++) {
      vv[k + i * 3] = 0.0;
    }
  }

/* Transfer the coordinates to the work matrix */

  iat = 0;
  for (i = lim1; i <= lim2; i++) {
    for (k = 0; k < 3; k++) {
      aa[iat + k * 200] = cax[k + i * 3];
    }
    iat++;
  }

/* Normalize the matrix, i.e., substract the average value of each row */

  for (j = 0; j < 3; ++j) {
    ave = 0.0;
    for (i = 0; i < nat; i++) {
      ave += aa[i + j * 200];
    }
    ave /= nat;
    for (i = 0; i < nat; i++) {
      aa[i + j * 200] -= ave;
    }
  }

/* Singular value decomposition */

  svdd_(aa, &c__200, &nat, &c__3, &isw, dd, uu, &c__200, vv, &c__3, ww, ierr);

  if (*ierr != 0) {
    *ierr = 11;
    return 0;
  }

/* Find the greatest singular value */

  if (dd[1] > dd[2]) {
    ii = 1;
  } else {
    ii = 2;
  }
  if (dd[0] > dd[ii]) {
    ii = 0;
  }

/* Get the corresponding principal axis direction */

  for (k = 0; k < 3; k++) {
    vnew[k] = vv[k + ii * 3];
  }

  return 0;
}
