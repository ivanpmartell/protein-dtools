#include <stdio.h>

#include "util.h"
#include "minim_new.h"
#include "bentax.h"

/******************************************************************************
 *
 ******************************************************************************/
/**
 * This subroutine determines the axis for each secondary structure
 * element (SSE). These SSE's are coded in array nsegment (one SSE per
 * row) and are defined in the previous stage of the parser.
 *
 * The first step of this routine is an attempt to refine the boundaries of
 * the SSEs by looking at the curvature of the polypeptide chain. If for a
 * segment this curvature is greater than a given value the segment is split
 * into 2 pieces (see routine curvature).
 *
 * The algorithm tries to fit an axis through the SSE by minimising the
 * function:  DD = 1/n Sum{(di-<d>)*(di-<d>)}
 * where n is the number of Ca's, the summation is taken over n, di is the
 * distance of the ith Ca to the axis and <d> is the average value of these
 * distances, i.e., <d> = 1/n Sum{di}.
 *
 * If the value of the residual, or the value of the function is above some
 * threshold this is an indication that a single axis is not a good description
 * of the SSE (which is likely bent or kinked) and the algorithm tries to fit
 * two or more axes through the SSE.
 *
 * The last stage of the procedure check whether two consecutive axes (same SSE
 * type) cannot be collapsed into a single one (if the angle they form is less
 * than a specified threshold angle).
 *
 * Once the axes are determined the internal variables are calculated for all
 * the pairs of SSEs. There are  4 internal variables, rho, theta, alpha,
 * omega needed to describe the position of a SSE with respect to another
 * one. See description in subroutine internal.c
 *
 * Input arguments:
 * maxvec: maximum number of SSE segment per structure (200)
 * nsegment: starting residue, ending residue, type of SSE.
 * cax: contains the coordinates of the corresponding Ca atoms.
 * natoms: is the number of CA atoms in the protein.
 * nsse: number of SSE according to the previous step of the parser.
 * lensse: is a vector of length 2 containing the minimum length for
 * a helix and a strand (as defined in the parser).
 * angle (deg.): if the angle between 2 consecutives axes (same SSE type)
 * is less than this value the two axes are collapsed into a single one.
 *
 * Output arguments:
 * SSEcorresp: the correspondence between initial and final SSEs
 * nvect: the final number of axes (including the ones that are flagged)
 * lmstore[k,1:2]: starting and ending residues for the kth SSE
 * lmstore[k,3]: minimisation condition code.
 * lmstore[k,4]: SSE type
 * pstore1: coordinates of the starting point of the axes
 * pstore2: coordinates of the end point of the axes
 * fstore[k,1]: value of the function at the end of the minimisation
 * fstore[k,2]: value of the max residual at the end of the minimisation
 * intern: internal coordinates for all pairs of SSEs of the protein.
 *
 * Last modification: 28/09/94        Modification to allow the sub. to
 *                                    be called by Splus.
 *
 *                    22/08/95        Addition of a step that determines
 *                                    whether the SSEs need to be divided
 *                                    into several pieces before fitting
 *                                    an axis through them.
 *
 *                    22/11/95        Modification of minimization routine
 *                                    see the routine header for details
 */
int axis_(int *maxvec, int *nsegment, int *nsse, double *cax, int natoms,
    int *lensse, double *angle, int *issecorresp, int *ind12, int *nvect,
    int *lmstore, double *pstore1, double *pstore2, double *fstore, int *ierr)
{
  int lsh[2] = { 2, 3 };
  double t1fh = 1.2;
  double t1rh = 2.0;
  double t2fh = 0.4;
  double t2rh = 0.8;
  double t1fs = 1.2;
  double t1rs = 2.0;
  double t2fs_min__ = 0.8;
  double t2rs_min__ = 1.4;

  /* System generated locals */
  int i__1, i__2, i__3;
  double d__1, d__2;

  /* Local variables */
  int mode, nfin;
  int new_nsse__, keep2, i__, j, k, l, itemp, nlast, ltemp;
  int ntemp[900]; /* was [3][300] */
  int itype, k1, l1, istop, l2, k2;
  int new_nvect__;
  double pkeep1[900]; /* was [3][300] */
  double pkeep2[900]; /* was [3][300] */
  double dd;
  int jj, kk;
  double fckeep[600]; /* was [2][300] */
  int ls, kx, ky, mdkeep[300], kz, nv;
  int length, ifound;
  double resmax;
  int growth;
  double pt1[3], pt2[3];
  int ind1, ind2, lim1, lim2;
  double t2fs, t2rs;

/* Parameter adjustments */
  fstore -= 3;
  pstore2 -= 4;
  pstore1 -= 4;
  lmstore -= 5;
  issecorresp -= 3;
  --lensse;
  nsegment -= 4;

  /* printf("*nsse (%p) [%d] = %ld\n", (void *) nsse, __LINE__, *nsse); */

  jj = 0;
  *ierr = 0;
  mode = 1;

  if (natoms > 2000) {
    *ierr = 1;
    return 0;
  }

  i__1 = *nsse;
  for (i__ = 1; i__ <= i__1; ++i__) {
    for (j = 1; j <= 3; ++j) {
      ntemp[j + i__ * 3 - 4] = nsegment[j + i__ * 3];
    }
  }

  new_nsse__ = *nsse;

/* Loop over the SSE's of the protein. An axis is calculated using all the Ca's of the */
/* SSE. If the minimization fails for some reason (mode != 0) or if the function value */
/* is above a given threshold or if the maximum value of the residuals is also above some */
/* threshold the algorithm checks whether the SSE is not bend or kinked, that is, whether */
/* it cannot be represented by two, or more, axes. */

/* printf("*nsse (%p) [%d] = %ld\n", (void *) nsse, __LINE__, *nsse);*/

  *nvect = 0;

  i__1 = new_nsse__;
  for (ls = 1; ls <= i__1; ++ls) {

    lim1 = ntemp[ls * 3 - 3];
    lim2 = ntemp[ls * 3 - 2];
    itype = ntemp[ls * 3 - 1];

    minim_new_(lim1, lim2, cax, natoms, &dd, &resmax, &mode, pt1, pt2, ierr);
    if (*ierr != 0) {
      return 0;
    }

/* Store the axis information */

    ++(*nvect);
    if (*nvect > *maxvec) {
      *ierr = 2;
      return 0;
    }
    lmstore[(*nvect << 2) + 1] = lim1;
    lmstore[(*nvect << 2) + 2] = lim2;
    lmstore[(*nvect << 2) + 3] = mode;
    lmstore[(*nvect << 2) + 4] = itype;
    fstore[(*nvect << 1) + 1] = dd;
    fstore[(*nvect << 1) + 2] = resmax;
    for (kz = 1; kz <= 3; ++kz) {
      pstore1[kz + *nvect * 3] = pt1[kz - 1];
      pstore2[kz + *nvect * 3] = pt2[kz - 1];
    }

/* Check whether the axis found provides a good description of the SSE */
/* If the values of the function (DD) or of the maximum residual (resmax) exceed some */
/* specified threshold the SSE cannot be accurately represented by a single vector. */

    if ((itype == 1 && (dd > t1fh || resmax > t1rh))
        || (itype == 2 && (dd > t1fs || resmax > t1rs))) {
      --(*nvect);

/* suppress the last axis which turned out to */

      nlast = *nvect;
      keep2 = lim2;
      lim2 = lim1 + lensse[itype] - 1;
      growth = FALSE;
      i__2 = *maxvec;
      for (kx = *nvect + 1; kx <= i__2; ++kx) {
        for (kz = 1; kz <= 4; ++kz) {
          lmstore[kz + (kx << 2)] = 0;
        }
      }
      kk = 0;
      istop = 0;

      /* printf("*nsse (%p) [%d] = %ld\n", (void *) nsse, __LINE__, *nsse); */

      while (lim2 <= keep2 && istop <= 1) {

        minim_new_(lim1, lim2, cax, natoms, &dd, &resmax, &mode, pt1, pt2,
            ierr);
        if (*ierr != 0) {
          return 0;
        }

/* Store required information in temporary arrays */

        ++kk;
        if (kk > 300) {
          *ierr = 3;
          return 0;
        }
        fckeep[(kk << 1) - 2] = dd;
        fckeep[(kk << 1) - 1] = resmax;
        mdkeep[kk - 1] = mode;
        for (kz = 1; kz <= 3; ++kz) {
          pkeep1[kz + kk * 3 - 4] = pt1[kz - 1];
          pkeep2[kz + kk * 3 - 4] = pt2[kz - 1];
        }

/* Computing MAX */

        d__1 = t2fs_min__, d__2 = t1fs * (double) .5;
        t2fs = MAX2(d__1, d__2);

/* Computing MAX */

        d__1 = t2rs_min__, d__2 = t1rs * (double) .5;
        t2rs = MAX2(d__1, d__2);

/* Test whether the current segment is within the limits */

        if ((itype == 1 && (dd > t2fh || resmax > t2rh))
            || (itype == 2 && (dd > t2fs || resmax > t2rs))) {

          if (growth) {

/* There is an open segment that must b */

            growth = FALSE;
            itemp = lim2 - lsh[itype - 1];
            ltemp = lmstore[(*nvect << 2) + 1] + lensse[itype] - 1;
            if (itemp >= ltemp) {

/* Backtracking */

              fstore[(*nvect << 1) + 1] =
                  fckeep[((kk - lsh[itype - 1]) << 1) - 2];
              fstore[(*nvect << 1) + 2] =
                  fckeep[((kk - lsh[itype - 1]) << 1) - 1];
              lmstore[(*nvect << 2) + 2] = itemp;
              lmstore[(*nvect << 2) + 3] = mdkeep[kk - lsh[itype - 1] - 1];
              lmstore[(*nvect << 2) + 4] = itype;
              for (kz = 1; kz <= 3; ++kz) {
                pstore1[kz + *nvect * 3] =
                    pkeep1[kz + (kk - lsh[itype - 1]) * 3 - 4];
                pstore2[kz + *nvect * 3] =
                    pkeep2[kz + (kk - lsh[itype - 1]) * 3 - 4];
              }
              lim1 = itemp + 1;
              lim2 = lim1 + lensse[itype] - 1;
              if (lim2 > keep2) {
                lim2 = keep2;
                ++istop;
              }
            } else {

/* End of the current segment is loc */

              lim2 = itemp;

/* corresponding nucleus. Reset lim2 */

              minim_new_(lim1, lim2, cax, natoms, &dd, &resmax, &mode, pt1,
                  pt2, ierr);
              if (*ierr != 0) {
                return 0;
              }
              fstore[(*nvect << 1) + 1] = dd;
              fstore[(*nvect << 1) + 2] = resmax;
              lmstore[(*nvect << 2) + 2] = lim2;
              lmstore[(*nvect << 2) + 3] = mode;
              lmstore[(*nvect << 2) + 4] = itype;
              for (kz = 1; kz <= 3; ++kz) {
                pstore1[kz + *nvect * 3] = pt1[kz - 1];
                pstore2[kz + *nvect * 3] = pt2[kz - 1];
              }
              lim1 = itemp + 1;
              lim2 = lim1 + lensse[itype] - 1;
              if (lim2 > keep2) {
                lim2 = keep2;
                ++istop;
              }
            }
          } else {
            ++lim1;
            lim2 = lim1 + lensse[itype] - 1;
          }

        } else {

/* Segment within the specified limits */

          if (growth) {

/* there is an open segment so increase */

            ++lim2;
          } else {

/* No open segment, create a new one */

            ++(*nvect);
            if (*nvect > *maxvec) {
              *ierr = 2;
              return 0;
            }
            lmstore[(*nvect << 2) + 1] = lim1;
            ++lim2;
            growth = TRUE;
          }

        }

      }

      /* printf("*nsse (%p) [%d] = %ld\n", (void *) nsse, __LINE__, *nsse); */

      if (lmstore[(*nvect << 2) + 2] == 0) {

/* Close the last segment */

        lmstore[(*nvect << 2) + 2] = keep2;
        fstore[(*nvect << 1) + 1] = fckeep[(kk << 1) - 2];
        fstore[(*nvect << 1) + 2] = fckeep[(kk << 1) - 1];
        lmstore[(*nvect << 2) + 3] = mdkeep[kk - 1];
        lmstore[(*nvect << 2) + 4] = itype;
        for (kz = 1; kz <= 3; ++kz) {
          pstore1[kz + *nvect * 3] = pkeep1[kz + kk * 3 - 4];
          pstore2[kz + *nvect * 3] = pkeep2[kz + kk * 3 - 4];
        }
      }

/*  Check whether consecutive vectors are close to be colinear */

      i__2 = *nvect - 1;
      for (kx = nlast + 1; kx <= i__2; ++kx) {
        if (lmstore[(kx << 2) + 2] == lmstore[((kx + 1) << 2) + 1] - 1) {
          /* (kx - 1) because bentax_ is "C READY" */
          if (bentax_((kx - 1), &pstore1[4], &pstore2[4]) < *angle) {
            lim1 = lmstore[(kx << 2) + 1];
            lim2 = lmstore[((kx + 1) << 2) + 2];
            minim_new_(lim1, lim2, cax, natoms, &dd, &resmax, &mode, pt1,
                pt2, ierr);
            if (*ierr != 0) {
              return 0;
            }
            lmstore[(kx << 2) + 1] = lim1;
            lmstore[(kx << 2) + 2] = lim2;
            lmstore[(kx << 2) + 3] = mode;
            lmstore[(kx << 2) + 4] = itype;
            fstore[(kx << 1) + 1] = dd;
            fstore[(kx << 1) + 2] = resmax;
            for (kz = 1; kz <= 3; ++kz) {
              pstore1[kz + kx * 3] = pt1[kz - 1];
              pstore2[kz + kx * 3] = pt2[kz - 1];
            }
            i__3 = *nvect;
            for (ky = kx + 2; ky <= i__3; ++ky) {
              for (kz = 1; kz <= 3; ++kz) {
                pstore1[kz + (ky - 1) * 3] = pstore1[kz + ky * 3];
                pstore2[kz + (ky - 1) * 3] = pstore2[kz + ky * 3];
              }
              for (kz = 1; kz <= 4; ++kz) {
                lmstore[kz + ((ky - 1) << 2)] = lmstore[kz + (ky << 2)];
              }
              fstore[((ky - 1) << 1) + 1] = fstore[(ky << 1) + 1];
              fstore[((ky - 1) << 1) + 1] = fstore[(ky << 1) + 1];
            }
            --(*nvect);
          }
        }
      }

    }

/* end of test whether the 1st axis calculated is valid */

  }

/* Remove the SSEs whose length is less than the standard length (lensse) in lmstore */

/*  printf("*nsse (%p) [%d] = %ld\n", (void *) nsse, __LINE__, *nsse);*/

  new_nvect__ = 0;
  i__1 = *nvect;
  for (nv = 1; nv <= i__1; ++nv) {
    length = lmstore[(nv << 2) + 2] - lmstore[(nv << 2) + 1] + 1;
    itype = lmstore[(nv << 2) + 4];
    if (length < lensse[itype]) {
      lmstore[(nv << 2) + 4] = -lmstore[(nv << 2) + 4];
    } else {
      ++new_nvect__;
    }
  }

  for (nv = *nvect; nv >= 1; --nv) {
    if (lmstore[(nv << 2) + 4] < 0) {
      i__1 = *nvect;
      for (k = nv + 1; k <= i__1; ++k) {
        for (l = 1; l <= 4; ++l) {
          lmstore[l + ((k - 1) << 2)] = lmstore[l + (k << 2)];
        }
        for (l = 1; l <= 2; ++l) {
          fstore[l + ((k - 1) << 1)] = fstore[l + (k << 1)];
        }
        for (l = 1; l <= 3; ++l) {
          pstore1[l + (k - 1) * 3] = pstore1[l + k * 3];
          pstore2[l + (k - 1) * 3] = pstore2[l + k * 3];
        }
      }
    }
  }

  *nvect = new_nvect__;

/* Determine the correspondence between the initial and final SSEs */

/*  printf("*nsse (%p) [%d] = %ld\n", (void *) nsse, __LINE__, *nsse);*/

  if (*nvect > *nsse) {
    ind1 = 0;
    *ind12 = 0;
    i__1 = *nvect;
    for (i__ = 1; i__ <= i__1; ++i__) {
      ++ind1;
      l1 = lmstore[(i__ << 2) + 1];
      l2 = lmstore[(i__ << 2) + 2];
      ind2 = 0;
      i__2 = *nsse;
      for (j = 1; j <= i__2; ++j) {
        ++ind2;
        k1 = nsegment[j * 3 + 1];
        k2 = nsegment[j * 3 + 2];
        if ((l1 <= k1 && k1 <= l2)
            || (l1 <= k2 && k2 <= l2)
            || (k1 <= l1 && l1 <= k2)
            || (k1 <= l2 && l2 <= k2)) {
          ++(*ind12);
          if (*ind12 > *maxvec) {
            *ierr = 2;
            return 0;
          }
          issecorresp[(*ind12 << 1) + 1] = ind1;
          issecorresp[(*ind12 << 1) + 2] = ind2;
        }
      }
    }
  } else {
    ind2 = 0;
    *ind12 = 0;
    i__1 = *nsse;
    for (i__ = 1; i__ <= i__1; ++i__) {
      ++ind2;
      l1 = nsegment[i__ * 3 + 1];
      l2 = nsegment[i__ * 3 + 2];
      ind1 = 0;
      i__2 = *nvect;
      for (j = 1; j <= i__2; ++j) {
        ++ind1;
        k1 = lmstore[(j << 2) + 1];
        k2 = lmstore[(j << 2) + 2];
        if ((l1 <= k1 && k1 <= l2)
            || (l1 <= k2 && k2 <= l2)
            || (k1 <= l1 && l1 <= k2)
            || (k1 <= l2 && l2 <= k2)) {
          ++(*ind12);
          if (*ind12 > *maxvec) {
            *ierr = 2;
            return 0;
          }
          issecorresp[(*ind12 << 1) + 1] = ind1;
          issecorresp[(*ind12 << 1) + 2] = ind2;
        }
      }
    }
  }

  i__1 = *nvect;
  for (i__ = 1; i__ <= i__1; ++i__) {
    nfin = *ind12;
    ifound = 0;
    i__2 = nfin;
    for (j = 1; j <= i__2; ++j) {
      if (i__ == issecorresp[(j << 1) + 1]) {
        ++ifound;
      }
      if (i__ > issecorresp[(j << 1) + 1]) {
        jj = j + 1;
      }
    }
    if (ifound == 0) {
      ++(*ind12);
      if (*ind12 > *maxvec) {
        *ierr = 2;
        return 0;
      }
      i__2 = jj;
      for (k = nfin; k >= i__2; --k) {
        issecorresp[((k + 1) << 1) + 1] = issecorresp[(k << 1) + 1];
        issecorresp[((k + 1) << 1) + 2] = issecorresp[(k << 1) + 2];
      }
      issecorresp[(jj << 1) + 1] = i__;
      issecorresp[(jj << 1) + 2] = 0;
    }
  }

  i__1 = *nsse;
  for (i__ = 1; i__ <= i__1; ++i__) {
    nfin = *ind12;
    ifound = 0;
    i__2 = nfin;
    for (j = 1; j <= i__2; ++j) {
      if (i__ == issecorresp[(j << 1) + 2]) {
        ++ifound;
      }
      if (i__ > issecorresp[(j << 1) + 2]) {
        jj = j + 1;
      }
    }
    if (ifound == 0) {
      ++(*ind12);
      if (*ind12 > *maxvec) {
        *ierr = 2;
        return 0;
      }
      i__2 = jj;
      for (k = nfin; k >= i__2; --k) {
        issecorresp[((k + 1) << 1) + 1] = issecorresp[(k << 1) + 1];
        issecorresp[((k + 1) << 1) + 2] = issecorresp[(k << 1) + 2];
      }
      issecorresp[(jj << 1) + 1] = 0;
      issecorresp[(jj << 1) + 2] = i__;
    }
  }
  return 0;
}
