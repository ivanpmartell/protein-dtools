/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "kaksi.h"
#include "parse_PDB_file.h"

/**
 * XML output for all the information.
 */
void fprint_results(FILE *fp, kaksi_args_t *args, pdb_t *pdb,
    struct PHIPSI *PhiPsi, double ***coo_CA, struct SEQUENCE *sseSeq,
    char ***contact)
{
  int i, k, ncS, nrS, n1, n2;
  ppf_args_t *pargs;

  pargs = &args->pargs;
  fprintf(fp, "<?xml version=\"1.0\" encoding=\"iso-8859-1\" "
      "standalone=\"no\"?>\n");
  fprintf(fp, "<!DOCTYPE kaksi_results SYSTEM \"kaksi_results.dtd\">\n");
  fprintf(fp, "<kaksi_results>\n");
  fprintf(fp, "  <pdb_code>%s</pdb_code>\n", pargs->pdb_code);
  fprintf(fp, "  <num_chains>%d</num_chains>\n", pdb->prot_Nchains);
  for (ncS = 0; ncS < pdb->Nchains; ncS++) {
    if (pdb->status[ncS] != 0) {
      continue;
    }
    if (pargs->user_chain_id != '�'
        && pdb->chainNames[ncS] != pargs->user_chain_id) {
      continue;
    }
    fprintf(fp, "  <chain>\n");
    fprintf(fp, "    <name>%c</name>\n", pdb->chainNames[ncS]);
    fprintf(fp, "    <sequence_length>%d</sequence_length>\n",
        pdb->chain_nres[ncS]);
    fprintf(fp, "    <sequence>\n");
    for (nrS = 0; nrS < pdb->chain_nres[ncS]; nrS++) {
      fprintf(fp, "      <res>");
      fprintf(fp, "<aa1>%c</aa1>", pdb->seq[ncS][nrS]);
      fprintf(fp, "<num>%d</num>", nrS + 1);
      if (pdb->SEQRESiCode[ncS][nrS] == '�') {
        fprintf(fp, "<pdb_num></pdb_num>");
        fprintf(fp, "<pdb_icode></pdb_icode>");
      } else {
        fprintf(fp, "<pdb_num>%d</pdb_num>", pdb->SEQRESnumres[ncS][nrS]);
        fprintf(fp, "<pdb_icode>%c</pdb_icode>", pdb->SEQRESiCode[ncS][nrS]);
      }
      fprintf(fp, "<phi>%.3f</phi>", PhiPsi[ncS].Phi[nrS]);
      fprintf(fp, "<psi>%.3f</psi>", PhiPsi[ncS].Psi[nrS]);
      if (pdb->SEQRESiCode[ncS][nrS] == '�') {
        fprintf(fp, "<curv>%.3f</curv>", 0.0);
      } else {
        fprintf(fp, "<curv>%.3f</curv>", pdb->curvature[ncS][nrS]);
      }
      fprintf(fp, "<sse>%c</sse>", pdb->sse[ncS][nrS]);
      fprintf(fp, "<kaksi_sse>%c</kaksi_sse>", sseSeq[ncS].seq[nrS]);
      fprintf(fp, "<CAx>%.3f</CAx>", coo_CA[ncS][nrS][0]);
      fprintf(fp, "<CAy>%.3f</CAy>", coo_CA[ncS][nrS][1]);
      fprintf(fp, "<CAz>%.3f</CAz>", coo_CA[ncS][nrS][2]);
      k = 0;
      n1 = -999;
      n2 = -999;
      for (i = 0; i < pdb->chain_nres[ncS]; i++) {
        if (contact[ncS][nrS][i] != '.') {
          if (k == 0) {
            n1 = i + 1;
            if (contact[ncS][nrS][i] == 'a') {
              n1 = -n1;
            }
            k++;
          } else if (k == 1) {
            n2 = i + 1;
            if (contact[ncS][nrS][i] == 'a') {
              n2 = -n2;
            }
            k++;
          } else {
            fprintf(stderr, "Warning: More than 2 neighbors in beta strand "
                "for residue %d, PDB code = %s\n", nrS + 1, pargs->pdb_code);
          }
/*
 * Skip direct neighbor to avoid problems
 * This should be fixed when beta neighbors selected properly
 * (see KAKSI TODO)
 */
          i++;
        }
      }
      if (n1 != -999) {
        fprintf(fp, "<beta1>%+d</beta1>", n1);
      } else {
        fprintf(fp, "<beta1></beta1>");
      }
      if (n2 != -999) {
        fprintf(fp, "<beta2>%+d</beta2>", n2);
      } else {
        fprintf(fp, "<beta2></beta2>");
      }
      fprintf(fp, "</res>\n");
    }
    fprintf(fp, "    </sequence>\n");
    fprintf(fp, "  </chain>\n");
  }
  fprintf(fp, "</kaksi_results>\n");
}
