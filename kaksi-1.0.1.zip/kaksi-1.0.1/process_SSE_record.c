/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

/*******************************************************************************
 * LOCAL DATA STRUCTURES
 ******************************************************************************/
struct SSErecord {
  char sseName[7]; /* Name of SSE considered */
  char symbol;     /* One letter symbol for SSE */
  int initResName; /* starting position for initResName in SSE record line */
  int initChainId; /* starting position for initChainId in SSE record line */
  int initSeqNum;  /* starting position for initSeqNum in SSE record line */
  int initIcode;   /* starting position for initIcode in SSE record line */
  int endResName;  /* ending position for initResName in SSE record line */
  int endChainId;  /* ending position for endChainId in SSE record line */
  int endSeqNum;   /* ending position for endSeqNum in SSE record line */
  int endIcode;    /* ending position for endIcode in SSE record line */
};

struct SSE_DESC {
  char **initResName;
  int *initSeqNum;
  char *initIcode;
  char **endResName;
  int *endSeqNum;
  char *endIcode;
};

/*******************************************************************************
 * LOCAL FUNCTIONS
 ******************************************************************************/
static void fill_sse(struct NODE *headSSE, struct SSErecord *rc, char chainId,
    struct RecordTransfer *ATOMrec, struct MiscTransfer *MT, int ncA,
    char *sse);
static void remove_tags_from_sse(int chain_nres, char *sse);
static int check_sse_separation(int chain_nres, char *sse);
static int calculate_current_sse_length(char *sse, int nr, char c);
static int calculate_previous_sse_length(char *sse, int nr, char c);
static int check_sse_length(int chain_nres, char *sse, int length_H,
    int length_b);

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Process the data in secondary structure records
 * Note: here the number of chains and number of
 * residues in SEQRES and ATOM records should
 * be consistent. All arrays are thus allocated
 * with SEQRESrec->Nchain and SEQRESrec->chain_nres.
 */
void process_SSE_record(pdb_t *pdb, struct NODES *heads,
    struct MiscTransfer *MT, struct RecordTransfer *SEQRESrec,
    struct RecordTransfer *ATOMrec, ppf_args_t *pargs)
{
  struct SSErecord Hrecord, Erecord, Trecord;
  int nc, nr, ncA, anr, i, j;
  char *sse = NULL;

/*
 * Initialize the SSE records
 */
  strcpy(Hrecord.sseName, "helix");
  Hrecord.symbol = 'H';

  Hrecord.initResName = 15;
  Hrecord.initChainId = 19;
  Hrecord.initSeqNum = 21;
  Hrecord.initIcode = 25;

  Hrecord.endResName = 27;
  Hrecord.endChainId = 31;
  Hrecord.endSeqNum = 33;
  Hrecord.endIcode = 37;


  strcpy(Erecord.sseName, "strand");
  Erecord.symbol = 'b';

  Erecord.initResName = 17;
  Erecord.initChainId = 21;
  Erecord.initSeqNum = 22;
  Erecord.initIcode = 26;

  Erecord.endResName = 28;
  Erecord.endChainId = 32;
  Erecord.endSeqNum = 33;
  Erecord.endIcode = 37;


  strcpy(Trecord.sseName, "turn");
  Trecord.symbol = 'T';

  Trecord.initResName = 15;
  Trecord.initChainId = 19;
  Trecord.initSeqNum = 20;
  Trecord.initIcode = 24;

  Trecord.endResName = 26;
  Trecord.endChainId = 30;
  Trecord.endSeqNum = 31;
  Trecord.endIcode = 35;

  ALLOC(pdb->sse, SEQRESrec->Nchain);
  ALLOC(pdb->SEQRESnumres, SEQRESrec->Nchain);
  ALLOC(pdb->SEQRESiCode, SEQRESrec->Nchain);
  for (i = 0; i < SEQRESrec->Nchain; i++) {
    ALLOC(pdb->sse[i], SEQRESrec->chain_nres[i] + 1);
    ALLOC(pdb->SEQRESnumres[i], SEQRESrec->chain_nres[i] + 1);
    ALLOC(pdb->SEQRESiCode[i], SEQRESrec->chain_nres[i] + 1);
    for (j = 0; j < SEQRESrec->chain_nres[i] + 1; j++) {
      pdb->SEQRESnumres[i][j] = -1;
      pdb->SEQRESiCode[i][j] = '�';
    }
  }

/*
 * Transfer data in NODE structures to array sse
 * Note: residue numbering in records HELIX, SHEET
 *       and TURN refers to numbering in ATOM records.
 */
  for (nc = 0; nc < pdb->Nchains; nc++) {
    if (pdb->status[nc] != 0) {
      continue;
    }

    ncA = getATOMchainNumber(nc, MT, ATOMrec, SEQRESrec);

    /*
     * Create a secondary structure array corresponding
     * to the residues in ATOM records.
     */
    ALLOC(sse, SEQRESrec->chain_nres[nc] + 1);
    sse[SEQRESrec->chain_nres[nc]] = '\0';

    memset(sse, '.', SEQRESrec->chain_nres[nc]);

    if (heads->headHelix != NULL) {
      fill_sse(heads->headHelix, &Hrecord, pdb->chainNames[nc], ATOMrec,
          MT, ncA, sse);
    }

    if (heads->headSheet != NULL) {
      fill_sse(heads->headSheet, &Erecord, pdb->chainNames[nc], ATOMrec,
          MT, ncA, sse);
    }

    if (pargs->turn == 1 && heads->headTurn != NULL) {
      fill_sse(heads->headTurn, &Trecord, pdb->chainNames[nc], ATOMrec,
          MT, ncA, sse);
    }

    /*printf("sse = [%s]\n", sse);*/
    remove_tags_from_sse(pdb->chain_nres[nc], sse);
    /*printf("sse = [%s]\n", sse);*/
    if (pargs->separate_sse == 1) {
      pdb->sep_sse_count[nc] = check_sse_separation(pdb->chain_nres[nc], sse);
    }
    /*printf("sse = [%s]\n", sse);*/
    if (pargs->remove_sse == 1) {
      pdb->rem_sse_count[nc] = check_sse_length(pdb->chain_nres[nc], sse,
          pargs->length_H, pargs->length_b);
    }
    /*printf("sse = [%s]\n", sse);*/

    /*
     * Create a secondary structure array corresponding
     * to the residues in SEQRES records.
     */
    anr = 0;
    for (nr = 0; nr < pdb->chain_nres[nc]; nr++) {
      if (pdb->ali[nc][nr] == '-') {
        pdb->sse[nc][nr] = 'X';
        pdb->SEQRESnumres[nc][nr] = -1;
        pdb->SEQRESiCode[nc][nr] = '�';
      } else {
        pdb->sse[nc][nr] = sse[anr];
        if (MT->numres[ncA] != NULL) {
          pdb->SEQRESnumres[nc][nr] = MT->numres[ncA][anr];
        }
        if (MT->iCode[ncA] != NULL) {
          pdb->SEQRESiCode[nc][nr] = MT->iCode[ncA][anr];
        }
        anr++;
      }
    }
    pdb->sse[nc][pdb->chain_nres[nc]] = '\0';
    pdb->SEQRESiCode[nc][pdb->chain_nres[nc]] = '\0';

    FREE(sse);
  } /* End of loop index nc */
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Structure SSErecord (rc) contains indices used to scan the buffer line 
 * in structure NODE and retrieve various items.
 * For instance the chain Id of the SSE initial residue (initChainId) can 
 * be found in: nd->line[rc->initChainId], etc.
 *
 * Structure NODE (headSSE) is a linked list that contains SSE records
 * read in the PDB file.
 *
 */
static void fill_sse(struct NODE *headSSE, struct SSErecord *rc, char chainId,
    struct RecordTransfer *ATOMrec, struct MiscTransfer *MT, int ncA,
    char *sse)
{
  struct NODE *nd;
  struct SSE_DESC *SSE = NULL;
  int ir, inSSE;
  int Nnodes;
  int nsse;
  int is, flag;
  int lastGoodEndSeqNum = 0, GoodEndSeqNum = 0;

/*
 * Allocate memory for storing the numbering of starting and ending residues 
 */
  Nnodes = 1;
  nd = headSSE->next;
  while (nd != NULL) {
    Nnodes++;
    nd = nd->next;
  }

  CALLOC(SSE, 1);
  ALLOC2(SSE->initResName, Nnodes, 4);
  ALLOC(SSE->initSeqNum, Nnodes);
  ALLOC(SSE->initIcode, Nnodes);
  ALLOC2(SSE->endResName, Nnodes, 4);
  ALLOC(SSE->endSeqNum, Nnodes);
  ALLOC(SSE->endIcode, Nnodes);

/*
 * Transfer the relevant data from the linked list to the structure SSE
 */
  nsse = 0;
  for (nd = headSSE; nd != NULL; nd = nd->next) {
    if (nd->line[rc->initChainId] != nd->line[rc->endChainId]) {
      fprintf(stderr, "Warning: the following %s starts in a chain and "
          "ends in another ==> %s\n", rc->sseName, nd->line);
      continue;
    }

  /*
   * Get SSEs only for the selected chain
   */
    if (nd->line[rc->initChainId] == chainId) {
      strncpy(SSE->initResName[nsse], nd->line + rc->initResName, 3);
      SSE->initResName[nsse][3] = '\0';
      sscanf(nd->line + rc->initSeqNum, "%d", SSE->initSeqNum + nsse);
      SSE->initIcode[nsse] = nd->line[rc->initIcode];
      strncpy(SSE->endResName[nsse], nd->line + rc->endResName, 3);
      SSE->endResName[nsse][3] = '\0';
      sscanf(nd->line + rc->endSeqNum, "%d", SSE->endSeqNum + nsse);
      SSE->endIcode[nsse] = nd->line[rc->endIcode];
      nsse++;
    }
  } /* End of loop index nd */

/*
 * Transfer the SSEs to array sse and check that there is no
 * pair of SSEs immediatly following each other in the sequence.
 * Later on, when all SSEs have been processed,
 * the longest SSE will be shortened by one residue in order to
 * let 1 coil between them.
 */
  for (is = 0; is < nsse; is++) {
    inSSE = 0;
    flag = 0;
    for (ir = 0; ir < ATOMrec->chain_nres[ncA]; ir++) {

    /*
     * Check for the beginning of a SSE
     */
      if (SSE->initSeqNum[is] == MT->numres[ncA][ir] &&
          SSE->initIcode[is] == MT->iCode[ncA][ir]) {

      /*
       * At the beginning of each new SSE check that there exists 
       * at least 1 coil between this SSE and the previous one.
       * Note: this is done for strands (b) and helices (H)
       * but not for turns (T).
       */
        inSSE = 1;
        if (residue_type(SSE->initResName[is]) != ATOMrec->seq[ncA][ir]) {
          Erreur(0, "Warning: For chain '%c' and residue number %d, residue "
              "in %s record is %s and in sequence is %c: trusting sequence!\n",
              chainId, ir + 1, rc->sseName, SSE->endResName[is],
              ATOMrec->seq[ncA][ir]);
          strcpy(SSE->endResName[is], aa1_to_aa3(ATOMrec->seq[ncA][ir]));
        }
        /*
         * If two consecutive SSEs are of the same type put flag to 1
         */
        if (ir > 0 && sse[ir - 1] == rc->symbol) {
          flag = 1;
        }
      }

    /*
     * If the current residue is located in a SSE,
     * write the corresponding symbol in array sse
     */
      if (inSSE) {
        if (flag == 1) {
          /*
           * If flag = 1, tag the beginning of the SSE
           */
          sse[ir] = '>';
          flag = 0;
        } else if ((SSE->initSeqNum[is] < SSE->endSeqNum[is])
            && sse[ir] != 'H' && sse[ir] != 'b') {

/*
 * Lots of files are badly annotated . In order to avoid abberant records :
 * 1. make sure SeqNum are relevants ie initSeqNum < endSeqNum
 * 2. avoid re-definition of SSE which is another error in annotations
 * 3. for Helix fields, initSeqNum must be superior to the endSeqNum of
 *    the last correct helix
 * 4. for SHEET fields maximum length of a valid strand is 49
 */
          if (rc->symbol != 'H'
              && (abs(SSE->initSeqNum[is] - SSE->endSeqNum[is]) < 50)) {
            sse[ir] = rc->symbol;
          } else if (rc->symbol == 'H'
              && SSE->initSeqNum[is] >= lastGoodEndSeqNum) {
            sse[ir] = rc->symbol;
            GoodEndSeqNum = SSE->endSeqNum[is];
          }
        }
      }

    /*
     * Check for the end of a SSE
     */
      if (SSE->endSeqNum[is] == MT->numres[ncA][ir] &&
          SSE->endIcode[is] == MT->iCode[ncA][ir]) {

      /*
       * At the end of each new SSE check that there exists 
       * at least 1 coil between this SSE and the next one.
       * Note: this is done for strands (b) and helices (H)
       * but not for turns (T).
       */
        lastGoodEndSeqNum = GoodEndSeqNum;

        inSSE = 0;
        if (residue_type(SSE->endResName[is]) != ATOMrec->seq[ncA][ir]) {
          Erreur(0, "Warning: For chain '%c' and residue number %d, residue "
              "in %s record is %s and in sequence is %c: trusting sequence!\n",
              chainId, ir + 1, rc->sseName, SSE->endResName[is],
              ATOMrec->seq[ncA][ir]);
          strcpy(SSE->endResName[is], aa1_to_aa3(ATOMrec->seq[ncA][ir]));
        }
      }
    } /* End of loop index ir */
  } /* End of loop index is */

  FREE(SSE->initResName);
  FREE(SSE->initSeqNum);
  FREE(SSE->initIcode);
  FREE(SSE->endResName);
  FREE(SSE->endSeqNum);
  FREE(SSE->endIcode);
  FREE(SSE);
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Remove tags ('>' = beginning of SSE) to shorten the longest SSE
 */
static void remove_tags_from_sse(int chain_nres, char *sse)
{
  int nr, prev_len, curr_len;

  for (nr = 0; nr < chain_nres; nr++) {
    if (sse[nr] == '>') {
/*
 * Yeah yeah yeah, I've seen PDB definition of an alpha helix of size 1
 * in the very last residue like in 1rwy B!!!!
 */
      if (nr == (chain_nres - 1)) {
        sse[nr] = '.';
        continue;
      }

      prev_len = calculate_previous_sse_length(sse, nr - 1, sse[nr - 1]);
/*
      printf("RTFS: nr = %5d, sse = '%c', prev_len = %3d\n",
          nr, sse[nr - 1], prev_len);
*/
      curr_len = 1 + calculate_current_sse_length(sse, nr + 1, sse[nr + 1]);
/*
      printf("RTFS: nr = %5d, sse = '%c', curr_len = %3d\n",
          nr, sse[nr + 1], curr_len);
*/
      curr_len++; /* the length of the tag */
      /*
       * NOTE: shorten the current SSE preferentially because it
       *       can be compared again with the next one, which is
       *       obviously not the case for the previous SSE.
       */
      if (curr_len >= prev_len) {
        sse[nr] = '.';
      } else {
        sse[nr - 1] = '.';
        sse[nr] = sse[nr + 1];
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Check the case where 2 SSEs are contiguous.
 * The longest SSE is shortened by one residue and replaced by a coil
 * to insure that all SSEs are 'isolated'.
 * Return the number of times the operation has been done.
 */
static int check_sse_separation(int chain_nres, char *sse)
{
  int prevSSE;  /**< Previous symbol in array sse */
  int currLen;  /**< Length of the current SSE */
  int prevLen;  /**< Length of the previous SSE */
  int nr;       /**< Number of residues */
  int warning;  /**< Number of separations done */

  prevSSE = '\0';
  currLen = 0;
  prevLen = 0;
  warning = 0;
  for (nr = 0; nr < chain_nres; nr++) {
    if (sse[nr] == 'b') {
      if (prevSSE == 'H') {
        currLen = calculate_current_sse_length(sse, nr, 'b');
/*
        printf("1/ nr = %5d, sse = '%c', prevSSE = '%c', prevLen = %3d, "
            "currLen = %3d\n", nr, sse[nr], prevSSE, prevLen, currLen);
*/
        if (currLen > prevLen) {
          sse[nr] = '.';
          prevLen = 0;
        } else {
          sse[nr - 1] = '.';
          prevLen = 1;
        }
        warning++;
      } else {
        prevLen++;
      }
    } else if (sse[nr] == 'H') {
      if (prevSSE == 'b') {
        currLen = calculate_current_sse_length(sse, nr, 'H');
/*
        printf("2/ nr = %5d, sse = '%c', prevSSE = '%c', prevLen = %3d, "
            "currLen = %3d\n", nr, sse[nr], prevSSE, prevLen, currLen);
*/
        if (currLen >= prevLen) {
          sse[nr] = '.';
          prevLen = 0;
        } else {
          sse[nr - 1] = '.';
          prevLen = 1;
        }
        warning++;
      } else {
        prevLen++;
      }
    } else if (sse[nr] == '.' || sse[nr] == 'X') {
      prevLen = 0;
    } else {
      ERROR_TAG;
      Erreur(1, "Error: Unknown secondary structure '%c'\n", sse[nr]);
    }
    prevSSE = sse[nr];
  }

  return warning;
}

/*******************************************************************************
 *
 ******************************************************************************/
static int calculate_current_sse_length(char *sse, int nr, char c)
{
  int length = 0;

  while (sse[nr] == c) {
    length++;
    nr++;
  }

  return length;
}

/*******************************************************************************
 *
 ******************************************************************************/
static int calculate_previous_sse_length(char *sse, int nr, char c)
{
  int length = 0;

  while (nr >= 0 && sse[nr] == c) {
    length++;
    nr--;
  }

  return length;
}

/*******************************************************************************
 *
 ******************************************************************************/
static int check_sse_length(int chain_nres, char *sse, int length_H,
    int length_b)
{
  int i, nr, sse_len, warning;

  warning = 0;
  for (nr = 0; nr < chain_nres; nr++) {
    if (sse[nr] == 'b') {
      sse_len = calculate_current_sse_length(sse, nr, 'b');
/*
      printf("CSL: nr = %5d, sse = '%c', sse_len = %3d\n",
          nr, 'b', sse_len);
*/
      if (sse_len < length_b) {
        for (i = 0; i < sse_len; i++) {
          sse[nr + i] = '.';
        }
        warning++;
      }
      nr += sse_len;
    } else if (sse[nr] == 'H') {
      sse_len = calculate_current_sse_length(sse, nr, 'H');
/*
      printf("CSL nr = %5d, sse = '%c', sse_len = %3d\n",
          nr, 'H', sse_len);
*/
      if (sse_len < length_H) {
        for (i = 0; i < sse_len; i++) {
          sse[nr + i] = '.';
        }
        warning++;
      }
      nr += sse_len;
    }
  }

  return warning;
}
