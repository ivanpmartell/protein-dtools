/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#ifndef _ALLOC_H
#define _ALLOC_H 1

/*! \file erreur.h
 * allocation defines
 */
#include "erreur.h"

/*! \def S(x)
 * Stringize operator # : returns a character string corresponding to
 * the name of a variable 
 */
#define S(x) #x

/*! \def ALLOC
 * Memory allocation below refers, for instance, to the following case
 * int *toto;
 * int nel = 10;
 * statement: ALLOC(toto,nel); is equivalent to 
 * statement: toto = malloc((size_t) nel * sizeof(*toto));
 * 
 */
#define ALLOC(ptr,nelem) {\
  (ptr) = malloc((size_t) (nelem) * sizeof(*ptr));\
  if((ptr) == NULL)  {\
    fprintf(stderr, "Error: %s in file %s at line %d: Unable to allocate memory for %s\n", __FUNCTION__, __FILE__, __LINE__, S(ptr));\
    exit(EXIT_FAILURE);\
  }\
}

/*! \def ALLOC2
 * Allocate a two dimensions array.
 * It only uses two malloc calls.
 */
#define ALLOC2(ptr, nelem1, nelem2) {\
  int alloc2_i;\
  CALLOC((ptr), (nelem1))\
  ALLOC((ptr)[0], (nelem1) * (nelem2))\
  for (alloc2_i = 1; alloc2_i < (nelem1); alloc2_i++) {\
    (ptr)[alloc2_i] = (ptr)[alloc2_i - 1] + (nelem2);\
  }\
}

/*! \def ALLOC3
 * Allocate a three dimensions array
 * It only uses three malloc calls.
 */
#define ALLOC3(ptr, nelem1, nelem2, nelem3) {\
  int alloc3_i;\
  CALLOC2((ptr), (nelem1), (nelem2))\
  ALLOC((ptr)[0][0], (nelem1) * (nelem2) * (nelem3))\
  for (alloc3_i = 1; alloc3_i < ((nelem1) * (nelem2)); alloc3_i++) {\
    (ptr)[0][alloc3_i] = (ptr)[0][alloc3_i - 1] + (nelem3);\
  }\
}

/*! \def CALLOC
 * Same as ALLOC but for CALLOC
 */
#define CALLOC(ptr, nelem) {\
  if ((ptr) != NULL) {\
    fprintf(stderr, "Warning: Allocating (calloc) a non NULL pointer!\n");\
  }\
  (ptr) = calloc((size_t) (nelem), sizeof(*ptr));\
  if ((ptr) == NULL) {\
    fprintf(stderr, "Error: Unable to allocate (calloc) memory (%d bytes) for %s\n",\
        (nelem) * sizeof(*ptr), S(ptr));\
    exit(EXIT_FAILURE);\
  }\
}

/*! \def CALLOC2
 * Same as ALLOC2 but for CALLOC
 */
#define CALLOC2(ptr, nelem1, nelem2) {\
  int calloc2_i;\
  CALLOC((ptr), (nelem1))\
  CALLOC((ptr)[0], (nelem1) * (nelem2))\
  for (calloc2_i = 1; calloc2_i < (nelem1); calloc2_i++) {\
    (ptr)[calloc2_i] = (ptr)[calloc2_i - 1] + (nelem2);\
  }\
}

/*! \def ALLOC3
 * Same as ALLOC3 but for CALLOC
 */
#define CALLOC3(ptr, nelem1, nelem2, nelem3) {\
  int calloc3_i;\
  CALLOC2((ptr), (nelem1), (nelem2))\
  CALLOC((ptr)[0][0], (nelem1) * (nelem2) * (nelem3))\
  for (calloc3_i = 1; calloc3_i < ((nelem1) * (nelem2)); calloc3_i++) {\
    (ptr)[0][calloc3_i] = (ptr)[0][calloc3_i - 1] + (nelem3);\
  }\
}

/*! \def FOPEN
 * Redefine fopen to include error check
 */
#define FOPEN(fp,fich,mode) { fp = fopen(fich,mode); \
        if(fp == NULL) { Erreur(1, "Unable to open file %s\n",fich); } }

/*! \def FREE
 * Redefine free to include warning check
 */
#define FREE(p) {\
  if (p == NULL) {\
    fprintf(stderr, "Warning: Trying to free a NULL pointer: %s\n", S(p));\
  } else {\
    free(p);\
    p = NULL;\
  }\
}

/*! \def FREE2
 * Free an array allocated with (C)ALLOC2
 */
#define FREE2(ptr) {\
  if ((ptr) == NULL) {\
    fprintf(stderr, "Warning: Trying to free a NULL pointer: %s\n", S(ptr));\
  } else {\
    FREE((ptr)[0])\
    FREE(ptr)\
  }\
}

/*! \def FCLOSE
 * Redefine fclose to include warning check
 */
#define FCLOSE(fp) {\
  if (fp == NULL) {\
    fprintf(stderr, "Warning: Trying to close a NULL file pointer: %s\n", S(fp));\
  } else {\
    fclose(fp);\
    fp = NULL;\
  }\
}

/*
 * When there is an exit dur to a fatal error print where
 * (function, file, line) at which this error occurred.
 */
#define ERROR_TAG fprintf(stderr,"Function %s in file %s at line %d:\n", \
    __FUNCTION__,__FILE__,__LINE__)

#endif /* alloc.h */
