/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Read a PDB file and store it in PDB data structure.
 * All atoms are read in.
 */
void Read_PDB(ppf_args_t *args, pdb_t *pdb, struct NODES *heads,
    struct CHUNK **headchunk, struct RecordTransfer *SEQRESrec,
    struct RecordTransfer *ATOMrec, struct MiscTransfer *MT)
{
  FILE *fp = NULL;
  char buffer[BUFSIZ];
  int i, nat;
  struct CHUNK *chunk = NULL;
  struct NODE *qTurn = NULL, *qSheet = NULL, *qHelix = NULL;
  char prevchainId1 = '\0', prevchainId2 = '\0', chainId;
  int ncS = 0, ncA = 0;
  char tmp[6];

  FOPEN(fp, args->pdb_fname, "r");

/*
 * Count number of atoms
 */
  nat = 0;
  while (fgets(buffer, BUFSIZ, fp) != NULL) {
  /*
   * Stop reading ATOM records after the first model if several models exist
   */
    if (strncmp(buffer, "ENDMDL", 6) == 0) {
      break;
    }
    if ((strncmp(buffer, "ATOM", 4) == 0 || strncmp(buffer, "HETATM", 6) == 0)
        && strncmp(buffer + 17, "ACE", 3) != 0
        && strncmp(buffer + 17, "NH2", 3) != 0) {
      nat++;
    }
  }
  pdb->nat = nat;

/*
 * Allocate memory depending on the number of atoms
 */
  ALLOC(pdb->numatom, nat);
  ALLOC2(pdb->atomtype, nat, 7);
  ALLOC2(pdb->atomname, nat, 5);
  ALLOC2(pdb->resname, nat, 4);
  ALLOC(pdb->chainID, nat);
  ALLOC(pdb->altLoc, nat);
  ALLOC(pdb->iCode, nat);
  ALLOC(pdb->numres, nat);
  ALLOC2(pdb->coo, nat, 3);
  ALLOC(pdb->tfactor, nat);
  ALLOC(pdb->occupancy, nat);

/*
 * Store atom fields
 */
  rewind(fp);
  nat = 0;
  while (fgets(buffer, BUFSIZ, fp) != NULL) {
  /*
   * Stop reading ATOM records after the first model if several models exist
   */
    if (strncmp(buffer, "ENDMDL", 6) == 0) {
      break;
    }
/*
 * HEADER
 */
    if (strncmp(buffer, "HEADER", 6) == 0) {
      if (strcmp(args->pdb_code, "void") == 0) {
        sscanf(buffer + 62, "%s", pdb->pdb_code);
        string_tolower(pdb->pdb_code);
        strcpy(args->pdb_code, pdb->pdb_code);
      } else {
        strcpy(pdb->pdb_code, args->pdb_code);
      }
/*
 * HELIX
 */
    } else if (strncmp(buffer, "HELIX ", 6) == 0) {
      if (heads->headHelix == NULL) {
        ALLOC(heads->headHelix, 1);
        qHelix = heads->headHelix;
      } else {
        ALLOC(qHelix->next, 1);
        qHelix = qHelix->next;
      }
      ALLOC(qHelix->line, strlen(buffer) + 1);
      strcpy(qHelix->line, buffer);
      qHelix->next = NULL;
/*
 * SHEET
 */
    } else if (strncmp(buffer, "SHEET ", 6) == 0) {
      if (heads->headSheet == NULL) {
        ALLOC(heads->headSheet, 1);
        qSheet = heads->headSheet;
      } else {
        ALLOC(qSheet->next, 1);
        qSheet = qSheet->next;
      }
      ALLOC(qSheet->line, strlen(buffer) + 1);
      strcpy(qSheet->line, buffer);
      qSheet->next = NULL;
/*
 * TURN
 */
    } else if (strncmp(buffer, "TURN  ", 6) == 0) {
      if (heads->headTurn == NULL) {
        ALLOC(heads->headTurn, 1);
        qTurn = heads->headTurn;
      } else {
        ALLOC(qTurn->next, 1);
        qTurn = qTurn->next;
      }
      ALLOC(qTurn->line, strlen(buffer) + 1);
      strcpy(qTurn->line, buffer);
      qTurn->next = NULL;
/*
 * SEQRES
 */
    } else if (strncmp(buffer, "SEQRES", 6) == 0) {
      if (ncS == 0) {
        ALLOC(chunk, 1);
        (*headchunk) = chunk;
      } else {
        ALLOC(chunk->next, 1);
        chunk = chunk->next;
      }
      chainId = buffer[11];
      if (chainId != prevchainId1) {
        ncS++;
        prevchainId1 = chainId;
      }
      chunk->chainId = chainId;
      sscanf(buffer + 12, "%d", &(chunk->nres));
      strncpy(chunk->line, buffer + 19, 52);
      chunk->next = NULL;
/*
 * ATOM
 */
    } else if ((strncmp(buffer, "ATOM", 4) == 0 || strncmp(buffer, "HETATM", 6) == 0)
        && strncmp(buffer + 17, "ACE", 3) != 0
        && strncmp(buffer + 17, "NH2", 3) != 0) {
      chainId = buffer[21];
      if (chainId != prevchainId2) {
        prevchainId2 = chainId;
        ncA++;
      }
      strncpy(pdb->atomtype[nat], buffer, 6);
      pdb->atomtype[nat][6] = '\0';
      strncpy(tmp, buffer + 6, 5);
      tmp[5] = '\0';
      pdb->numatom[nat] = atoi(tmp);
      strncpy(pdb->atomname[nat], buffer + 12, 4);
      pdb->atomname[nat][4] = '\0';
      strncpy(pdb->resname[nat], buffer + 17, 3);
      pdb->resname[nat][3] = '\0';
      pdb->chainID[nat] = buffer[21];
      pdb->altLoc[nat] = buffer[16];
      pdb->iCode[nat] = buffer[26];
      sscanf(buffer + 22, "%d", &pdb->numres[nat]);
      sscanf(buffer + 29, "%lf %lf %lf %lf %lf", &pdb->coo[nat][0],
          &pdb->coo[nat][1], &pdb->coo[nat][2], &pdb->tfactor[nat],
          &pdb->occupancy[nat]);
      nat++;
    }
  }

  FCLOSE(fp);

/*
 * Allocate memory depending on the number of chains
 */
  SEQRESrec->Nchain = ncS;
  ALLOC(MT->nucleic, ncS);
  CALLOC(SEQRESrec->chainName, ncS + 1);
  ALLOC(SEQRESrec->chain_nres, ncS);
  ALLOC(MT->hetatmInSeqres, ncS);
  CALLOC(pdb->sep_sse_count, ncS);
  CALLOC(pdb->rem_sse_count, ncS);

  ATOMrec->Nchain = ncA;
  CALLOC(ATOMrec->chainName, ncA + 1);
  ALLOC(ATOMrec->chain_nres, ncA);
  ALLOC(MT->validATOMchains, ncA);
  for (i = 0; i < ncA; i++) {
    MT->validATOMchains[i] = 1;
  }
}
