/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "kaksi.h"
#include "parse_PDB_file.h"
#include "util.h"
#include "axis.h"

/*
 * parametres determines sur 2880 domaines de ASTRAL 1.63, identite inferieure
 * a 40, reso meilleure que 2.25, pas de sequences inferieires a 50 residus.
 */
#define DIST_MOY_H_COEUR_II2  5.49
#define DIST_SD_H_COEUR_II2 0.20
#define DIST_MOY_H_EXT_II5 8.72
#define DIST_SD_H_EXT_II5 0.63
#define DIST_MOY_H_EXT_II2 5.54
#define DIST_SD_H_EXT_II2 0.25
#define DIST_MOY_H_COEUR_II3 5.30
#define DIST_SD_H_COEUR_II3 0.64
#define DIST_MOY_H_EXT_II3 5.36
#define DIST_SD_H_EXT_II3 0.39
#define DIST_MOY_H_EXT_II4 6.33
#define DIST_SD_H_EXT_II4 0.71

#define DIST_MOY_B_INTRA_EXT_II2 6.70
#define DIST_SD_B_INTRA_EXT_II2 0.32

#define DIST_MOY_B_PARA_FRONT_COEUR 4.84
#define DIST_SD_B_PARA_FRONT_COEUR 0.24
#define DIST_MOY_B_PARA_FRONT_EXT 4.83
#define DIST_SD_B_PARA_FRONT_EXT 0.29
#define DIST_MOY_B_PARA_INTER_EXT_II1 6.07
#define DIST_SD_B_PARA_INTER_EXT_II1 0.35

#define DIST_MOY_B_ANTI_FRONT_EXT 4.77
#define DIST_SD_B_ANTI_FRONT_EXT 0.42
#define DIST_MOY_B_ANTI_FRONT_COEUR 4.88
#define DIST_SD_B_ANTI_FRONT_COEUR 0.43
#define DIST_MOY_B_ANTI_INTER_EXT_II1 6.00
#define DIST_SD_B_ANTI_INTER_EXT_II1 0.47

#define SEUILHI    20
#define SEUIL_RAMA 50
#define SEUILT	   6.8

/*For ex-FORTRAN subroutine for axes computation */
#define MAXVEC     200 /* Max number of vectors in a protein */
#define ANGLE      25.0 /* if the angle between 2 consecutives axes (same SSE type) is less */
/* than this value the two axes are collapsed into a single one. */

/*******************************************************************************
 * LOCAL FUNCTIONS
 ******************************************************************************/
void Fill_counters(int *densityRamaHelix, int *densityRamaStrand,
    int helixMat[36][36], int strandMat[36][36], double Phi, double Psi,
    int seqIndex);
void Fill_SSE(int *densityRamaHelix, int *densityRamaStrand,
    struct SEQUENCE *sseSeq, struct PHIPSI *PhiPsi,
    struct SEQUENCE *strandOrient, char **contact, ppf_args_t *pargs,
    kaksi_args_t *args, double **coo_CA, int nCA);
void vect(double **coo_CA, int a, int b, double *vector);
int intervalle(double D, double M, double borne);
int Is_in_ext(int j, struct SEQUENCE *sseSequence, char c);
int Is_in_heart(int j, struct SEQUENCE *sseSequence, char c);
int Is_in_inter(int j, struct SEQUENCE *sseSequence, char c);
int Is_in_C_ext(int j, struct SEQUENCE *sseSequence, char c);
int Is_in_N_ext(int j, struct SEQUENCE *sseSequence, char c);
int Is_valid_angle(struct PHIPSI *PhiPsi, int index);
int Is_struct_seg(struct SEQUENCE *sseSeq, int debut, int fin, char structure);
double distance_Rama(struct PHIPSI *PhiPsi, int index1, int index2);
int Check_local_minimum(double **dist, int i, int j, int length,
    struct SEQUENCE *sseSeq);

/******************************************************************************
 *
 ******************************************************************************/
void Assign_SSE(struct PHIPSI *PhiPsi,
    int helixMat[36][36], int strandMat[36][36], struct SEQUENCE *sseSeq,
    struct SEQUENCE *strandOrient, char **contact, ppf_args_t *pargs,
    kaksi_args_t *args, double **coo_CA, int nCA)
{
  int j, i;
  int *densityRamaHelix, *densityRamaStrand; /* densityRamaHelix[i] : density in the ramaplot of helices for residu i */

  ALLOC(densityRamaHelix, sseSeq->length);
  ALLOC(densityRamaStrand, sseSeq->length);

  /*initialization to -2 = PAIR of diedral angles not defined (sequence extremity) */
  for (j = 0; j < sseSeq->length; j++) {
    densityRamaHelix[j] = -2;
    densityRamaStrand[j] = -2;
    if (PhiPsi->Phi[j] <= 180 || PhiPsi->Psi[j] <= 180) {
      densityRamaHelix[j] = -1;
      densityRamaStrand[j] = -1; /* -1 means that one of the angles is available (chain extremity) */
      sseSeq->seq[j] = '.';
    }
    if (PhiPsi->Phi[j] <= 180 && PhiPsi->Psi[j] <= 180)
      Fill_counters(densityRamaHelix, densityRamaStrand, helixMat, strandMat,
          PhiPsi->Phi[j], PhiPsi->Psi[j], j);
  }

  /*contact table for beta interactions, to be filled during the detection : a for anti sheet, p for parallel sheet */
  for (j = 0; j < sseSeq->length; j++) {
    for (i = 0; i < sseSeq->length; i++) {
      contact[i][j] = '.';
    }
  }

  Fill_SSE(densityRamaHelix, densityRamaStrand, sseSeq, PhiPsi,
      strandOrient, contact, pargs, args, coo_CA, nCA);

  FREE(densityRamaHelix);
  FREE(densityRamaStrand);
}

/*******************************************************************************
 *
 ******************************************************************************/
void Fill_counters(int *densityRamaHelix, int *densityRamaStrand,
    int helixMat[36][36], int strandMat[36][36], double Phi, double Psi,
    int seqIndex)
{
  int a, b;

  a = ceil(Phi / 10) + 17; /* smallest integer greater or equal to Phi */
  if (Phi == -180)
    a = 35; /*Phi=-10 a=16, Phi=-5 a=17,  Phi=0 a=17, Phi=5 a=17, Phi=10 a=18, Phi=-5 a=17 */

  b = ceil(Psi / 10) + 17;
  if (Psi == -180)
    b = 35;
  densityRamaHelix[seqIndex] = helixMat[a][b];
  densityRamaStrand[seqIndex] = strandMat[a][b];
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 *  SSE Detection : 
 * 1 Helice Dectection with Phi/Psi angles and CC distances  (5 steps)
 * 2 Turn Detection with CC distances (keep it appart)
 * 3 Correction for Hb or bH
 * 4 Beta Sheet Detection  Phi/Psi angles and CC distances
 * 5 Length Correction : remove Helices and strands that are too short
 * 6 Add Turns to the Final Sequence (if turn detection is desired)
 *
 * R if only one angle is missing, assignation is coil
 */
void Fill_SSE(int *densityRamaHelix, int *densityRamaStrand,
    struct SEQUENCE *sseSeq, struct PHIPSI *PhiPsi,
    struct SEQUENCE *strandOrient, char **contact, ppf_args_t *pargs,
    kaksi_args_t *args, double **coo_CA, int nCA)
{
  int i, j, j1, j2, k;          /* index for helix/strand/turn detection */
  int jcorr, currentLength;     /* index for length correction */
  int testH = 0, testB = 0;     /* count the criteria fitting */
  double vector1[3], vector2[3], scal; /* for beta-sheet orientation */
/* for the axis routine */
  int maxvec = MAXVEC;
  int **nsegment = NULL;
  int nsse, lensse[2];          /* Minimum length for periodic SSEs */
  double angle = ANGLE;         /* Above this angular value we have a bent SSE that is thus described by 2 axes */
  int **SSE_corresp = NULL;
  int SSE_corresp_size;
  int nvect;
  int **lmstore = NULL;
  double **pstore1 = NULL, **pstore2 = NULL, **fstore = NULL;
  int ierr = 0, modecorrec, turn;
  struct SEQUENCE newSeq;
  char *turnSeq = NULL;
/*
 * Inter C alpha distances in angstrom,
 * used for alpha / strand / turn detection
 */
  double **dist = NULL;
  double beta_dist_thresh, alpha_dist_thresh, beta_angle_thresh;

  lensse[0] = pargs->length_H;
  lensse[1] = pargs->length_b;
  modecorrec = args->modecorrec;
  beta_dist_thresh = args->beta_dist_thresh;
  alpha_dist_thresh = args->alpha_dist_thresh;
  beta_angle_thresh = args->beta_angle_thresh;
  turn = pargs->turn;

  CALLOC2(dist, sseSeq->length, sseSeq->length);

  for (i = 0; i < sseSeq->length; i++) {
    if (coo_CA[i][0] > (double) -999) {
      for (j = i; j < sseSeq->length; j++) {
        if (coo_CA[j][0] > (double) -999) {
          dist[i][j] = dist[j][i] = distance3(coo_CA, i, j);
        }
      }
    }
  }

/*
 * 1 Helix Detection step 1
 * In a 6-residues long sliding window, detect segments with inter-Calpha
 * distances in favor of Helix, i.e all distances in the 95% intervalle
 * (mean +- 1.96 sd )
 */
  for (j = 0; j < sseSeq->length - 5; j++) {
    testH = 0;
    if (densityRamaHelix[j] >= 0 && densityRamaHelix[j + 1] >= 0 &&
        densityRamaHelix[j + 2] >= 0 && densityRamaHelix[j + 3] >= 0 &&
        densityRamaHelix[j + 4] >= 0 && densityRamaHelix[j + 5] >= 0) {
      testH = 0;
      if (intervalle(dist[j][j + 2], DIST_MOY_H_EXT_II2,
              alpha_dist_thresh * DIST_SD_H_EXT_II2))
        testH++;
      if (intervalle(dist[j + 1][j + 3], DIST_MOY_H_COEUR_II2,
              alpha_dist_thresh * DIST_SD_H_COEUR_II2))
        testH++;
      if (intervalle(dist[j + 2][j + 4], DIST_MOY_H_COEUR_II2,
              alpha_dist_thresh * DIST_SD_H_COEUR_II2))
        testH++;
      if (intervalle(dist[j + 3][j + 5], DIST_MOY_H_EXT_II2,
              alpha_dist_thresh * DIST_SD_H_EXT_II2))
        testH++;
      if (intervalle(dist[j][j + 3], DIST_MOY_H_EXT_II3,
              alpha_dist_thresh * DIST_SD_H_EXT_II3))
        testH++;
      if (intervalle(dist[j + 1][j + 4], DIST_MOY_H_COEUR_II3,
              alpha_dist_thresh * DIST_SD_H_COEUR_II3))
        testH++;
      if (intervalle(dist[j + 2][j + 5], DIST_MOY_H_EXT_II3,
              alpha_dist_thresh * DIST_SD_H_EXT_II3))
        testH++;
      if (intervalle(dist[j][j + 4], DIST_MOY_H_EXT_II4,
              alpha_dist_thresh * DIST_SD_H_EXT_II4))
        testH++;
      if (intervalle(dist[j + 1][j + 5], DIST_MOY_H_EXT_II4,
              alpha_dist_thresh * DIST_SD_H_EXT_II4))
        testH++;
      if (intervalle(dist[j][j + 5], DIST_MOY_H_EXT_II5,
              alpha_dist_thresh * DIST_SD_H_EXT_II5))
        testH++;
      if (testH > 9)
        sseSeq->seq[j] = sseSeq->seq[j + 1] = sseSeq->seq[j + 2] =
            sseSeq->seq[j + 3] = sseSeq->seq[j + 4] = sseSeq->seq[j + 5] = 'H';
    }
  }

/*
 * 1 Helix Detection step 2
 * In a 4-residues long sliding window, detect segments with all Phi/Psi
 * pairs in the helix zone, one of them must be in the high density zone
 */
  for (j = 0; j < sseSeq->length - 3; j++) {
    testH = 0;
    if (PhiPsi->Phi[j] < 0 && PhiPsi->Psi[j] < 60 && PhiPsi->Psi[j] > -90)
      testH++;
    if (PhiPsi->Phi[j + 1] < 0 && PhiPsi->Psi[j + 1] < 60 &&
        PhiPsi->Psi[j + 1] > -90)
      testH++;
    if (PhiPsi->Phi[j + 2] < 0 && PhiPsi->Psi[j + 2] < 60 &&
        PhiPsi->Psi[j + 2] > -90)
      testH++;
    if (PhiPsi->Phi[j + 3] < 0 && PhiPsi->Psi[j + 3] < 60 &&
        PhiPsi->Psi[j + 3] > -90)
      testH++;

    if (testH == 4) {
      if (densityRamaHelix[j] >= SEUILHI || densityRamaHelix[j + 1] >= SEUILHI
          || densityRamaHelix[j + 2] >= SEUILHI ||
          densityRamaHelix[j + 3] >= SEUILHI)
        sseSeq->seq[j] = sseSeq->seq[j + 1] = sseSeq->seq[j + 2] =
            sseSeq->seq[j + 3] = 'H';
    }
  }

/*
 * 1 Helix Detection step 3
 * Break an helice if the euclidian distance in the rama plot between two
 * paires is upper then a threshold
 */
  if (modecorrec == 1 || modecorrec == 3) { /* edit� par Guillaume */
    for (j = 0; j < sseSeq->length; j++) {
      if (Is_valid_angle(PhiPsi, j) == 0 && Is_valid_angle(PhiPsi, j + 1) == 0
          && Is_valid_angle(PhiPsi, j + 2) == 0) {
        if (sseSeq->seq[j] == 'H' && sseSeq->seq[j + 1] == 'H' &&
            sseSeq->seq[j + 2] == 'H' && Is_in_heart(j + 1, sseSeq, 'H') == 0 &&
            Is_in_ext(j, sseSeq, 'H') == 1 && Is_in_ext(j + 2, sseSeq, 'H') == 1
            && (distance_Rama(PhiPsi, j, j + 1) + distance_Rama(PhiPsi, j + 2,
                    j + 1)) > (2.25 * SEUIL_RAMA)) {
          sseSeq->seq[j + 1] = '.';
        }
      }
    }
  }

/*
 * 1 Helix Detection step 4
 * delete helices shorter than length_H
 */
  currentLength = 0;
  for (j = 0; j < sseSeq->length; j++) {
    if (sseSeq->seq[j] == 'H') {
      currentLength++;
      if ((j < sseSeq->length - 1 && sseSeq->seq[j + 1] != 'H') || (j == sseSeq->length - 1)) { /*end of a too short helix */
        if (currentLength > 0 && currentLength < pargs->length_H) {
          for (jcorr = j; jcorr > (j - currentLength); jcorr--)
            sseSeq->seq[jcorr] = '.';
        }
        currentLength = 0;
      }
    }
  }

/*
 * 1 Helix Detection step 5
 * axes correction : break or merge helices, based on main axis calculation
 */
  if (modecorrec == 2 || modecorrec == 3) { /* edit� par Guillaume */
    nvect = 0;
    for (j = 0; j < sseSeq->length; j++) {
      if ((j == 0 && sseSeq->seq[j] == 'H') || (j > 0 &&
              sseSeq->seq[j - 1] != 'H' && sseSeq->seq[j] == 'H'))
        nvect++;
    }

    if (nvect > 0) {
      ALLOC2(nsegment, nvect, 3);
      i = 0;
      for (j = 0; j < sseSeq->length; j++) {
        if ((j == 0 && sseSeq->seq[j] == 'H') || (j > 0 &&
                sseSeq->seq[j - 1] != 'H' && sseSeq->seq[j] == 'H')) {
          nsegment[i][0] = j;
        }
        if ((j == sseSeq->length - 1 && sseSeq->seq[j] == 'H')
            || (j < sseSeq->length - 1 && sseSeq->seq[j] == 'H' &&
                sseSeq->seq[j + 1] != 'H')) {
          nsegment[i][1] = j;
          nsegment[i][2] = 1;
          i++;
        }
      }
      if (nvect != i) {
        Erreur(1, "Error: When checking for SSE axes, cannot find "
            "the right number of element %d %d...\n", nvect, i);
      }

      ALLOC2(SSE_corresp, maxvec, 2);
      ALLOC2(lmstore, maxvec, 4);
      ALLOC2(pstore1, maxvec, 3);
      ALLOC2(pstore2, maxvec, 3);
      ALLOC2(fstore, maxvec, 2);

      nsse = nvect;
      axis_(&maxvec, nsegment[0], &nsse, coo_CA[0], nCA, lensse, &angle,
          SSE_corresp[0], &SSE_corresp_size, &nvect, lmstore[0], pstore1[0],
          pstore2[0], fstore[0], &ierr);

      /*fprintf(stderr,"Correspondence between SSEs before and after subroutine axis \n"); */
      for (j = 1; j < nvect; j++) {
        /*fprintf(stderr," old = %d new=%d \n",  SSE_corresp[j][0], SSE_corresp[j][1]);  
           fprintf(stderr," debut et fin : %d %d \n", lmstore[j][0] , lmstore[j][1]); */
        if (lmstore[j][0] == lmstore[j - 1][1] + 1) {
          /*fprintf(stderr, " 2 consecutive helices \n"); */
          /*shorten the longer one */
          if ((lmstore[j][1] - lmstore[j][0]) >
              (lmstore[j - 1][1] - lmstore[j - 1][0]))
            /*the second one is longer */
            lmstore[j][0] += 1;

          else
            lmstore[j - 1][1] -= 1;
        }
      }
/*
      for(j=0; j<nvect; j++) {
        fprintf(stderr," old = %d new=%d \n",  SSE_corresp[j][0],
            SSE_corresp[j][1]);  
        fprintf(stderr," debut et fin : %d %d \n", lmstore[j][0] ,
            lmstore[j][1]); 
      }
*/
      if (ierr > 0) {
        switch (ierr) {
        case 1:
          fprintf(stderr,
              "ERROR increase the size of parameter maxatm in routine axis\n");
          break;
        case 2:
          fprintf(stderr,
              "ERROR increase the size of parameter maxvec in routine axis\n");
          break;
        case 3:
          fprintf(stderr,
              "ERROR increase the size of parameter mxkeep in routine axis\n");
          break;
        case 4:
          fprintf(stderr, "ERROR SSE appears to have only 1 residue!\n");
          break;
        default:
          fprintf(stderr, "ERROR in routine axis return code is %d\n", ierr);
          break;
        }
        exit(1);
      }

      i = 0;
      ALLOC(newSeq.seq, sseSeq->length + 1);
      newSeq.seq[sseSeq->length] = '\0';
      newSeq.length = sseSeq->length;
      for (j = 0; j < sseSeq->length; j++) {
        if (sseSeq->seq[j] != 'H')
          newSeq.seq[j] = sseSeq->seq[j];
        else
          (newSeq.seq[j] = '.');
        if (i < nvect) {
          if (j >= lmstore[i][0] && j <= lmstore[i][1])
            newSeq.seq[j] = 'H';

          if (j == lmstore[i][1])
            i++;
        }
      }
      if (i != nvect)
        Erreur(1, "Error: Not the right element of SSE\n");
      strcpy(sseSeq->seq, newSeq.seq); /* C ici que se fait le trasfert final */
    }
  }

/*
 * 2 Turn Detection with distances
 * only turns with 2 to 4 internal residus are implemented yet
 */
  ALLOC(turnSeq, sseSeq->length);
  for (j = 0; j < sseSeq->length; j++)
    turnSeq[j] = '-';


  for (i = 0; i < sseSeq->length; i++) {
    for (j = i + 3; j <= i + 5; j++) {
      if (Is_valid_angle(PhiPsi, i) == 0 && Is_valid_angle(PhiPsi, j) == 0) {
#ifdef LOG
        fprintf(stderr, " distance en %d %d : %lf\n", i, j, dist[i][j]);
        fprintf(stderr, " check helix is : %d \n", Is_struct_seg(sseSeq, i, j,
                'H'));
#endif
        if (dist[i][j] < SEUILT && dist[i][j] > 0 &&
            Is_struct_seg(sseSeq, i, j, 'H') == 1 &&
            Is_struct_seg(sseSeq, i, j, 'T') == 1) {
#ifdef LOG
          fprintf(stderr, " trouve distance en %d %d : %lf\n", i, j,
              dist[i][j]);
#endif
          if (Check_local_minimum(dist, i, j, PhiPsi->nCA, sseSeq) == 0) {
#ifdef LOG
            printf(" trouve un minimum en %d %d\n", i, j);
#endif
            if (turnSeq[i + 1] == '-') {
              turnSeq[i + 1] = 'T';
            }
            for (k = i + 2; k < j; k++) {
              if (turnSeq[k] == '-')
                turnSeq[k] = 't';
            }
          }
        }
      }
    }
  }

/*
 * 3 Sheet Dectection
 */
  for (j1 = 0; j1 < sseSeq->length - 5; j1++) {
    testB = 0;
    for (j2 = j1 + 5; j2 < sseSeq->length - 3; j2++) {
      if (densityRamaStrand[j1] >= 0 && densityRamaStrand[j1 + 1] >= 0 &&
          densityRamaStrand[j1 + 2] >= 0 && turnSeq[j1] != 't' &&
          turnSeq[j1 + 1] != 't' && turnSeq[j1 + 2] != 't' &&
          densityRamaStrand[j2] >= 0 && densityRamaStrand[j2 + 1] >= 0 &&
          densityRamaStrand[j2 + 2] >= 0 && turnSeq[j2] != 't' &&
          turnSeq[j2 + 1] != 't' && turnSeq[j2 + 2] != 't') {
        vect(coo_CA, j1, j1 + 2, vector1);
        vect(coo_CA, j2, j2 + 2, vector2);
        scal = scalar3_product(vector1, vector2);
        testB = 0;
        if (scal > 0 && dist[j1 + 1][j2 + 1] < 10 && dist[j1][j2] < 10 &&
            dist[j1 + 2][j2 + 2] < 10) {
          testB = 0;
          if (intervalle(dist[j1][j1 + 2], DIST_MOY_B_INTRA_EXT_II2,
                  beta_dist_thresh * DIST_SD_B_INTRA_EXT_II2))
            testB++;

          if (intervalle(dist[j2][j2 + 2], DIST_MOY_B_INTRA_EXT_II2,
                  beta_dist_thresh * DIST_SD_B_INTRA_EXT_II2))
            testB++;

          if (intervalle(dist[j1][j2], DIST_MOY_B_PARA_FRONT_EXT,
                  beta_dist_thresh * DIST_SD_B_PARA_FRONT_EXT))
            testB++;

          if (intervalle(dist[j1 + 1][j2 + 1], DIST_MOY_B_PARA_FRONT_COEUR,
                  beta_dist_thresh * DIST_SD_B_PARA_FRONT_COEUR))
            testB++;

          if (intervalle(dist[j1 + 2][j2 + 2], DIST_MOY_B_PARA_FRONT_EXT,
                  beta_dist_thresh * DIST_SD_B_PARA_FRONT_EXT))
            testB++;

          if (intervalle(dist[j1][j2 + 1], DIST_MOY_B_PARA_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_PARA_INTER_EXT_II1))
            testB++;

          if (intervalle(dist[j1 + 1][j2], DIST_MOY_B_PARA_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_PARA_INTER_EXT_II1))
            testB++;

          if (intervalle
              (dist[j1 + 1][j2 + 2], DIST_MOY_B_PARA_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_PARA_INTER_EXT_II1))
            testB++;

          if (intervalle
              (dist[j1 + 2][j2 + 1], DIST_MOY_B_PARA_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_PARA_INTER_EXT_II1))
            testB++;

        } /*end of if(scal>0) */
        if (scal < 0 && dist[j1][j2 + 2] < 10 && dist[j1 + 1][j2 + 1] < 10 &&
            dist[j1 + 2][j2] < 10) {
          testB = 0;
          if (intervalle(dist[j1][j1 + 2], DIST_MOY_B_INTRA_EXT_II2,
                  beta_dist_thresh * DIST_SD_B_INTRA_EXT_II2))
            testB++;

          if (intervalle(dist[j2][j2 + 2], DIST_MOY_B_INTRA_EXT_II2,
                  beta_dist_thresh * DIST_SD_B_INTRA_EXT_II2))
            testB++;

          if (intervalle(dist[j1][j2 + 2], DIST_MOY_B_ANTI_FRONT_EXT,
                  beta_dist_thresh * DIST_SD_B_ANTI_FRONT_EXT))
            testB++;

          if (intervalle(dist[j1 + 1][j2 + 1], DIST_MOY_B_ANTI_FRONT_COEUR,
                  beta_dist_thresh * DIST_SD_B_ANTI_FRONT_COEUR))
            testB++;

          if (intervalle(dist[j1 + 2][j2], DIST_MOY_B_ANTI_FRONT_EXT,
                  beta_dist_thresh * DIST_SD_B_ANTI_FRONT_EXT))
            testB++;

          if (intervalle(dist[j1][j2 + 1], DIST_MOY_B_ANTI_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_ANTI_INTER_EXT_II1))
            testB++;

          if (intervalle(dist[j1 + 1][j2], DIST_MOY_B_ANTI_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_ANTI_INTER_EXT_II1))
            testB++;

          if (intervalle
              (dist[j1 + 1][j2 + 2], DIST_MOY_B_ANTI_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_ANTI_INTER_EXT_II1))
            testB++;

          if (intervalle
              (dist[j1 + 2][j2 + 1], DIST_MOY_B_ANTI_INTER_EXT_II1,
                  beta_dist_thresh * DIST_SD_B_ANTI_INTER_EXT_II1))
            testB++;
        }
        /*end of if(scal<0) */
        if (testB >= 9) {
          testB = 0;

          for (k = 0; k <= 2; k++) {
            if (densityRamaStrand[j1 + k] > 0)
              testB += 1;

            if (densityRamaStrand[j2 + k] > 0)
              testB += 1;
          }

          if ((PhiPsi->Psi[j2 + 1] > -120 && PhiPsi->Psi[j2 + 1] < 50) ||
              (PhiPsi->Psi[j2 + 1] > -120 && PhiPsi->Psi[j2 + 1] < 50))
            testB = 0;

          /*
           * What is so special here ?
           */
          if (testB >= beta_angle_thresh) {
            sseSeq->seq[j1] = sseSeq->seq[j1 + 1] = sseSeq->seq[j1 + 2] =
                sseSeq->seq[j2] = sseSeq->seq[j2 + 1] = sseSeq->seq[j2 + 2] =
                'b';
            if (scal > 0) { /* para strands */
              for (k = 0; k <= 2; k++) {
                contact[j1 + k][j2 + k] = contact[j2 + k][j1 + k] =
                    'p';
                switch (strandOrient->seq[j1 + k]) {
                case 'a':
                  strandOrient->seq[j1 + k] = 'b';
                  break;
                case 'b':
                  strandOrient->seq[j1 + k] = 'b';
                  break;

                default:
                  strandOrient->seq[j1 + k] = 'p';
                  break;
                }
                switch (strandOrient->seq[j2 + k]) {
                case 'a':
                  strandOrient->seq[j2 + k] = 'b';
                  break;
                case 'b':
                  strandOrient->seq[j2 + k] = 'b';
                  break;

                default:
                  strandOrient->seq[j2 + k] = 'p';
                  break;
                }
              } /* end for(k=0; k<=2;k++) */
            } else { /* anti strands */

              for (k = 0; k <= 2; k++) {
                contact[j1 + k][j2 + 2 - k] =
                    contact[j2 + 2 - k][j1 + k] = 'a';
                switch (strandOrient->seq[j1 + k]) {
                case 'p':
                  strandOrient->seq[j1 + k] = 'b';
                  break;
                case 'b':
                  strandOrient->seq[j1 + k] = 'b';
                  break;

                default:
                  strandOrient->seq[j1 + k] = 'a';
                  break;
                }
                switch (strandOrient->seq[j2 + k]) {
                case 'p':
                  strandOrient->seq[j2 + k] = 'b';
                  break;
                case 'b':
                  strandOrient->seq[j2 + k] = 'b';
                  break;

                default:
                  strandOrient->seq[j2 + k] = 'a';
                  break;
                }
              } /* end for (k=0; k<=2; k++) */
            } /* end else     */
          } /* end if testB >= seuil3D */
        } /* end of if testB >= 9 */
      } /* end of if (densityRamaStrand[j1] != -1 && densityRamaStrand[j1+1] != -1 && ...) */
    } /* end of j2 loop */
  } /* end of j1 loop */

/*
 * 4 SSEs separation
 * It is not allowed to have Hb or bH without a coil between them.
 * When it happens, shorten the helix, because the conditions required
 * for a beta sheet are more severe.
 */
  for (j = 0; j < sseSeq->length - 1; j++) {
    if (sseSeq->seq[j] == 'H' && sseSeq->seq[j + 1] == 'b') {
      sseSeq->seq[j] = '.';
    } else if (sseSeq->seq[j] == 'b' && sseSeq->seq[j + 1] == 'H') {
      sseSeq->seq[j + 1] = '.';
    }
  }

/*
 * 5 post-processing
 * Delete helices shorter than length_H
 */
  currentLength = 0;
  for (j = 0; j < sseSeq->length; j++) {
    if (sseSeq->seq[j] == 'H') {
      currentLength++;
      if ((j < sseSeq->length - 1 && sseSeq->seq[j + 1] != 'H') || (j == sseSeq->length - 1)) { /*fin d'une helice trop courte */
        if (currentLength > 0 && currentLength < pargs->length_H) {
          for (jcorr = j; jcorr > (j - currentLength); jcorr--)
            sseSeq->seq[jcorr] = '.';
        }
        currentLength = 0;
      }
    }
  }

/*
 * 6 Add the turn detection to the final sse sequence
 */
  if (turn == 1) {
    for (j = 0; j < sseSeq->length; j++) {
      if (turnSeq[j] != '-')
        sseSeq->seq[j] = turnSeq[j];
    }
  }

  FREE(turnSeq);
  FREE2(dist);
}

/*******************************************************************************
 *
 ******************************************************************************/
void vect(double **coo_CA, int a, int b, double *vector)
{
  vector[0] = coo_CA[b][0] - coo_CA[a][0];
  vector[1] = coo_CA[b][1] - coo_CA[a][1];
  vector[2] = coo_CA[b][2] - coo_CA[a][2];
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * TEst if D  in interval  M-borne , M+borne
 */
int intervalle(double D, double M, double borne)
{
  if (D < (M + borne) && D > (M - borne))
    return 1;
  else
    return 0;
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Test if residues internal between i and j are assigned as structure
 */
int Is_struct_seg(struct SEQUENCE *sseSeq, int debut, int fin, char structure)
{
  int res = 1;
  int index;

  for (index = debut + 1; index < fin; index++) {
    if (sseSeq->seq[index] == structure)
      return 0;
  }
  return res;
}

/*******************************************************************************
 *
 ******************************************************************************/
int Check_local_minimum(double **dist, int ref_i, int ref_j, int length,
    struct SEQUENCE *sseSeq)
{
  int i, j;

/* check j position while keeping i fixed */
#ifdef LOG
  fprintf(stderr, " check 1\n");
#endif
  i = ref_i;
  for (j = ref_j - 2; j <= ref_j + 2; j++) {
    if (i >= 0 && j >= 0 && i < length && j < length && (j - i >= 3 &&
            j - i <= 5)) {
#ifdef LOG
      fprintf(stderr, " check %d %d ", i, j);
      fprintf(stderr, " distance %lf\n", dist[i][j]);
#endif
      if (dist[i][j] > 0 && Is_struct_seg(sseSeq, i, j, 'H') &&
          dist[i][j] < dist[ref_i][ref_j])
        return 1;
    }
  }

/* check i position while keeping j fixed */
#ifdef LOG
  fprintf(stderr, " check 2\n");
#endif
  j = ref_j;
  for (i = ref_i - 2; i <= ref_i + 2; i++) {
#ifdef LOG
    fprintf(stderr, " check %d %d ", i, j);

#endif
    if (i >= 0 && j >= 0 && i < length && j < length && (j - i >= 3 &&
            j - i <= 5)) {
#ifdef LOG
      fprintf(stderr, " check %d %d ", i, j);
      fprintf(stderr, " distance %lf\n", dist[i][j]);
#endif
      if (dist[i][j] > 0 && Is_struct_seg(sseSeq, i, j, 'H') &&
          dist[i][j] < dist[ref_i][ref_j])
        return 1;
    }
  }

/*
 * now that extremities are sure, check that no turn can be made from
 * the internal residues
 */
#ifdef LOG
  fprintf(stderr, " check 3\n");
#endif
  for (i = ref_i + 1; i <= ref_j - 1; i++) {
    for (j = i - 5; j <= i + 5; j++) {
      /*fprintf(stderr, " check %d %d ", i, j); */
      if (i >= 0 && j >= 0 && i < length && j < length && ((j - i >= 3 &&
                  j - i <= 5) || (i - j >= 3 && i - j <= 5))) {
#ifdef LOG
        fprintf(stderr, " check %d %d ", i, j);
        fprintf(stderr, " distance %lf\n", dist[i][j]);
#endif
        if (dist[i][j] > 0 && Is_struct_seg(sseSeq, i, j, 'H') &&
            dist[i][j] < dist[ref_i][ref_j]) {
#ifdef LOG
          fprintf(stderr, " which is a new minimum \n");
#endif
          return 1;
        }
      }
    }
  }

  return 0;
}
