#include <math.h>

#include "simul.h"

/******************************************************************************
 *
 ******************************************************************************/
/**
 * Function minimization
 * Gradient and target function to be used with INRIA routine M1QN3
 * Last modification: 23/04/94
 *
 * ==> C READY <==
 */
int simul_(int *indic, int *n, double *xc, double *fc, double *gc, int *iter,
    int *isim, int *izs, double *rzs, double *dzs)
{
  int k, natoms;
  int iat, lim1, lim2;
  double cg[3], resmax;
  double cax[6000]; /* was [3][2000] */

/*
 * Just to avoid warnings for unused parameters (A. Marin)
 */
  n = n;
  iter = iter;
  isim = isim;

  lim1 = izs[0];
  lim2 = izs[1];
  natoms = izs[2];

  for (iat = 0; iat < natoms; iat++) {
    for (k = 0; k < 3; k++) {
      cax[k + iat * 3] = rzs[iat * 3 + k];
    }
  }

  for (k = 0; k < 3; k++) {
    cg[k] = dzs[k];
  }

  if (*indic == 2 || *indic == 4) {
    func_(lim1, lim2, cax, cg, xc, fc, &resmax);
  }

  if (*indic == 3 || *indic == 4) {
    gradient_(lim1, lim2, cax, cg, xc, gc);
  }

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/**
 * This subroutine calculates the function: D = 1/n Sum{(di-<d>)*(di-<d>)}
 * where n is the number of Ca's, the summation is taken over n, di is the
 * distance of the ith Ca to the axis and <d> is the average value of these
 * distances, i.e., <d> = 1/n Sum{di}. Note that there are only 2 variables,
 * phi and psi since the axis has to go through the centroid cg.
 *
 * ==> C READY <==
 */
int func_(int lim1, int lim2, double *cax, double *cg, double *var,
    double *dd, double *resmax)
{
  int ii, l, diff;
  double d__1;
  double dist[2000], residual[2000];
  double theta, c1, c2, s1, s2, fl;
  double uu[3], dav, phi;

  diff = lim2 - lim1 + 1;
  fl = 1.0 / diff;

  theta = var[0];
  phi = var[1];
  c1 = cos(theta);
  s1 = sin(theta);
  c2 = cos(phi);
  s2 = sin(phi);

/* Calculate the distances di */

  for (ii = 0; ii < diff; ii++) {
    for (l = 0; l < 3; l++) {
      uu[l] = cg[l] - cax[l + (lim1 + ii) * 3];
    }

/* Computing 2nd power */

    d__1 = c1 * s2 * uu[0] + s1 * s2 * uu[1] + c2 * uu[2];
    dist[ii] = uu[0] * uu[0] + uu[1] * uu[1] + uu[2] * uu[2] - d__1 * d__1;
    dist[ii] = sqrt(dist[ii]);
  }

/* Calculate the average value <d> */

  dav = 0.0;
  for (ii = 0; ii < diff; ii++) {
    dav += dist[ii];
  }
  dav *= fl;

/* Calculate the function */

  *dd = 0.0;
  for (ii = 0; ii < diff; ii++) {
    residual[ii] = (dist[ii] - dav) * (dist[ii] - dav);
    *dd += residual[ii];
  }
  *dd *= fl;

/* Determine the maximum residual */

  *resmax = 0.0;
  for (ii = 0; ii < diff; ii++) {
    if (sqrt(residual[ii]) > *resmax) {
      *resmax = sqrt(residual[ii]);
    }
  }

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/**
 * This subroutine calculates the gradient of the function:
 * D = 1/n Sum{(di-<d>)*(di-<d>)}
 * where n is the number of Ca's, the summation is taken over n, di is the
 * distance of the ith Ca to the axis and <d> is the average value of these
 * distances, i.e., <d> = 1/n Sum{di}. Note that there are only 2 variables,
 * phi and theta. The axis has to go through the centroid cg.
 *
 * ==> C READY <==
 */
int gradient_(int lim1, int lim2, double *cax, double *cg, double *var,
    double *grad)
{
  int l, ii, kk, ll, diff;
  double scal[2000], dist[2000];
  double theta, c1, c2, s1, s2, fl;
  double uu[6000]; /* was [3][2000] */
  double t1k, t2k, t1l, t2l, dkl, phi, tmp;

  diff = lim2 - lim1 + 1;
  fl = 1.0 / diff;
  fl *= fl;

  theta = var[0];
  phi = var[1];
  c1 = cos(theta);
  s1 = sin(theta);
  c2 = cos(phi);
  s2 = sin(phi);

/* Calculate the distances di */

  for (ii = 0; ii < diff; ii++) {
    for (l = 0; l < 3; l++) {
      uu[l + ii * 3] = cg[l] - cax[l + (lim1 + ii) * 3];
    }
    scal[ii] = c1 * s2 * uu[ii * 3 + 0]
        + s1 * s2 * uu[ii * 3 + 1]
        + c2 * uu[ii * 3 + 2];
    dist[ii] =
        uu[ii * 3 + 0] * uu[ii * 3 + 0] + uu[ii * 3 + 1] * uu[ii * 3 + 1]
        + uu[ii * 3 + 2] * uu[ii * 3 + 2] - scal[ii] * scal[ii];
    dist[ii] = sqrt(dist[ii]);
  }

/* Calculate the gradient */

  grad[0] = 0.0;
  grad[1] = 0.0;
  for (kk = 0; kk < diff; kk++) {
    tmp = scal[kk] / dist[kk];
    t1k = (s1 * s2 * uu[kk * 3 + 0] - c1 * s2 * uu[kk * 3 + 1]) * tmp;
    t2k = (-c1 * c2 * uu[kk * 3 + 0] - s1 * c2 * uu[kk * 3 + 1]
        + s2 * uu[kk * 3 + 2]) * tmp;
    for (ll = 0; ll < diff; ll++) {
      if (kk == ll) {
        dkl = 1.0;
      } else {
        dkl = 0.0;
      }
      tmp = scal[ll] / dist[ll];
      t1l = (s1 * s2 * uu[ll * 3 + 0] - c1 * s2 * uu[ll * 3 + 1]) * tmp;
      t2l = (-c1 * c2 * uu[ll * 3 + 0] - s1 * c2 * uu[ll * 3 + 1]
          + s2 * uu[ll * 3 + 2]) * tmp;
      grad[0] += (diff * dkl - 1) * (t1k * dist[ll] + t1l * dist[kk]);
      grad[1] += (diff * dkl - 1) * (t2k * dist[ll] + t2l * dist[kk]);
    }
  }

  grad[0] *= fl;
  grad[1] *= fl;

  return 0;
}
