/*
 * K2R is a program to transmogrify KAKSI XML output to other formats.
 * Copyright (C) 2005
 * Antoine MARIN and the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#ifndef _ALLOC_H
#define _ALLOC_H 1

/*! \def S(x)
 * Stringize operator # : returns a character string corresponding to
 * the name of a variable 
 */
#define S(x) #x

/*! \def ALLOC
 * Memory allocation below refers, for instance, to the following case
 * int *toto;
 * int nel = 10;
 * statement: ALLOC(toto,nel,int); is equivalent to 
 * statement: toto = (int *) malloc((size_t) nel*sizeof(int));
 * 
 */
#define ALLOC(pntr,nelem,type) {(pntr) = (type *) malloc((size_t) (nelem) * \
        sizeof(type)); if((pntr) == NULL)  { \
        fprintf(stderr, "Function: %s in file %s at line %d: Unable to allocate memory for %s\n", __FUNCTION__, __FILE__, __LINE__, S(pntr)); } }

#define CALLOC(pntr,nelem,type) {(pntr) = (type *) calloc((size_t) (nelem), \
        sizeof(type)); if((pntr) == NULL)  { \
        fprintf(stderr, "Function: %s in file %s at line %d: Unable to allocate memory for %s\n", __FUNCTION__, __FILE__, __LINE__, S(pntr)); } }

/*! \def ALLOC_PTR_TO_ARRAY
 * Memory allocation below refers, for instance, to the following case
 * int (*toto)[8];   here toto is a pointer to an array of 8 integers
 * int nel = 10;
 * statement: ALLOC_PTR_TO_ARRAY(toto,nel,int,8); is equivalent to
 * statement: toto = (int (*)[8]) malloc((size_t) nel*sizeof(*toto));
 * Note that *toto refers to the object pointed to by toto, i.e., 
 * an array of 8 integers and thus sizeof(*toto) is 32 bytes.
 */
#define ALLOC_PTR_TO_ARRAY(pntr,nelem,type,array_size) \
        { (pntr) = (type (*)[array_size]) malloc((size_t) (nelem) * \
        sizeof(*pntr)); if((pntr) == NULL) { \
        fprintf(stderr, "Function: %s in file %s at line %d: Unable to allocate memory for %s\n", __FUNCTION__, __FILE__, __LINE__, S(pntr)); } }

/*! \def FOPEN
 * Redefine fopen to include error check
 */
#define FOPEN(fp,fich,mode) { fp = fopen(fich,mode); \
        if(fp == NULL) { fprintf(stderr, "Unable to open file %s\n",fich); } }

/*! \def FREE
 * Redefine free to include warning check
 */
#define FREE(p) { if(p == NULL) { fprintf(stderr, \
        "Trying to free a NULL pointer: %s\n", S(p)); } \
        else { free(p); p = NULL; } }

/*! \def FREE
 * Redefine fclose to include warning check
 */
#define FCLOSE(fp) { if(fp == NULL) { fprintf(stderr, \
        "Trying to close a NULL file pointer: %s\n", S(fp)); } \
        else { fclose(fp); fp = NULL; } }

/*
 * When there is an exit dur to a fatal error print where
 * (function, file, line) at which this error occurred.
 */
#define ERROR_TAG fprintf(stderr,"Function %s in file %s at line %d : ", \
    __FUNCTION__,__FILE__,__LINE__)

#endif /* alloc.h */
