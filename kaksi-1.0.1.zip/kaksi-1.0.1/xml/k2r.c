/*
 * K2R is a program to transmogrify KAKSI XML output to other formats.
 * Copyright (C) 2005
 * Antoine MARIN and the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <libgen.h> /* for basename */
#include <libxml/xmlreader.h>

#include "alloc.h"

#define VERSION       "0.9"
#define MAXCURV       25.0
#define MAX_FNAME     256

/*******************************************************************************
 * TODO
 *
 */

/*******************************************************************************
 * DATA TYPES
 ******************************************************************************/
/**
 * Arguments data structure
 */
typedef struct k2r_args_s {
  char kxo_fname[512];       /**< KAKSI XML output file name */
  int print_fasta;
  int print_angles;
  int print_coo;
  int print_curv;
  int print_pdb_curv;
  int print_pdb_num;
  int print_sse;
  int print_kaksi_sse;
  int print_strand_contact;  /**< flag to print beta strand contacts */
  int print_strand_orient;   /**< flag to print beta strand orientations */
  int print_to_file;
  int output_width;
  char chain;                /**< User provided PDB chain (optional) */
} k2r_args_t;

/**
 * Chain data structure
 *
 * NOTE: all the pointers should be of size 'length'
 *       or 'length' + 1 for strings.
 */
typedef struct k2r_chain_s {
  char name;
  int length;
  char *aa1;        /**< amino acid 1 letter code */
  int *num;
  int *pdb_num;
  char *pdb_icode;
  double *phi;
  double *psi;
  double *curv;
  char *sse;
  char *kaksi_sse;
  double *CAx;
  double *CAy;
  double *CAz;
  int *beta1;
  int *beta2;
} k2r_chain_t;

/**
 * Main data structure
 */
typedef struct k2r_data_s {
  xmlTextReaderPtr reader;
  char pdb_code[16];
  int num_chains;
  k2r_chain_t *chain;
} k2r_data_t;

/*******************************************************************************
 * LOCAL FUNCTIONS
 ******************************************************************************/
static void read_kaksi_xml_output(k2r_args_t *args, k2r_data_t *data);
static void fill_data_structure(k2r_args_t *args, k2r_data_t *data);
static const xmlChar *get_xml_node_value(xmlTextReaderPtr reader);
static void funky_outputs(k2r_args_t *args, k2r_data_t *data);

static void print_fasta(k2r_args_t *args, k2r_data_t *data);
static void print_sse(k2r_args_t *args, k2r_data_t *data);
static void print_kaksi_sse(k2r_args_t *args, k2r_data_t *data);
static void print_pdb_num(k2r_args_t *args, k2r_data_t *data);
static void print_strand_orient(k2r_args_t *args, k2r_data_t *data);
static void print_strand_contact(k2r_args_t *args, k2r_data_t *data);
static void print_curv(k2r_args_t *args, k2r_data_t *data);
static void print_pdb_curv(k2r_args_t *args, k2r_data_t *data);

static void print_seq_width(char *seq, int width);
static void fprint_seq_width(FILE *fp, char *seq, int width);
static void print_int_seq_width(int *seq, int length, int width);
static void fprint_int_seq_width(FILE *fp, int *seq, int length, int width);
static void print_double_seq_width(double *seq, int length, int width);
static void fprint_double_seq_width(FILE *fp, double *seq, int length, int width);
static void print_pdb_num_width(int *num, char *icode, int length, int width);
static void fprint_pdb_num_width(FILE *fp, int *num, char *icode, int length,
    int width);
static void print_strand_orient_width(int *beta1, int *beta2, int length,
    int width);
static void fprint_strand_orient_width(FILE *fp, int *beta1, int *beta2,
    int length, int width);

static char *aa1_to_aa3(char aa1);
static void parse_command_line(int argc, char **argv, k2r_args_t *args);
static void init_arguments(k2r_args_t *args);
static void init_data(k2r_data_t *data);
static void fprint_usage(FILE *fp, char **argv, k2r_args_t *args);

/*******************************************************************************
 *
 ******************************************************************************/
int main (int argc, char **argv)
{
  k2r_args_t args;
  k2r_data_t data;

  init_arguments(&args);
  init_data(&data);
  parse_command_line(argc, argv, &args);

/*
 * Read KAKSI XML output.
 */
  read_kaksi_xml_output(&args, &data);

/*
 * Fill data structure.
 */
  fill_data_structure(&args, &data);

/*
 * Cleanup function for the XML library.
 */
  xmlCleanupParser();

/*
 * Output what you want.
 */
  funky_outputs(&args, &data);

  exit(0);
}

/*******************************************************************************
 *
 ******************************************************************************/
static void read_kaksi_xml_output(k2r_args_t * args, k2r_data_t * data)
{
  data->reader = xmlReaderForFile(args->kxo_fname, NULL, 0);
  if (data->reader == NULL) {
    fprintf(stderr, "Error: Failed to parse file %s\n", args->kxo_fname);
    exit(1);
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Parse the XML structure and fill the data structure and allocate
 * memory according to the need.
 *
 * XML node types:
 * 1  = open element
 * 15 = close element
 */
static void fill_data_structure(k2r_args_t *args, k2r_data_t *data)
{
  int l, nc, nr, ret, type, chain_found = 0;
  xmlTextReaderPtr reader;
  const xmlChar *xsp;

  reader = data->reader;
  ret = xmlTextReaderRead(reader);
  nc = -1;
  nr = -1;

/*
 * This loop enumerate all the XML document nodes
 * For each tag, store the corresponding information, allocate memory
 * when the size information is available.
 */
  while (ret == 1) {
    xsp = xmlTextReaderConstName(reader);
    type = xmlTextReaderNodeType(reader);
    if (type == 1 && strcmp((char *) xsp, "pdb_code") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <pdb_code> value!\n");
        exit(1);
      }
      strcpy(data->pdb_code, (char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "num_chains") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <num_chains> value!\n");
        exit(1);
      }
      data->num_chains = atoi((char *) xsp);
      ALLOC(data->chain, data->num_chains, k2r_chain_t);
    } else if (type == 1 && strcmp((char *) xsp, "chain") == 0) {
      nc++;
      nr = -1;
    } else if (type == 1 && strcmp((char *) xsp, "name") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <name> value!\n");
        exit(1);
      }
      data->chain[nc].name = xsp[0];
      if (args->chain == '\0' || args->chain == data->chain[nc].name) {
        chain_found++;
      }
    } else if (type == 1 && strcmp((char *) xsp, "sequence_length") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <sequence_length> value!\n");
        exit(1);
      }
      l = atoi((char *) xsp);
      data->chain[nc].length = l;
      ALLOC(data->chain[nc].aa1, l + 1, char);
      data->chain[nc].aa1[l] = '\0';
      ALLOC(data->chain[nc].num, l, int);
      ALLOC(data->chain[nc].pdb_num, l, int);
      ALLOC(data->chain[nc].pdb_icode, l, char);
      ALLOC(data->chain[nc].phi, l, double);
      ALLOC(data->chain[nc].psi, l, double);
      ALLOC(data->chain[nc].curv, l, double);
      ALLOC(data->chain[nc].sse, l + 1, char);
      data->chain[nc].sse[l] = '\0';
      ALLOC(data->chain[nc].kaksi_sse, l + 1, char);
      data->chain[nc].kaksi_sse[l] = '\0';
      ALLOC(data->chain[nc].CAx, l, double);
      ALLOC(data->chain[nc].CAy, l, double);
      ALLOC(data->chain[nc].CAz, l, double);
      ALLOC(data->chain[nc].beta1, l, int);
      ALLOC(data->chain[nc].beta2, l, int);
    } else if (type == 1 && strcmp((char *) xsp, "res") == 0) {
      nr++;
    } else if (type == 1 && strcmp((char *) xsp, "aa1") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <aa1> value!\n");
        exit(1);
      }
      data->chain[nc].aa1[nr] = xsp[0];
    } else if (type == 1 && strcmp((char *) xsp, "num") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <num> value!\n");
        exit(1);
      }
      data->chain[nc].num[nr] = atoi((char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "pdb_num") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        data->chain[nc].pdb_num[nr] = -1;
      } else {
        data->chain[nc].pdb_num[nr] = atoi((char *) xsp);
      }
    } else if (type == 1 && strcmp((char *) xsp, "pdb_icode") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        data->chain[nc].pdb_icode[nr] = '�';
      } else {
        data->chain[nc].pdb_icode[nr] = xsp[0];
      }
    } else if (type == 1 && strcmp((char *) xsp, "phi") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <phi> value!\n");
        exit(1);
      }
      data->chain[nc].phi[nr] = atof((char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "psi") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <psi> value!\n");
        exit(1);
      }
      data->chain[nc].psi[nr] = atof((char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "curv") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <curv> value!\n");
        exit(1);
      }
      data->chain[nc].curv[nr] = atof((char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "sse") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <sse> value!\n");
        exit(1);
      }
      data->chain[nc].sse[nr] = xsp[0];
    } else if (type == 1 && strcmp((char *) xsp, "kaksi_sse") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <kaksi_sse> value!\n");
        exit(1);
      }
      data->chain[nc].kaksi_sse[nr] = xsp[0];
    } else if (type == 1 && strcmp((char *) xsp, "CAx") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <CAx> value!\n");
        exit(1);
      }
      data->chain[nc].CAx[nr] = atof((char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "CAy") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <CAy> value!\n");
        exit(1);
      }
      data->chain[nc].CAy[nr] = atof((char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "CAz") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        fprintf(stderr, "Error: unable to find <CAz> value!\n");
        exit(1);
      }
      data->chain[nc].CAz[nr] = atof((char *) xsp);
    } else if (type == 1 && strcmp((char *) xsp, "beta1") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        data->chain[nc].beta1[nr] = INT_MIN;
      } else {
        data->chain[nc].beta1[nr] = atoi((char *) xsp);
      }
    } else if (type == 1 && strcmp((char *) xsp, "beta2") == 0) {
      xsp = get_xml_node_value(reader);
      if (xsp == NULL) {
        data->chain[nc].beta2[nr] = INT_MIN;
      } else {
        data->chain[nc].beta2[nr] = atoi((char *) xsp);
      }
    }
    ret = xmlTextReaderRead(reader);
  }

  xmlFreeTextReader(reader);

/*
 * Some checks
 */
  if (ret != 0) {
    fprintf(stderr, "Error: Failed to parse XML reader!\n");
  }
  if (chain_found == 0) {
    fprintf(stderr, "Error: Unable to find PDB chain!\n");
    exit(1);
  }
  if (data->pdb_code[0] == '\0') {
    fprintf(stderr, "Error: No PDB code found!\n");
    exit(1);
  }
  if (data->num_chains == 0) {
    fprintf(stderr, "Error: No chains found!\n");
    exit(1);
  }
  if (data->chain == NULL) {
    fprintf(stderr, "Error: Empty data structure!\n");
    exit(1);
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static const xmlChar *get_xml_node_value(xmlTextReaderPtr reader)
{
  int ret;
  const xmlChar *name, *value;

  ret = xmlTextReaderRead(reader);
  name = xmlTextReaderConstName(reader);
  value = xmlTextReaderConstValue(reader);
  if (strcmp((char *) name, "#text") == 0) {
    return value;
  }
  return NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
static void funky_outputs(k2r_args_t *args, k2r_data_t *data)
{
  if (args->print_fasta == 1) {
    print_fasta(args, data);
  }
  if (args->print_sse == 1) {
    print_sse(args, data);
  }
  if (args->print_kaksi_sse == 1) {
    print_kaksi_sse(args, data);
  }
  if (args->print_pdb_num == 1) {
    print_pdb_num(args, data);
  }
  if (args->print_strand_orient == 1) {
    print_strand_orient(args, data);
  }
  if (args->print_strand_contact == 1) {
    print_strand_contact(args, data);
  }
  if (args->print_curv == 1) {
    print_curv(args, data);
  }
  if (args->print_pdb_curv == 1) {
    print_pdb_curv(args, data);
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_fasta(k2r_args_t *args, k2r_data_t *data)
{
  int nc;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c.fasta", data->pdb_code, data->chain[nc].name);
        } else {
          sprintf(fname, "%s.fasta", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      fprintf(fp, ">%s%c [SEQRES sequence]\n", data->pdb_code,
          data->chain[nc].name);
      fprint_seq_width(fp, data->chain[nc].aa1, args->output_width);
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_sse(k2r_args_t *args, k2r_data_t *data)
{
  int nc;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c.sse", data->pdb_code, data->chain[nc].name);
        } else {
          sprintf(fname, "%s.sse", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      fprintf(fp, ">%s%c [PDB secondary structure assignment]\n", data->pdb_code,
          data->chain[nc].name);
      fprint_seq_width(fp, data->chain[nc].sse, args->output_width);
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_kaksi_sse(k2r_args_t *args, k2r_data_t *data)
{
  int nc;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c.sse_kaksi", data->pdb_code,
              data->chain[nc].name);
        } else {
          sprintf(fname, "%s.sse_kaksi", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      fprintf(fp, ">%s%c [KAKSI secondary structure assignment]\n",
          data->pdb_code, data->chain[nc].name);
      fprint_seq_width(fp, data->chain[nc].kaksi_sse, args->output_width);
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_pdb_num(k2r_args_t *args, k2r_data_t *data)
{
  int nc;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c.pdbnum", data->pdb_code, data->chain[nc].name);
        } else {
          sprintf(fname, "%s.pdbnum", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      fprintf(fp, ">%s%c [PDB numbering of SEQRES sequence]\n", data->pdb_code,
          data->chain[nc].name);
      fprint_pdb_num_width(fp, data->chain[nc].pdb_num,
          data->chain[nc].pdb_icode, data->chain[nc].length,
          args->output_width / 6);
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_strand_orient(k2r_args_t *args, k2r_data_t *data)
{
  int nc;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c.strandOrient", data->pdb_code,
              data->chain[nc].name);
        } else {
          sprintf(fname, "%s.strandOrient", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      fprintf(fp, ">%s%c [beta strands orientations, p = parallel, "
          "a = antiparallel, P = double parallel, A = double antiparallel, "
          "M = mixed]\n", data->pdb_code,
          data->chain[nc].name);
      fprint_strand_orient_width(fp, data->chain[nc].beta1,
          data->chain[nc].beta2, data->chain[nc].length, args->output_width);
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_strand_contact(k2r_args_t *args, k2r_data_t *data)
{
  int nc, nr1, nr2, length, beta1, beta2;
  k2r_chain_t *chain;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c.strandContact", data->pdb_code,
              data->chain[nc].name);
        } else {
          sprintf(fname, "%s.strandContact", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      fprintf(fp, ">%s%c [beta strands contacts, p = parallel, "
          "a = antiparallel]\n", data->pdb_code,
          data->chain[nc].name);
      chain = &data->chain[nc];
      length = chain->length;
      for (nr1 = 0; nr1 < length; nr1++) {
        beta1 = chain->beta1[nr1];
        beta2 = chain->beta2[nr1];
        for (nr2 = 0; nr2 < length; nr2++) {
          if (beta1 != INT_MIN && (nr2 + 1) == abs(beta1)) {
            if (beta1 > 0) {
              fprintf(fp, "p");
            } else {
              fprintf(fp, "a");
            }
          } else if (beta2 != INT_MIN && (nr2 + 1) == abs(beta2)) {
            if (beta2 > 0) {
              fprintf(fp, "p");
            } else {
              fprintf(fp, "a");
            }
          } else {
            fprintf(fp, ".");
/*
            if (nr1 != nr2) {
              fprintf(fp, ".");
            } else {
              fprintf(fp, "\\");
            }
*/
          }
        }
        fprintf(fp, "\n");
      }
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_curv(k2r_args_t *args, k2r_data_t *data)
{
  int nc;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c.curv", data->pdb_code, data->chain[nc].name);
        } else {
          sprintf(fname, "%s.curv", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      fprintf(fp, ">%s%c [curvature]\n", data->pdb_code,
          data->chain[nc].name);
      fprint_double_seq_width(fp, data->chain[nc].curv, data->chain[nc].length,
          args->output_width / 8);
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Print curvature in PDB format.
 *
 * NOTE: the string formats SHOULD BE THE EXACT PDB specification
 *       (XXXXXX%5d %4s%c%3s %c%4d%c   %8.3f%8.3f%8.3f%6.2f%6.2f)
 */
static void print_pdb_curv(k2r_args_t *args, k2r_data_t *data)
{
  int nc, nr, length;
  char *atm_format = "ATOM  %5d %4s%c%3s %c%4d%c   %8.3f%8.3f%8.3f%6.2f%6.2f\n";
  double curv;
  k2r_chain_t *chain;
  char fname[MAX_FNAME];
  FILE *fp = stdout;

  for (nc = 0; nc < data->num_chains; nc++) {
    if (args->chain == '\0' || args->chain == data->chain[nc].name) {
      if (args->print_to_file == 1) {
        if (data->chain[nc].name != ' ') {
          sprintf(fname, "%s%c_curv.pdb", data->pdb_code, data->chain[nc].name);
        } else {
          sprintf(fname, "%s_curv.pdb", data->pdb_code);
        }
        FOPEN(fp, fname, "w");
      }
      chain = &data->chain[nc];
      length = chain->length;
      for (nr = 0; nr < length; nr++) {
        if (nr != length - 1) {
          curv = chain->curv[nr];
        } else {
          curv = MAXCURV;
        }
        fprintf(fp, atm_format, nr + 1, " CA ", ' ', aa1_to_aa3(chain->aa1[nr]),
            chain->name, chain->pdb_num[nr], chain->pdb_icode[nr],
            chain->CAx[nr], chain->CAy[nr], chain->CAz[nr], 1.0, curv);
      }
      fprintf(fp, "TER\n");
      if (fp != stdout) {
        FCLOSE(fp);
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_seq_width(char *seq, int width)
{
  fprint_seq_width(stdout, seq, width);
}
/*******************************************************************************
 *
 ******************************************************************************/
static void fprint_seq_width(FILE *fp, char *seq, int width)
{
  int i, length;

  length = strlen(seq);
  for (i = 0; i < length; i++) {
    fprintf(fp, "%c", seq[i]);
    if ((i + 1) % width == 0) {
      fprintf(fp, "\n");
    }
  }
  if (i % width != 0) {
    fprintf(fp, "\n");
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_int_seq_width(int *seq, int length, int width)
{
  fprint_int_seq_width(stdout, seq, length, width);
}

/*******************************************************************************
 *
 ******************************************************************************/
static void fprint_int_seq_width(FILE *fp, int *seq, int length, int width)
{
  int i;

  for (i = 0; i < length; i++) {
    fprintf(fp, "%d ", seq[i]);
    if ((i + 1) % width == 0) {
      fprintf(fp, "\n");
    }
  }
  if (i % width != 0) {
    fprintf(fp, "\n");
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_double_seq_width(double *seq, int length, int width)
{
  fprint_double_seq_width(stdout, seq, length, width);
}

/*******************************************************************************
 *
 ******************************************************************************/
static void fprint_double_seq_width(FILE *fp, double *seq, int length, int width)
{
  int i;

  for (i = 0; i < length; i++) {
    fprintf(fp, "%8.3f", seq[i]);
    if ((i + 1) % width == 0) {
      fprintf(fp, "\n");
    }
  }
  if (i % width != 0) {
    fprintf(fp, "\n");
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_pdb_num_width(int *num, char *icode, int length, int width)
{
  fprint_pdb_num_width(stdout, num, icode, length, width);
}

/*******************************************************************************
 *
 ******************************************************************************/
static void fprint_pdb_num_width(FILE *fp, int *num, char *icode, int length,
    int width)
{
  int i;

  for (i = 0; i < length; i++) {
    if (icode[i] != '�') {
      fprintf(fp, "%5d%c", num[i], icode[i]);
    } else {
      fprintf(fp, "   -1�");
    }
    if ((i + 1) % width == 0) {
      fprintf(fp, "\n");
    }
  }
  if (i % width != 0) {
    fprintf(fp, "\n");
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_strand_orient_width(int *beta1, int *beta2, int length,
    int width)
{
  fprint_strand_orient_width(stdout, beta1, beta2, length, width);
}

/*******************************************************************************
 *
 ******************************************************************************/
static void fprint_strand_orient_width(FILE *fp, int *beta1, int *beta2,
    int length, int width)
{
  int i;

  for (i = 0; i < length; i++) {
/* old code
    if (beta1[i] == INT_MIN) {
      fprintf(fp, ".");
    } else if (beta1[i] > 0 && (beta2[i] > 0 || beta2[i] == INT_MIN)) {
      fprintf(fp, "p");
    } else if (beta1[i] < 0 && (beta2[i] < 0 || beta2[i] == INT_MIN)) {
      fprintf(fp, "a");
    } else if ((beta1[i] < 0 && beta2[i] > 0 && beta2[i] != INT_MIN)
        || (beta1[i] > 0 && beta2[i] < 0 && beta2[i] != INT_MIN)) {
      fprintf(fp, "b");
    } else {
      fprintf(stderr, "Error: the program should never print this!\n");
      exit(1);
    }
*/
/*
 * New code (not tested) with more states
 * Maybe we should split M into 2 states (this is not symetrical) but
 * we have to be sure about the orientation.
 * Maybe beta1 and beta2 should be beta_l (left) and beta_r (right)
 */
    if (beta1[i] == INT_MIN) {
      fprintf(fp, ".");
    } else if (beta1[i] > 0 && beta2[i] == INT_MIN) {
      fprintf(fp, "p");
    } else if (beta1[i] < 0 && beta2[i] == INT_MIN) {
      fprintf(fp, "a");
    } else if (beta1[i] > 0 && beta2[i] > 0) {
      fprintf(fp, "P");
    } else if (beta1[i] < 0 && beta2[i] < 0) {
      fprintf(fp, "A");
    } else if ((beta1[i] < 0 && beta2[i] > 0)
        || (beta1[i] > 0 && beta2[i] < 0)) {
      fprintf(fp, "M");
    } else {
      fprintf(stderr, "Error: the program should never print this!\n");
      exit(1);
    }
    if ((i + 1) % width == 0) {
      fprintf(fp, "\n");
    }
  }
  if (i % width != 0) {
    fprintf(fp, "\n");
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static char *aa1_to_aa3(char aa1)
{
  switch (aa1) {
    case 'A' : return "ALA";
    case 'C' : return "CYS";
    case 'D' : return "ASP";
    case 'E' : return "GLU";
    case 'F' : return "PHE";
    case 'G' : return "GLY";
    case 'H' : return "HIS";
    case 'I' : return "ILE";
    case 'K' : return "LYS";
    case 'L' : return "LEU";
    case 'M' : return "MET";
    case 'N' : return "ASN";
    case 'P' : return "PRO";
    case 'Q' : return "GLN";
    case 'R' : return "ARG";
    case 'S' : return "SER";
    case 'T' : return "THR";
    case 'V' : return "VAL";
    case 'W' : return "TRP";
    case 'Y' : return "TYR";
    default  : return "UNK";
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void parse_command_line(int argc, char **argv, k2r_args_t *args)
{
  int i;

  for (i = 1; i < argc; i++) {
    if (strcmp(argv[i], "-c") == 0) {
      i++;
      args->chain = argv[i][0];
    } else if (strcmp(argv[i], "-h") == 0
        || strcmp(argv[i], "--help") == 0) {
      fprint_usage(stdout, argv, args);
      exit(0);
    } else if (strcmp(argv[i], "-kxo") == 0) {
      i++;
      strcpy(args->kxo_fname, argv[i]);
    } else if (strcmp(argv[i], "-ow") == 0) {
      i++;
      args->output_width = atoi(argv[i]);
      if (args->output_width < 1) {
        args->output_width = INT_MAX;
      }
    } else if (strcmp(argv[i], "-pf") == 0) {
      args->print_to_file = 1;
    } else if (strcmp(argv[i], "-pfc") == 0) {
      args->print_curv = 1;
    } else if (strcmp(argv[i], "-pfs") == 0) {
      args->print_fasta = 1;
    } else if (strcmp(argv[i], "-pks") == 0) {
      args->print_kaksi_sse = 1;
    } else if (strcmp(argv[i], "-ppc") == 0) {
      args->print_pdb_curv = 1;
    } else if (strcmp(argv[i], "-ppn") == 0) {
      args->print_pdb_num = 1;
    } else if (strcmp(argv[i], "-pps") == 0) {
      args->print_sse = 1;
    } else if (strcmp(argv[i], "-psc") == 0) {
      args->print_strand_contact = 1;
    } else if (strcmp(argv[i], "-pso") == 0) {
      args->print_strand_orient = 1;
    } else if (strcmp(argv[i], "-v") == 0
        || strcmp(argv[i], "--version") == 0) {
      printf("This is %s release number %s\n", basename(argv[0]), VERSION);
      exit(0);
    } else {
      printf("Unknown tag : %s\n", argv[i]);
      exit(1);
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void init_arguments(k2r_args_t *args)
{
  args->kxo_fname[0] = '\0';
  args->print_fasta = 0;
  args->print_angles = 0;
  args->print_coo = 0;
  args->print_curv = 0;
  args->print_pdb_curv = 0;
  args->print_pdb_num = 0;
  args->print_sse = 0;
  args->print_kaksi_sse = 0;
  args->print_strand_contact = 0;
  args->print_strand_orient = 0;
  args->print_to_file = 0;
  args->output_width = 80;
  args->chain = '\0';
}

/*******************************************************************************
 *
 ******************************************************************************/
static void init_data(k2r_data_t *data)
{
  data->reader = NULL;
  data->pdb_code[0] = '\0';
  data->num_chains = 0;
  data->chain = NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
static void fprint_usage(FILE *fp, char **argv, k2r_args_t *args)
{
  fprintf(fp, "\nUsage: %s [options] -kxo kaksi_xml_output\n\n",
      basename(argv[0]));
  fprintf(fp, " Options:\n\n");
  fprintf(fp, "  -c chain        : PDB chain\n");
  fprintf(fp, "  -h, --help      : print this help\n");
  fprintf(fp, "  -ow width       : output width, -1 will never split lines\n"
              "                    [default: %d]\n", args->output_width);
  fprintf(fp, "  -pf             : print output to file(s), one for each PDB chain\n");
  fprintf(fp, "  -pfc            : print curvature in FASTA format\n");
  fprintf(fp, "  -pfs            : print SEQRES sequence in FASTA format\n");
  fprintf(fp, "  -pks            : print KAKSI secondary structure in FASTA format\n");
  fprintf(fp, "  -ppc            : print curvature in PDB format\n");
  fprintf(fp, "  -ppn            : print PDB numbering in FASTA format\n");
  fprintf(fp, "  -pps            : print PDB secondary structure in FASTA format\n");
  fprintf(fp, "  -psc            : print beta strands contacts in a raw matrix format\n");
  fprintf(fp, "  -pso            : print beta strands orientations in FASTA format\n");
  fprintf(fp, "  -v, --version   : print the program release number\n\n");
}
