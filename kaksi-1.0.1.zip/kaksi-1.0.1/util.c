/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * This function returns, for a given chain number in SEQRES records, 
 * (nc), the corresponding chain number in ATOM records.
 */
int getATOMchainNumber(int current_nc, struct MiscTransfer *MT,
    struct RecordTransfer *ATOMrec, struct RecordTransfer *SEQRESrec)
{
  int ncA;  /**< Chain number in ATOM records */

  for (ncA = 0; ncA < ATOMrec->Nchain; ncA++) {
    if (MT->validATOMchains[ncA] == 0) {
      continue;
    }
    if (ATOMrec->chainName[ncA] == SEQRESrec->chainName[current_nc]) {
      return ncA;
    }
  }

/*
 * The program should never reach this point in theory!
 */
  ERROR_TAG;
  Erreur(1, "Error: The program should never reach this line. This is SEQRES "
      "chain %d '%c'\n", current_nc, SEQRESrec->chainName[current_nc]);

  return -1;
}

/*******************************************************************************
 *
 ******************************************************************************/
char *aa1_to_aa3(char aa1)
{
  switch (aa1) {
    case 'A' : return "ALA";
    case 'C' : return "CYS";
    case 'D' : return "ASP";
    case 'E' : return "GLU";
    case 'F' : return "PHE";
    case 'G' : return "GLY";
    case 'H' : return "HIS";
    case 'I' : return "ILE";
    case 'K' : return "LYS";
    case 'L' : return "LEU";
    case 'M' : return "MET";
    case 'N' : return "ASN";
    case 'P' : return "PRO";
    case 'Q' : return "GLN";
    case 'R' : return "ARG";
    case 'S' : return "SER";
    case 'T' : return "THR";
    case 'V' : return "VAL";
    case 'W' : return "TRP";
    case 'Y' : return "TYR";
    default  : return "UNK";
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Set the PDB file name if not provided
 */
void set_pdb_file(char *pdb_file, char *pdb_dir, char *pdb_code)
{
  if (pdb_dir == NULL && strcmp(pdb_file, "void") == 0) {
    Erreur(1, "Error: Environment variable PDB_DIR is not defined and no "
        "PDB file has been specified explicitely.\n");
  }

  if (strcmp(pdb_code, "void") == 0 && strcmp(pdb_file, "void") == 0) {
    Erreur(1, "Error: You must specify a PDB code or a PDB file.\n");
  } else {
    if (strcmp(pdb_file, "void") == 0) {
      string_tolower(pdb_code);
      sprintf(pdb_file, "%s/%c%c/pdb%s.ent", pdb_dir, pdb_code[1],
          pdb_code[2], pdb_code);
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
void vector3_product(double *vect_norm, double *vect1, double *vect2)
{
  vect_norm[0] = vect1[1] * vect2[2] - vect1[2] * vect2[1];
  vect_norm[1] = vect1[2] * vect2[0] - vect1[0] * vect2[2];
  vect_norm[2] = vect1[0] * vect2[1] - vect1[1] * vect2[0];
}

/*******************************************************************************
 *
 ******************************************************************************/
double distance3(double **coo_CA, int index1, int index2)
{
  return sqrt(
      (coo_CA[index1][0] - coo_CA[index2][0]) *
      (coo_CA[index1][0] - coo_CA[index2][0]) +
      (coo_CA[index1][1] - coo_CA[index2][1]) *
      (coo_CA[index1][1] - coo_CA[index2][1]) +
      (coo_CA[index1][2] - coo_CA[index2][2]) *
      (coo_CA[index1][2] - coo_CA[index2][2]));
}

/*******************************************************************************
 *
 ******************************************************************************/
double scalar3_product(double *vect1, double *vect2)
{
  return (vect1[0] * vect2[0] + vect1[1] * vect2[1] + vect1[2] * vect2[2]);
}

/*******************************************************************************
 *
 ******************************************************************************/
void read_mat(int mat[36][36], char *fileName)
{
  FILE *fp = NULL;
  int i, j;

  FOPEN(fp, fileName, "r");

  for (i = 0; i < 36; i++) {
    for (j = 0; j < 36; j++) {
      fscanf(fp, "%d", &mat[i][j]);
    }
  }

  FCLOSE(fp);
}

/*******************************************************************************
 *
 ******************************************************************************/
char residue_type(char *str1)
{
  if (strncmp(str1, "ALA", 3) == 0) {
    return ('A');
  } else if (strncmp(str1, "CYS", 3) == 0) {
    return ('C');
  } else if (strncmp(str1, "ASP", 3) == 0) {
    return ('D');
  } else if (strncmp(str1, "GLU", 3) == 0) {
    return ('E');
  } else if (strncmp(str1, "PHE", 3) == 0) {
    return ('F');
  } else if (strncmp(str1, "GLY", 3) == 0) {
    return ('G');
  } else if (strncmp(str1, "HIS", 3) == 0) {
    return ('H');
  } else if (strncmp(str1, "ILE", 3) == 0) {
    return ('I');
  } else if (strncmp(str1, "LYS", 3) == 0) {
    return ('K');
  } else if (strncmp(str1, "LEU", 3) == 0) {
    return ('L');
  } else if (strncmp(str1, "MET", 3) == 0) {
    return ('M');
  } else if (strncmp(str1, "ASN", 3) == 0) {
    return ('N');
  } else if (strncmp(str1, "PRO", 3) == 0) {
    return ('P');
  } else if (strncmp(str1, "GLN", 3) == 0) {
    return ('Q');
  } else if (strncmp(str1, "ARG", 3) == 0) {
    return ('R');
  } else if (strncmp(str1, "SER", 3) == 0) {
    return ('S');
  } else if (strncmp(str1, "THR", 3) == 0) {
    return ('T');
  } else if (strncmp(str1, "VAL", 3) == 0) {
    return ('V');
  } else if (strncmp(str1, "TRP", 3) == 0) {
    return ('W');
  } else if (strncmp(str1, "TYR", 3) == 0) {
    return ('Y');
  } else if (strncmp(str1, "   ", 3) == 0) {
    return (' ');
  } else {
    return ('X');
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
void string_tolower(char *s)
{
  int i, k;

  k = strlen(s);
  for (i = 0; i < k; i ++) {
    if (s[i] >= 'A' && s[i] <= 'Z') {
      s[i] = tolower(s[i]);
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
void init_ppf_arguments(ppf_args_t *args)
{
  args->pdb_dir = getenv("PDB_DIR");
  if (args->pdb_dir == NULL) {
    args->pdb_dir = "/db/natif/pdb";
  }
  strcpy(args->pdb_fname, "void");
  strcpy(args->pdb_code, "void");
/*
 * This sentinel value must be changed to something else if it happens
 * that the chain name is � (and everything may happens in PDB files!)
 */
  args->user_chain_id = '�';
  args->length_H = 5;
  args->length_b = 3;
  args->turn = 0;
  args->separate_sse = 1;
  args->remove_sse = 0;
}
