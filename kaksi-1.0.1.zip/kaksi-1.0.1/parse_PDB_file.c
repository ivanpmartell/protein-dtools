/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "read_PDB_file.h"
#include "process_SEQRES_record.h"
#include "process_ATOM_record.h"
#include "compare_SEQRES_ATOM.h"
#include "transfer_data.h"
#include "process_SSE_record.h"
#include "compute_phi_psi.h"
#include "extract_CA.h"
#include "util.h"

#define VERSION "1.4.1"

/* TODO
 *
 * 1/ Check the warnings to see if we can cope with some of them:
 * 1tbzH, 1tgn, 1theA, 1theB, 1tq7B, 1trmA, 1trmB, 2tgd, 2trm
 * (A. Marin 13/01/2005)
 *
 * 2/ Check function 'FillSecStructure' with file 1tbz chain H
 * (A. Marin 13/01/2005)
 */

/*******************************************************************************
 * INTERNAL FUNCTIONS
 ******************************************************************************/
static void print_usage(char **argv, ppf_args_t *args);
static void parse_command_line(int argc, char **argv, ppf_args_t *args);

/*******************************************************************************
 *
 ******************************************************************************/
int main(int argc, char *argv[])
{
  FILE *fpout = NULL;
  char Fout[250], Fout_root[250];
  int i;
  int nc, nca = 0;
  pdb_t pdb;
  char chainId;
  int notfound;
  double **coo_CA = NULL;
  struct RecordTransfer SEQRESrec, ATOMrec;
  struct NODES heads;
  struct CHUNK *headchunk;
  struct MiscTransfer *MT;
  struct PHIPSI *PhiPsi;
  ppf_args_t args;

  fprintf(stderr, "**************************************************\n");
  fprintf(stderr, "* The use of parse_PDB_file is deprecated        *\n");
  fprintf(stderr, "* Use KAKSI instead and K2R to change the output *\n");
  fprintf(stderr, "**************************************************\n");

  init_ppf_arguments(&args);
  parse_command_line(argc, argv, &args);
  set_pdb_file(args.pdb_fname, args.pdb_dir, args.pdb_code);

/*
 * Initialize PDB structure and other values
 */
  CALLOC(MT, 1, struct MiscTransfer);
  memset(&pdb, 0, sizeof(pdb_t));
  SEQRESrec.Nchain = 0;
  ATOMrec.Nchain = 0;
  heads.headHelix = NULL;
  heads.headSheet = NULL;
  heads.headTurn = NULL;

/*
 * Read PDB file and check a lot of things
 */
  Read_PDB(&args, &pdb, &heads, &headchunk, &SEQRESrec, &ATOMrec, MT);
  process_SEQRES_record(headchunk, &SEQRESrec, MT);
  process_ATOM_record(&pdb, MT, &SEQRESrec, &ATOMrec);
  compare_SEQRES_ATOM(MT, &pdb, &SEQRESrec, &ATOMrec);
  transfer_data(&pdb, MT, &SEQRESrec, &ATOMrec);
  process_SSE_record(&pdb, &heads, MT, &SEQRESrec, &ATOMrec, &args);
  ALLOC(PhiPsi, pdb.Nchains, struct PHIPSI);
  compute_phi_psi(&pdb, PhiPsi);

/*
 * Write on file the required information for the selected chain
 */
  notfound = 1;
  for (nc = 0; nc < pdb.Nchains; nc++) {
    if (pdb.nucleic[nc] == 1)
      continue;
    if (args.user_chain_id != '�' && pdb.chainNames[nc] != args.user_chain_id)
      continue;

    nca = pdb.chain_nres[nc];
    chainId = pdb.chainNames[nc];
    if (chainId == ' ') {
      sprintf(Fout_root, "%s", args.pdb_code);
    } else {
      sprintf(Fout_root, "%s%c", args.pdb_code, chainId);
    }
    notfound = 0;

    /*
     * Print SEQRES sequence in FASTA format
     */
    sprintf(Fout, "%s.fasta", Fout_root);
    FOPEN(fpout, Fout, "w");
    fprintf(fpout, ">%s\n", Fout_root);
    fprintf(fpout, "%s\n", pdb.seq[nc]);
    FCLOSE(fpout);

    /*
     * Print secondary structure defined in the PDB file
     */
    sprintf(Fout, "%s.sse", Fout_root);
    if (pdb.sep_sse_count[nc] != 0) {
      fprintf(stderr, "Warning: could not process SSE record because of "
          "too many errors (%d), SSEs are not separated with coils.\n",
          pdb.sep_sse_count[nc]);
      strcat(Fout, ".warning");
    }
    FOPEN(fpout, Fout, "w");
    fprintf(fpout, ">%s\n", Fout_root);
    fprintf(fpout, "%s\n", pdb.sse[nc]);
    FCLOSE(fpout);

    /*
     * Print PDB numbering
     */
    sprintf(Fout, "%s.pdbnum", Fout_root);
    FOPEN(fpout, Fout, "w");
    fprintf(fpout, ">%s\n", Fout_root);
    for (i = 0; i < nca; i++) {
      fprintf(fpout, "%d%c ", pdb.SEQRESnumres[nc][i],
          pdb.SEQRESiCode[nc][i]);

    }
    fprintf(fpout, "\n");
    FCLOSE(fpout);

    /*
     * Print Phi/psi angles
     */
    sprintf(Fout, "%s.angles", Fout_root);
    FOPEN(fpout, Fout, "w");
    fprintf(fpout, ">%s\n", Fout_root);
    for (i = 0; i < nca; i++) {
      fprintf(fpout, " %3d%c %c %6.1f %6.1f %c\n", PhiPsi[nc].index[i],
          PhiPsi[nc].iCode[i], PhiPsi[nc].resName[i], PhiPsi[nc].Phi[i],
          PhiPsi[nc].Psi[i], PhiPsi[nc].Omega[i]);
    }
    FCLOSE(fpout);

    /*
     * Print CA coordinates
     */
    ALLOC(coo_CA, pdb.max_nCA, double *);
    for (i = 0; i < pdb.max_nCA; i++) {
      ALLOC(coo_CA[i], 3, double);
    }
    extract_CA(&pdb, coo_CA, nc);

    sprintf(Fout, "%s.coo", Fout_root);
    FOPEN(fpout, Fout, "w");
    fprintf(fpout, "%d\n", nca);
    for (i = 0; i < nca; i++) {
      fprintf(fpout, "%4d %c   %8.3f %8.3f %8.3f\n", i + 1, pdb.seq[nc][i],
          coo_CA[i][0], coo_CA[i][1], coo_CA[i][2]);
    }
    FCLOSE(fpout);

    for (i = 0; i < nca; i++) {
      FREE(coo_CA[i]);
    }
    FREE(coo_CA);

  } /* End of loop on chains (nc) */

  if (notfound) {
    ERROR_TAG;
    fprintf(stderr, "Error: Unable to find chain '%c' in PDB file whose "
        "chains are: ", args.user_chain_id);
    for (i = 0; i < pdb.Nchains; i++) {
      fprintf(stderr, "'%c' ", pdb.chainNames[i]);
    }
    fprintf(stderr, "\n");
    exit(1);
  }

  exit(0);
}

/*******************************************************************************
 *
 ******************************************************************************/
static void parse_command_line(int argc, char **argv, ppf_args_t *args)
{
  int i;

  if (argc == 1) {
    print_usage(argv, args);
    exit(1);
  }

  for (i = 1; i < argc; i++) {
    if (strcmp(argv[i], "-c") == 0) {
      i++;
      args->user_chain_id = argv[i][0];
      if (args->user_chain_id == '�') {
        ERROR_TAG;
        Erreur(1, "Error: Your chain name (%c) corresponds to the "
            "sentinel value in the program.\nChange the sentinel value "
            "in the program and recompile it\n", args->user_chain_id);
      }
    } else if (strcmp(argv[i], "-h") == 0
        || strcmp(argv[i], "--help") == 0) {
      print_usage(argv, args);
      exit(0);
    } else if (strcmp(argv[i], "-pc") == 0) {
      i++;
      strcpy(args->pdb_code, argv[i]);
    } else if (strcmp(argv[i], "-pf") == 0) {
      i++;
      strcpy(args->pdb_fname, argv[i]);
    } else if (strcmp(argv[i], "-sep") == 0) {
      i++;
      args->separate_sse = atoi(argv[i]);
    } else if (strcmp(argv[i], "-turn") == 0) {
      i++;
      args->turn = atoi(argv[i]);
    } else if (strcmp(argv[i], "-v") == 0
        || strcmp(argv[i], "--version") == 0) {
      printf("This is %s release number %s\n", basename(argv[0]), VERSION);
      exit(0);
    } else {
      printf("Unknown tag : %s\n", argv[i]);
      exit(1);
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static void print_usage(char **argv, ppf_args_t *args)
{
  printf("\nUsage : %s [options] {-pc pdb_code, -pf pdb_file}\n\n",
      basename(argv[0]));
  printf("pdb_code        : PDB code for the PDB file to be processed.\n");
  printf("pdb_file        : name of the PDB file (if not specified, it must "
      "be found in dir: %s).\n\n", args->pdb_dir);
  printf("Options:\n\n");
  printf("-c pdb_chain    : name of the chain to process.\n");
  printf("                  If none, all chains will be processed.\n");
  printf("-h, --help      : print this help\n");
  printf("-sep bool       : 1 or 0. 0 means that no editing of SSEs "
      "is performed,  two SSEs can directly follow\n");
  printf("                          each other. 1 means that a coil will "
      "be introduced between 2 contigous SSEs.\n");
  printf("                          Default [%d]\n", args->separate_sse);
  printf("-turn bool      : 1 or 0. 1 select turns as a secondary "
      "structure with symbol 'T'\n");
  printf("                          0 turns are considered as coils: '.'\n");
  printf("                          Default [%d]\n", args->turn);
  printf("-v, --version   : print the program release number\n\n");
}
