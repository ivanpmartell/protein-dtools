#include <math.h>

#include "m1qn3.h"
#include "util.h"

/******************************************************************************
 *
 ******************************************************************************/
/** 
 * M1qn3, version 1.0, septembre 1988.
 *
 * La sous-routine m1qn3 est une interface entre le programme
 * appelant et la sous-routine m1qn3a, le minimiseur proprement dit.
 *
 * trav est la zone de travail pour m1qn3a, de dimension ntrav.
 * Elle est subdivisee en
 *     5 vecteurs de dimension n: d,xx,gg,precon,aux
 *     m scalaires: alpha
 *     m vecteurs de dimension n: ybar
 *     m vecteurs de dimension n: sbar
 *
 * m est alors le plus grand entier tel que
 *     m*(2*n+1)+5*n .le. ntrav,
 * soit m := (ntrav-5*n) / (2*n+1)
 *
 * A chaque iteration la metrique est formee a partir d''une matrice
 * diagonale D mise a jour m fois par la formule de BFGS en
 * utilisant les m couples {y,s} les plus recents. La matrice
 * diagonale est egale apres la premiere iteration a
 *     (y,s)/|y|**2 * identite
 * et est elle-meme mise a jour a chaque iteration en utilisant la
 * formule de BFGS directe diagonalisee adaptee a l''ellipsoide de
 * Rayleigh. Si on note
 *     D[i]:=(De[i],e[i]),
 * ou les e[i] forment une base orthonormale pour le produit scalaire
 * (.,.), la formule de mise a jour de D s''ecrit:
 *     D[i] := 1 / ( (Dy,y)/(y,s)/D[i] + y[i]**2/(y,s)
 *                    - (Dy,y)*(s[i]/D[i])**2/(y,s)/(D**(-1)s,s) )
 *
 * Modifs 17/5/90 (Gilbert)
 * - on autorise le simulateur a faire ce qu'il veut (notamment
 *   a modifier la fonction) apres mlis0, toutes les 'iperso'
 *   iterations.
 */
int m1qn3_(int (*simul) (), int (*prosca) (), int *n, double *x, double *f,
    double *g, double *dxmin, double *df1, double *epsg, int *impres, int *io,
    int *mode, int *niter, int *nsim, int *iperso, double *trav, int *ntrav,
    int *izs, double *rzs, double *dzs)
{
  int iaux, m, isbar;
  int iprec, iybar;
  int l1memo, id, ialpha;
  int ntravu, igg, ixx;
  double r1, r2;
  double ps;

  /* Parameter adjustments */
  --dzs;
  --rzs;
  --izs;
  --trav;
  --g;
  --x;

  if (*n <= 0 || *niter <= 0 || *nsim <= 0 || *iperso < 0 ||
      *dxmin <= 0.0 || *epsg <= 0.0 || *epsg > 1.0) {
    *mode = 2;
    return 0;
  }

/* calcul de m et des pointeurs subdivisant la zone de travail trav */

  ntravu = *ntrav - *n * 5;
  if (ntravu < 0) {
    *mode = 2;
    return 0;
  }
  l1memo = (*n << 1) + 1;
  m = ntravu / l1memo;
  ntravu = m * l1memo + *n * 5;
  id = 1;
  ixx = id + *n;
  igg = ixx + *n;
  iprec = igg + *n;
  iaux = iprec + *n;
  ialpha = iaux + *n;
  iybar = ialpha + m;
  isbar = iybar + *n * m;

/* appel du code d'optimisation */

  m1qn3a_(simul, prosca, n, &x[1], f, &g[1], dxmin, df1, epsg, impres, io,
      mode, niter, nsim, iperso, &m, &trav[id], &trav[ixx], &trav[igg],
      &trav[iprec], &trav[iaux], &trav[ialpha], &trav[iybar], &trav[isbar],
      &izs[1], &rzs[1], &dzs[1]);

/* impressions finales */

  (*prosca) (*n, &x[1], &x[1], &ps);
  r1 = ps;
  r1 = sqrt(r1);
  (*prosca) (*n, &g[1], &g[1], &ps);
  r2 = ps;
  r2 = sqrt(r2);

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
int m1qn3a_(int (*simul) (), int (*prosca) (), int *n, double *x, double *f,
    double *g, double *dxmin, double *df1, double *epsg, int *impres, int *io,
    int *mode, int *niter, int *nsim, int *iperso, int *m, double *d__,
    double *xx, double *gg, double *precon, double *aux, double *alpha,
    double *ybar, double *sbar, int *izs, double *rzs, double *dzs)
{
  int ybar_dim1, ybar_offset, sbar_dim1, sbar_offset, i__1;
  int jmin, jmax, isim, iter;
  int i__;
  int indic;
  int moderl;
  double c_b7 = 0.95;
  double c_b8 = 0.001;
  double d__1, d__2, d__3;
  double tmin, tmax;
  double t;
  double preco, gnorm, r1, ff, dk, ps, ys, gnadru;
  double precos, dk1, hp0, ps2;
  double den, rms, eps1;

  /* Parameter adjustments */
  --aux;
  --precon;
  --gg;
  --xx;
  --d__;
  --g;
  --x;
  sbar_dim1 = *n;
  sbar_offset = 1 + sbar_dim1 * 1;
  sbar -= sbar_offset;
  ybar_dim1 = *n;
  ybar_offset = 1 + ybar_dim1 * 1;
  ybar -= ybar_offset;
  --alpha;
  --izs;
  --rzs;
  --dzs;

  eps1 = 0.0;
  iter = 0;
  isim = 1;

  (*prosca) (*n, &g[1], &g[1], &ps);
  gnorm = ps;
  gnorm = sqrt(gnorm);

/* Computing 2nd power */

  d__1 = gnorm;
  precos = *df1 * 2.0 / (d__1 * d__1);
  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    d__[i__] = -g[i__] * precos;
  }

/* initialisation pour mlis0 */

  tmax = 1e20;
  (*prosca) (*n, &d__[1], &g[1], &hp0);

/* initialisation pour strang */

  jmin = 1;
  jmax = 0;

/*
 * debut des iterations.
 * on connait d. on cherche x(k+1) de la forme x(k) + t*d, avec t > 0.
 * debut de la boucle: etiquette 100, sortie de la boucle: goto 1000.
 */
L100:
  ++iter;
  if (*impres < 0) {
    if (iter % (-(*impres)) == 0) {
      indic = 1;
      (*simul) (&indic, n, &x[1], f, &g[1], &iter, &isim, &izs[1], &rzs[1],
          &dzs[1]);
      goto L100;
    }
  }

  if (*impres >= 3) {
    (*prosca) (*n, &g[1], &g[1], &gnadru);
    rms = sqrt(gnadru / *n);
  }
  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    xx[i__] = x[i__];
    gg[i__] = g[i__];
  }
  ff = *f;

/* recherche lineaire et nouveau point x(k+1) */

  tmin = 0.0;
  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {

/* Computing MAX */

    d__2 = tmin, d__3 = (d__1 = d__[i__], fabs(d__1));
    tmin = MAX2(d__2, d__3);
  }
  tmin = *dxmin / tmin;
  t = 1.0;
  r1 = hp0;

  mlis0_(n, simul, prosca, &x[1], f, &r1, &t, &tmin, &tmax, &d__[1], &g[1],
      &c_b7, &c_b8, impres, io, &moderl, &isim, nsim, &aux[1], &iter, &izs[1],
      &rzs[1], &dzs[1]);

/* mlis0 renvoie les nouvelles valeurs de x, f et g */

  if (moderl != 0) {
    if (moderl < 0) {
      *mode = moderl;
    } else if (moderl == 1) {
      *mode = 3;
    } else if (moderl == 4) {
      *mode = 5;
    } else if (moderl == 5) {
      *mode = 0;
    } else if (moderl == 6) {
      *mode = 6;
    }
    goto L1000;
  }

/* tests d''arret */

  (*prosca) (*n, &g[1], &g[1], &ps);
  eps1 = ps;
  eps1 = sqrt(eps1) / gnorm;

  if (eps1 < *epsg) {
    *mode = 1;
    goto L1000;
  }
  if (iter == *niter) {
    *mode = 4;
    goto L1000;
  }
  if (isim > *nsim) {
    *mode = 5;
    goto L1000;
  }

/* mise a jour de la matrice */

  if (*m > 0) {
    ++jmax;
    if (iter > *m) {
      ++jmin;
      if (jmin > *m) {
        jmin -= *m;
      }
      if (jmax > *m) {
        jmax -= *m;
      }
    }

/* y, s et (y,s) */

    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
      sbar[i__ + jmax * sbar_dim1] = x[i__] - xx[i__];
      ybar[i__ + jmax * ybar_dim1] = g[i__] - gg[i__];
    }
    if (*impres >= 5) {
      (*prosca) (*n, &sbar[jmax * sbar_dim1 + 1], &sbar[jmax * sbar_dim1 + 1],
          &ps);
      dk1 = sqrt(ps);
      dk = dk1;
    }
    (*prosca) (*n, &ybar[jmax * ybar_dim1 + 1], &sbar[jmax * sbar_dim1 + 1],
        &ps);
    ys = ps;
    if (ys <= 0.0) {
      *mode = 7;
      goto L1000;
    }

/* ybar et sbar */

    r1 = sqrt(1.0 / ys);
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
      sbar[i__ + jmax * sbar_dim1] = r1 * sbar[i__ + jmax * sbar_dim1];
      ybar[i__ + jmax * ybar_dim1] = r1 * ybar[i__ + jmax * ybar_dim1];
    }

/* calcul de la diagonale de preconditionnement */

    (*prosca) (*n, &ybar[jmax * ybar_dim1 + 1], &ybar[jmax * ybar_dim1 + 1],
        &ps);
    precos = 1.0 / ps;
    if (iter == 1) {
      i__1 = *n;
      for (i__ = 1; i__ <= i__1; ++i__) {
        precon[i__] = precos;
      }
    } else {

/* ajustememt de la diagonale a l''ellipsoide de rayleigh */

      r1 = 0.0;
      i__1 = *n;
      for (i__ = 1; i__ <= i__1; ++i__) {

/* Computing 2nd power */

        d__1 = ybar[i__ + jmax * ybar_dim1];
        r1 += precon[i__] * (d__1 * d__1);
      }
      if (*impres >= 5) {
      }
      i__1 = *n;
      for (i__ = 1; i__ <= i__1; ++i__) {
        precon[i__] /= r1;
      }

/* mise a jour diagonale */

      den = 0.0;
      i__1 = *n;
      for (i__ = 1; i__ <= i__1; ++i__) {

/* Computing 2nd power */

        d__1 = sbar[i__ + jmax * sbar_dim1];
        den += d__1 * d__1 / precon[i__];
      }
      i__1 = *n;
      for (i__ = 1; i__ <= i__1; ++i__) {

/* Computing 2nd power */

        d__1 = ybar[i__ + jmax * ybar_dim1];

/* Computing 2nd power */

        d__2 = sbar[i__ + jmax * sbar_dim1] / precon[i__];
        precon[i__] =
            1.0 / (1.0 / precon[i__] + d__1 * d__1 -
            d__2 * d__2 / den);
      }
    }
    if (*impres >= 5) {
      preco = 0.0;
      i__1 = *n;
      for (i__ = 1; i__ <= i__1; ++i__) {
        preco += precon[i__];
      }
      preco /= *n;
    }
  }

/* kz 17/5/90 */

/* appel personalise a simul ? */
/* (il est autorise de changer la fonction ici !) */

  if (*iperso > 0) {
    if (iter % *iperso == 0) {
      indic = 0;
      (*simul) (&indic, n, &x[1], f, &g[1], &iter, &isim, &izs[1], &rzs[1],
          &dzs[1]);
    }
  }

/* end kz */

/* calcul de la nouvelle direction de descente d = - H.g */

  if (*m == 0) {

/* Computing 2nd power */

    d__1 = eps1 * gnorm;
    preco = (ff - *f) * 2.0 / (d__1 * d__1);
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
      d__[i__] = -g[i__] * preco;
    }
  } else {
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
      d__[i__] = -g[i__];
    }
    strang2_(prosca, n, m, &d__[1], &jmin, &jmax, &precon[1], &alpha[1],
        &ybar[ybar_offset], &sbar[sbar_offset], &izs[1], &rzs[1], &dzs[1]);
  }

/* test: la direction d est-elle de descente ? */
/* hp0 sera utilise par mlis0 */

  (*prosca) (*n, &d__[1], &g[1], &hp0);
  if (hp0 >= 0.) {
    *mode = 7;
    goto L1000;
  }
  if (*impres >= 5) {
    (*prosca) (*n, &g[1], &g[1], &ps);
    ps = sqrt(ps);
    (*prosca) (*n, &d__[1], &d__[1], &ps2);
    ps2 = sqrt(ps2);
    ps = hp0 / ps / ps2;

/* Computing MIN */

    d__1 = -ps;
    ps = MIN2(d__1, 1.);
    ps = acos(ps);
    r1 = ps;
    r1 = r1 * 180.0 / 3.1415927;
  }

/* on poursuit les iterations */

  goto L100;

/* retour */

L1000:
  *niter = iter;
  *nsim = isim;
  *epsg = eps1;
  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/**
 * Calcule le produit h g ou
 *     . h est une matrice construite par la formule de bfgs inverse
 *       a nm memoires a partir de la matrice diagonale precon
 *       dans un espace hilbertien dont le produit scalaire
 *       est donne par prosca
 *       (cf. j. nocedal, math. of comp. 35/151 (1980) 773-782)
 *     . g est un vecteur de dimension n (en general le gradient)
 *
 * la matrice precon apparait donc comme un preconditionneur diagonal
 *
 * delp = g (en entree), = h g (en sortie)
 *
 * la matrice h est memorisee par les vecteurs des tableaux
 * ybar, sbar et les pointeurs jmin, jmax
 *
 * alpha(nm) est une zone de travail
 *
 * izs(1),rzs(1),dzs(1) sont des zones de travail pour prosca
 */
int strang2_(int (*prosca) (), int *n, int *nm, double *depl, int *jmin,
    int *jmax, double *precon, double *alpha, double *ybar, double *sbar,
    int *izs, double *rzs, double *dzs)
{
  int ybar_dim1, ybar_offset, sbar_dim1, sbar_offset, i__1, i__2;
  int jfin, i__, j;
  int jp;
  double r__;
  double ps;

  /* Parameter adjustments */
  --precon;
  --depl;
  sbar_dim1 = *n;
  sbar_offset = 1 + sbar_dim1 * 1;
  sbar -= sbar_offset;
  ybar_dim1 = *n;
  ybar_offset = 1 + ybar_dim1 * 1;
  ybar -= ybar_offset;
  --alpha;
  --izs;
  --rzs;
  --dzs;

  jfin = *jmax;
  if (jfin < *jmin) {
    jfin = *jmax + *nm;
  }

/* phase de descente */

  i__1 = *jmin;
  for (j = jfin; j >= i__1; --j) {
    jp = j;
    if (jp > *nm) {
      jp -= *nm;
    }
    (*prosca) (*n, &depl[1], &sbar[jp * sbar_dim1 + 1], &ps);
    r__ = ps;
    alpha[jp] = r__;
    i__2 = *n;
    for (i__ = 1; i__ <= i__2; ++i__) {
      depl[i__] -= r__ * ybar[i__ + jp * ybar_dim1];
    }
  }

/* preconditionnement */

  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    depl[i__] *= precon[i__];
  }

/* remontee */

  i__1 = jfin;
  for (j = *jmin; j <= i__1; ++j) {
    jp = j;
    if (jp > *nm) {
      jp -= *nm;
    }
    (*prosca) (*n, &depl[1], &ybar[jp * ybar_dim1 + 1], &ps);
    r__ = alpha[jp] - ps;
    i__2 = *n;
    for (i__ = 1; i__ <= i__2; ++i__) {
      depl[i__] += r__ * sbar[i__ + jp * sbar_dim1];
    }
  }

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/**
 * mlis0 + minuscules + commentaires + version amelioree (XII 88):
 *   interpolation cubique systematique et anti-overflows
 *
 *    en sortie logic =
 *    0          descente serieuse
 *    1          descente bloquee
 *    4          nap > napmax
 *    5          retour a l'utilisateur
 *    6          fonction et gradient pas d'accord
 *    < 0        contrainte implicite active
 */
int mlis0_(int *n, int (*simul) (), int (*prosca) (), double *xn, double *fn,
    double *fpn, double *t, double *tmin, double *tmax, double *d__, double *g,
    double *amd, double *amf, int *imp, int *io, int *logic, int *nap,
    int *napmax, double *x, int *iter, int *izs, double *rzs, double *dzs)
{
  int i__1;
  int i__;
  int indic;
  int indica;
  int indicd;
  double d__1;
  double barr, tesd, tesf, fopt, test, topt, f;
  double z__, d2, fa, fd, fg, ta, fp;
  double td;
  double tg, gauche, ps, barmin, barmax, barmul;
  double droite, taa, fpa, ffn, fpd, fpg;

/*
 * Just to avoid warnings for unused parameters (A. Marin)
 */
  io = io;

  /* Parameter adjustments */
  --x;
  --g;
  --d__;
  --xn;
  --izs;
  --rzs;
  --dzs;

  if (*n > 0 && *fpn < 0.0 && *t > 0.0 && *tmax > 0.0 &&
      *amf > 0.0 && *amd > *amf && *amd < 1.0) {
    goto L5;
  }
  *logic = 6;
  goto L999;

L5:
  tesf = *amf * *fpn;
  indicd = 0;
  tesd = *amd * *fpn;
  barmin = 0.01;
  barmul = 3.0;
  barmax = 0.3;
  barr = barmin;
  td = 0.0;
  tg = 0.0;
  fg = *fn;
  fpg = *fpn;
  topt = 0.0;
  fopt = *fn;
  ta = 0.0;
  fa = *fn;
  fpa = *fpn;
  (*prosca) (*n, &d__[1], &d__[1], &ps);
  d2 = ps;

/* elimination d'un t initial ridiculement petit */

  if (*t > *tmin) {
    goto L20;
  }
  *t = *tmin;
  if (*t <= *tmax) {
    goto L20;
  }
  *tmin = *tmax;

L20:
  if (*fn + *t * *fpn < *fn + *t * 0.9 * *fpn) {
    goto L30;
  }
  *t *= 2.0;
  goto L20;

L30:
  indica = 1;
  *logic = 0;
  if (*t > *tmax) {
    *t = *tmax;
    *logic = 1;
  }

/* nouveau x */

  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    x[i__] = xn[i__] + *t * d__[i__];
  }

/* boucle */

L100:
  ++(*nap);
  if (*nap > *napmax) {
    *logic = 4;
    *fn = fg;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
      xn[i__] += topt * d__[i__];
    }
    indic = 4;
    (*simul) (&indic, n, &xn[1], fn, &g[1], iter, nap, &izs[1], &rzs[1],
        &dzs[1]);
    goto L999;
  }
  indic = 4;

/* appel simulateur */

  (*simul) (&indic, n, &x[1], &f, &g[1], iter, nap, &izs[1], &rzs[1], &dzs[1]);
  if (indic == 0) {

/* arret demande par l'utilisateur */

    *logic = 5;
    *fn = f;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
      xn[i__] = x[i__];
    }
    goto L999;
  }
  if (indic < 0) {

/* les calculs n'ont pas pu etre effectues par le simulateur */

    td = *t;
    indicd = indic;
    *logic = 0;
    *t = tg + (td - tg) * 0.1;
    goto L905;
  }
  if (f < fopt) {
    topt = *t;
    fopt = f;
  }

/* les tests elementaires sont faits, on y va */

  (*prosca) (*n, &d__[1], &g[1], &ps);
  fp = ps;

/* premier test de Wolfe */

  ffn = f - *fn;
  if (ffn > *t * tesf) {
    td = *t;
    fd = f;
    fpd = fp;
    indicd = indic;
    *logic = 0;
    goto L500;
  }

/* test 1 ok, donc deuxieme test de Wolfe */

  if (fp > tesd) {
    *logic = 0;
    goto L320;
  }
  if (*logic == 0) {
    goto L350;
  }

/* test 2 ok, donc pas serieux, on sort */

L320:
  *fn = f;
  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    xn[i__] = x[i__];
  }
  goto L999;

L350:
  tg = *t;
  fg = f;
  fpg = fp;
  if (td != 0.0) {
    goto L500;
  }

/* extrapolation */

  taa = *t;
  gauche = (barr * 10.0 + 1.0) * *t;
  droite = *t * 10.0 *barr / barmin;
  ecube_(t, &f, &fp, &ta, &fa, &fpa, &gauche, &droite);
  ta = taa;
  if (*t < *tmax) {
    goto L900;
  }
  *logic = 1;
  *t = *tmax;
  goto L900;

/* interpolation */

L500:
  if (indica <= 0) {
    ta = *t;
    gauche = tg;
    droite = td;
    *t = tg * 0.9 + td * 0.1;
    goto L900;
  }
  test = barr * (td - tg);
  gauche = tg + test;
  droite = td - test;
  taa = *t;
  ecube_(t, &f, &fp, &ta, &fa, &fpa, &gauche, &droite);
  ta = taa;

/* fin de boucle */
/* - t peut etre bloque sur tmax */
/* (venant de l'extrapolation avec logic=1) */

L900:
  fa = f;
  fpa = fp;

/* restriction eventuelle de l'intervalle de confiance */
/* (pour eviter pertes de temps en cas de mode 6) */

  if (*t > gauche && *t < droite) {
    barr = barmin;
  } else {

/* Computing MIN */

    d__1 = barmul * barr;
    barr = MIN2(d__1, barmax);
  }

L905:
  indica = indic;

/* faut-il continuer ? */

  if (td == 0.0) {
    goto L950;
  }
  if (td - tg < *tmin) {
    goto L920;
  }

/* limite de precision machine (arret de secours) ? */

  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    z__ = xn[i__] + *t * d__[i__];
    if (z__ != xn[i__] && z__ != x[i__]) {
      goto L950;
    }
  }

/* arret sur dxmin ou de secours */

L920:
  *logic = 6;

/* si indicd<0, derniers calculs non faits par simul */

  if (indicd < 0) {
    *logic = indicd;
  }

/* si tg=0, xn = xn_depart, */
/* sinon on prend xn=x_gauche qui fait decroitre f */

  if (topt == 0.0) {
    goto L940;
  }
  *fn = fopt;
  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    xn[i__] += topt * d__[i__];
  }
  indic = 4;
  (*simul) (&indic, n, &xn[1], fn, &g[1], iter, nap, &izs[1], &rzs[1], &dzs[1]);

L940:
  if (*imp <= 0) {
    goto L999;
  }
  goto L999;

/* recopiage de x et boucle */

L950:
  i__1 = *n;
  for (i__ = 1; i__ <= i__1; ++i__) {
    x[i__] = xn[i__] + *t * d__[i__];
  }
  goto L100;

L999:
  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/**
 * Calcule le nouveau t par formule cubique
 * d'apres t et ta, forcee entre tg et td
 */
int ecube_(double *t, double *f, double *fp, double *ta, double *fa,
    double *fpa, double *tg, double *td)
{
  double d__1;
  double sign, anum, ps, discri, den;

  ps = *fp + *fpa - (*fa - *f) * 3. / (*ta - *t);
  if (fabs(ps) <= 1.) {
    discri = ps * ps - *fp * *fpa;
    if (discri >= 0.) {
      discri = sqrt(discri);
      goto L120;
    }
    discri = -1.;
  } else {
    discri = *fp / ps;
    discri *= *fpa;
    discri = ps - discri;
    if (ps >= 0. && discri >= 0.) {
      discri = sqrt(ps) * sqrt(discri);
      goto L120;
    }
    if (ps < 0. && discri < 0.) {
      discri = sqrt(-ps) * sqrt(-discri);
      goto L120;
    }
    discri = -1.;
  }
  if (discri >= 0.) {
    goto L120;
  }
  if (*fp < 0.0) {
    *t = *td;
  }
  if (*fp >= 0.0) {
    *t = *tg;
  }
  goto L900;

L120:
  if (*t - *ta < 0.0) {
    discri = -discri;
  }
  sign = (*t - *ta) / (d__1 = *t - *ta, fabs(d__1));
  if ((ps + *fp) * sign > 0.0) {
    goto L500;
  }
  den = ps * 2. + *fp + *fpa;
  anum = discri + *fp + ps;
  if ((d__1 = (*t - *ta) * anum, fabs(d__1)) >= (*td - *tg) * fabs(den)) {
    goto L200;
  }
  *t += anum * (*ta - *t) / den;
  goto L900;

L200:
  *t = *td;
  goto L900;

L500:
  *t += *fp * (*ta - *t) / (ps + *fp + discri);

L900:
  *t = MAX2(*t, *tg);
  *t = MIN2(*t, *td);
  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/**
 * Scalar product to be used with m1qn3
 *
 * ==> C READY <==
 */
int prosca_(int n, double *a, double *b, double *ps)
{
  int i;

  *ps = 0.0;
  for (i = 0; i < n; i++) {
    *ps += a[i] * b[i];
  }

  return 0;
}
