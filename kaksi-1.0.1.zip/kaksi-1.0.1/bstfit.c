#include <math.h>

#include "bstfit.h"
#include "util.h"

/******************************************************************************
 *
 ******************************************************************************/
static double d_sign(double a, double b);

/******************************************************************************
 *
 ******************************************************************************/
/**
 * This version can be used with option -O of the compiler.
 * The bug in subroutine dmach which was the cause of incorrect
 * results when the code was optimized has been fixed.
 * Last modification: 22/06/94
 */
int bstftx_(int *n, double *co1, double *co2, int *iflag, int *ims,
    double *rms, double *r__, double *xc1, double *xc2, int *ierr)
{
  int i__1;
  double a[9]; /* was [3][3] */
  int i__, j, k, natom;
  int na;
  double xd, yd, zd;

  /* Parameter adjustments */
  --iflag;
  co2 -= 4;
  co1 -= 4;
  r__ -= 4;
  --xc1;
  --xc2;

  for (k = 1; k <= 3; ++k) {
    xc1[k] = 0.0;
    xc2[k] = 0.0;
  }

  natom = 0;
  i__1 = *n;
  for (na = 1; na <= i__1; ++na) {
    if (iflag[na] >= *ims) {
      ++natom;
      for (k = 1; k <= 3; ++k) {
        xc1[k] += co1[k + na * 3];
        xc2[k] += co2[k + na * 3];
      }
    }
  }

  for (k = 1; k <= 3; ++k) {
    xc1[k] /= natom;
    xc2[k] /= natom;
    i__1 = *n;
    for (na = 1; na <= i__1; ++na) {
      co1[k + na * 3] -= xc1[k];
      co2[k + na * 3] -= xc2[k];
    }
  }

  for (i__ = 1; i__ <= 3; ++i__) {
    for (j = 1; j <= 3; ++j) {
      a[i__ + j * 3 - 4] = 0.0;
      i__1 = *n;
      for (na = 1; na <= i__1; ++na) {
        if (iflag[na] >= *ims) {
          a[i__ + j * 3 - 4] += co1[i__ + na * 3] * co2[j + na * 3];
        }
      }
    }
  }

  bstft0_(n, &co2[4], a, &r__[4], ierr);

  if (*ierr == 1) {
    return 0;
  }

  *rms = 0.;
  i__1 = *n;
  for (na = 1; na <= i__1; ++na) {
    if (iflag[na] >= *ims) {
      xd = co2[na * 3 + 1] - co1[na * 3 + 1];
      yd = co2[na * 3 + 2] - co1[na * 3 + 2];
      zd = co2[na * 3 + 3] - co1[na * 3 + 3];
      *rms = *rms + xd * xd + yd * yd + zd * zd;
    }
  }

  *rms = sqrt(*rms / natom);

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
int bstft0_(int *n, double *co2, double *a, double *r__, int *ierr)
{
  int c__3 = 3;
  int i__1;
  double deta;
  double c__[3], d__[3];
  int i__, j;
  double u[9]; /* was [3][3] */
  double v[9]; /* was [3][3] */
  int na;
  double wk[3];
  int ier;

  /* Parameter adjustments */
  co2 -= 4;
  a -= 4;
  r__ -= 4;

  deta = a[4] * a[8] * a[12] + a[7] * a[11] * a[6] + a[10] * a[5] * a[9] -
      a[6] * a[8] * a[10] - a[9] * a[11] * a[4] - a[12] * a[5] * a[7];

  if (fabs(deta) < 1e-8) {
    *ierr = 1;
    return 0;
  }

  svdd_(&a[4], &c__3, &c__3, &c__3, &c__3, d__, u, &c__3, v, &c__3, wk, &ier);

  if (deta > 0.0) {
    for (i__ = 1; i__ <= 3; ++i__) {
      for (j = 1; j <= 3; ++j) {
        r__[i__ + j * 3] =
            u[i__ - 1] * v[j - 1] + u[i__ + 2] * v[j + 2] + u[i__ + 5] * v[j +
            5];
      }
    }
  } else if (deta < 0.0) {
    for (i__ = 1; i__ <= 3; ++i__) {
      for (j = 1; j <= 3; ++j) {
        r__[i__ + j * 3] =
            u[i__ - 1] * v[j - 1] + u[i__ + 2] * v[j + 2] - u[i__ + 5] * v[j +
            5];
      }
    }
  }

  i__1 = *n;
  for (na = 1; na <= i__1; ++na) {
    c__[0] =
        r__[4] * co2[na * 3 + 1] + r__[7] * co2[na * 3 + 2] +
        r__[10] * co2[na * 3 + 3];
    c__[1] =
        r__[5] * co2[na * 3 + 1] + r__[8] * co2[na * 3 + 2] +
        r__[11] * co2[na * 3 + 3];
    c__[2] =
        r__[6] * co2[na * 3 + 1] + r__[9] * co2[na * 3 + 2] +
        r__[12] * co2[na * 3 + 3];
    co2[na * 3 + 1] = c__[0];
    co2[na * 3 + 2] = c__[1];
    co2[na * 3 + 3] = c__[2];
  }

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/*
 * ==> C READY <==
 */
double double_precision()
{
  double one = 1.0;
  double eps = 1.0;

  while (eps + one != one) {
    eps *= 0.5;
  }
  eps += eps;

  return eps;
}

/******************************************************************************
 *
 ******************************************************************************/
int svdd_(double *a, int *ka, int *m, int *n, int *isw, double *q, double *u,
    int *ku, double *v, int *kv, double *w, int *ind)
{
  int a_dim1, a_offset, u_dim1, u_offset, v_dim1, v_offset, i__1, i__2, i__3;
  double d__1, d__2, d__3;
  double c__, f, g, h__;
  int i__, j, k, l;
  double s, x, y, z__, anorm;
  int ii, kk, ll, mn, it, mu, mv, ip1, m1n, lp1;
  double tol, sum;

  /* Parameter adjustments */
  --w;
  --q;
  a_dim1 = *ka;
  a_offset = 1 + a_dim1 * 1;
  a -= a_offset;
  u_dim1 = *ku;
  u_offset = 1 + u_dim1 * 1;
  u -= u_offset;
  v_dim1 = *kv;
  v_offset = 1 + v_dim1 * 1;
  v -= v_offset;

/* Modification JFG 22/06/94 */
  ip1 = 0;
  s = 0.0;
  h__ = 0.0;
  l = 0;
  *ind = 30000;
  mn = MIN2(*m, *n);
  if (mn < 1 || *m > *ka || *m > *ku) {
    goto L490;
  }
  mu = *isw / 2;
  mv = *isw % 2;
  if (mu < 0 || mu > 1 || mv < 0 || mv > 1) {
    goto L490;
  }
  if (mv == 1 && *n > *kv) {
    goto L490;
  }

/* Computing MIN */

  i__1 = *m + 1;
  m1n = MIN2(i__1, *n);
  i__1 = *n;
  for (j = 1; j <= i__1; ++j) {
    i__2 = *m;
    for (i__ = 1; i__ <= i__2; ++i__) {
      u[i__ + j * u_dim1] = a[i__ + j * a_dim1];
    }
  }
  anorm = 0.0;
  g = 0.0;
  i__2 = m1n;
  for (i__ = 1; i__ <= i__2; ++i__) {
    q[i__] = 0.0;
    w[i__] = g;
    if (i__ > *m) {
      goto L100;
    }
    ip1 = i__ + 1;
    g = u[i__ + i__ * u_dim1];
    if (i__ == *m) {
      goto L30;
    }
    sum = 0.0;
    i__1 = *m;
    for (k = i__; k <= i__1; ++k) {
      sum = u[k + i__ * u_dim1] * u[k + i__ * u_dim1] + sum;
    }
    s = sum;
    d__1 = sqrt(s);
    g = -d_sign(d__1, g);
    h__ = u[i__ + i__ * u_dim1] * g - s;
    u[i__ + i__ * u_dim1] -= g;

L30:
    q[i__] = g;
    if (i__ == *n) {
      goto L100;
    }
    if (s == 0.0 || i__ == *m) {
      goto L60;
    }
    i__1 = *n;
    for (j = ip1; j <= i__1; ++j) {
      sum = 0.0;
      i__3 = *m;
      for (k = i__; k <= i__3; ++k) {
        sum = u[k + i__ * u_dim1] * u[k + j * u_dim1] + sum;
      }
      f = sum / h__;
      i__3 = *m;
      for (k = i__; k <= i__3; ++k) {
        u[k + j * u_dim1] = u[k + i__ * u_dim1] * f + u[k + j * u_dim1];
      }
    }

L60:
    g = u[i__ + ip1 * u_dim1];
    if (ip1 == *n) {
      goto L100;
    }
    sum = 0.0;
    i__3 = *n;
    for (k = ip1; k <= i__3; ++k) {
      sum = u[i__ + k * u_dim1] * u[i__ + k * u_dim1] + sum;
    }
    s = sum;
    d__1 = sqrt(s);
    g = -d_sign(d__1, g);
    h__ = u[i__ + ip1 * u_dim1] * g - s;
    u[i__ + ip1 * u_dim1] -= g;
    if (s == 0.0 || i__ == *m) {
      goto L100;
    }
    i__3 = *m;
    for (j = ip1; j <= i__3; ++j) {
      sum = 0.0;
      i__1 = *n;
      for (k = ip1; k <= i__1; ++k) {
        sum = u[i__ + k * u_dim1] * u[j + k * u_dim1] + sum;
      }
      f = sum / h__;
      i__1 = *n;
      for (k = ip1; k <= i__1; ++k) {
        u[j + k * u_dim1] = u[i__ + k * u_dim1] * f + u[j + k * u_dim1];
      }
    }

L100:

/* Computing MAX */

    d__3 = (d__1 = q[i__], fabs(d__1)) + (d__2 = w[i__], fabs(d__2));
    anorm = MAX2(d__3, anorm);
  }
  tol = double_precision() * anorm;
  if (mv == 0) {
    goto L180;
  }
  i__2 = m1n;
  for (ii = 1; ii <= i__2; ++ii) {
    i__ = m1n + 1 - ii;
    if (i__ == *n) {
      goto L170;
    }
    ip1 = i__ + 1;
    if (i__ == m1n) {
      goto L150;
    }
    if (ip1 == *n || w[ip1] == 0.0) {
      goto L130;
    }
    h__ = u[i__ + ip1 * u_dim1] * w[ip1];
    i__1 = m1n;
    for (j = ip1; j <= i__1; ++j) {
      sum = 0.0;
      i__3 = *n;
      for (k = ip1; k <= i__3; ++k) {
        sum = u[i__ + k * u_dim1] * v[k + j * v_dim1] + sum;
      }
      f = sum / h__;
      i__3 = *n;
      for (k = ip1; k <= i__3; ++k) {
        v[k + j * v_dim1] = u[i__ + k * u_dim1] * f + v[k + j * v_dim1];
      }
    }

L130:
    i__3 = m1n;
    for (j = ip1; j <= i__3; ++j) {
      v[i__ + j * v_dim1] = 0.0;
    }

L150:
    i__3 = *n;
    for (j = ip1; j <= i__3; ++j) {
      v[j + i__ * v_dim1] = 0.0;
    }

L170:
    v[i__ + i__ * v_dim1] = 1.0;
  }

L180:
  if (mu == 0) {
    goto L260;
  }
  i__2 = mn;
  for (ii = 1; ii <= i__2; ++ii) {
    i__ = mn + 1 - ii;
    if (i__ == mn) {
      goto L200;
    }
    ip1 = i__ + 1;
    i__3 = mn;
    for (j = ip1; j <= i__3; ++j) {
      u[i__ + j * u_dim1] = 0.0;
    }

L200:
    if (q[i__] == 0.0) {
      goto L250;
    }
    if (i__ == mn) {
      goto L230;
    }
    h__ = u[i__ + i__ * u_dim1] * q[i__];
    i__3 = mn;
    for (j = ip1; j <= i__3; ++j) {
      sum = 0.0;
      i__1 = *m;
      for (k = ip1; k <= i__1; ++k) {
        sum = u[k + i__ * u_dim1] * u[k + j * u_dim1] + sum;
      }
      f = sum / h__;
      i__1 = *m;
      for (k = i__; k <= i__1; ++k) {
        u[k + j * u_dim1] = u[k + i__ * u_dim1] * f + u[k + j * u_dim1];
      }
    }

L230:
    i__1 = *m;
    for (k = i__; k <= i__1; ++k) {
      u[k + i__ * u_dim1] /= q[i__];
    }

L250:
    if (i__ < *m || q[i__] == 0.0) {
      u[i__ + i__ * u_dim1] += 1.0;
    }
  }

L260:
  if (anorm == 0.0) {
    goto L470;
  }
  i__2 = m1n;
  for (kk = 1; kk <= i__2; ++kk) {
    k = m1n + 1 - kk;
    for (it = 1; it <= 30; ++it) {
      i__1 = k;
      for (ll = 1; ll <= i__1; ++ll) {
        l = k + 1 - ll;
        if ((d__1 = w[l], fabs(d__1)) < tol) {
          goto L310;
        }
        if ((d__1 = q[l], fabs(d__1)) < tol) {
          goto L280;
        }
      }

L280:
      c__ = 0.0;
      s = -1.0;
      i__1 = l;
      for (ii = 2; ii <= i__1; ++ii) {
        i__ = l + 1 - ii;
        f = -w[i__ + 1] * s;
        w[i__ + 1] *= c__;
        if (fabs(f) < tol) {
          goto L310;
        }
        g = q[i__];
        q[i__] = sqrt(g * g + f * f);
        c__ = g / q[i__];
        s = f / q[i__];
        if (mv == 0) {
          goto L300;
        }
        i__3 = *n;
        for (j = 1; j <= i__3; ++j) {
          x = v[j + i__ * v_dim1];
          v[j + i__ * v_dim1] = v[j + l * v_dim1] * s + x * c__;
          v[j + l * v_dim1] = v[j + l * v_dim1] * c__ - x * s;
        }

L300:
        ;
      }

L310:
      if (l == k) {
        goto L370;
      }
      g = w[k - 1];
      h__ = w[k];
      x = q[l];
      y = q[k - 1];
      z__ = q[k];
      f = ((y - z__) * (y + z__) + (g - h__) * (g +
              h__)) / (h__ * y * 2.0);
      d__1 = sqrt(f * f + 1.0);
      f = ((x - z__) * (x + z__) + h__ * (y / (d_sign(d__1, f) + f) - h__)) / x;
      c__ = 1.0;
      s = 1.0;
      lp1 = l + 1;
      i__1 = k;
      for (i__ = lp1; i__ <= i__1; ++i__) {
        h__ = w[i__] * s;
        g = w[i__] * c__;
        w[i__ - 1] = sqrt(f * f + h__ * h__);
        c__ = f / w[i__ - 1];
        s = h__ / w[i__ - 1];
        f = x * c__ + g * s;
        g = g * c__ - x * s;
        h__ = q[i__] * s;
        y = q[i__] * c__;
        if (mv == 0) {
          goto L330;
        }
        i__3 = *n;
        for (j = 1; j <= i__3; ++j) {
          x = v[j + (i__ - 1) * v_dim1];
          v[j + (i__ - 1) * v_dim1] = v[j + i__ * v_dim1] * s + x * c__;
          v[j + i__ * v_dim1] = v[j + i__ * v_dim1] * c__ - x * s;
        }

L330:
        q[i__ - 1] = sqrt(f * f + h__ * h__);
        c__ = f / q[i__ - 1];
        s = h__ / q[i__ - 1];
        f = g * c__ + y * s;
        x = y * c__ - g * s;
        if (mu == 0) {
          goto L350;
        }
        i__3 = *m;
        for (j = 1; j <= i__3; ++j) {
          y = u[j + (i__ - 1) * u_dim1];
          u[j + (i__ - 1) * u_dim1] = u[j + i__ * u_dim1] * s + y * c__;
          u[j + i__ * u_dim1] = u[j + i__ * u_dim1] * c__ - y * s;
        }

L350:
        ;
      }
      w[l] = 0.0;
      w[k] = f;
      q[k] = x;
    }
    goto L480;

L370:
    if (q[k] >= 0.0) {
      goto L390;
    }
    q[k] = -q[k];
    if (mv == 0) {
      goto L390;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
      v[j + k * v_dim1] = -v[j + k * v_dim1];
    }

L390:
    ;
  }
  if (*n == 1) {
    goto L470;
  }
  k = mn;

L400:
  l = 1;
  ii = 1;
  ll = 1;
  i__2 = k;
  for (i__ = 2; i__ <= i__2; ++i__) {
    if (q[i__] > q[l]) {
      goto L410;
    }
    l = i__;
    goto L420;

L410:
    ii = i__;
    ll = l;

L420:
    ;
  }
  if (ii == ll) {
    goto L460;
  }
  s = q[ii];
  q[ii] = q[ll];
  q[ll] = s;
  if (mv == 0) {
    goto L440;
  }
  i__2 = *n;
  for (j = 1; j <= i__2; ++j) {
    s = v[j + ii * v_dim1];
    v[j + ii * v_dim1] = v[j + ll * v_dim1];
    v[j + ll * v_dim1] = s;
  }

L440:
  if (mu == 0) {
    goto L460;
  }
  i__2 = *m;
  for (j = 1; j <= i__2; ++j) {
    s = u[j + ii * u_dim1];
    u[j + ii * u_dim1] = u[j + ll * u_dim1];
    u[j + ll * u_dim1] = s;
  }

L460:
  k = ii - 1;
  if (k >= 2) {
    goto L400;
  }

L470:
  *ind = 0;
  return 0;

L480:
  *ind = 20000;

L490:
  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/*
 * ==> C READY <==
 */
static double d_sign(double a, double b)
{
  double x;

  x = (a >= 0 ? a : -a);
  return (b >= 0 ? x : -x);
}
