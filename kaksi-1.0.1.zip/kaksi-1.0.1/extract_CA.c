/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Store the CA's coordinates of PDB structure in array coo_CA.
 */
void extract_CA(pdb_t *pdb, double **coo_CA, int nc)
{
  int k, ires, iat, nCA, Nres, hetatmInSeqres;
  char chainId, *ali = NULL;

  Nres = pdb->chain_nres[nc];
  chainId = pdb->chainNames[nc];
  ali = pdb->ali[nc];
  hetatmInSeqres = pdb->hetatmInSeqres[nc];

  iat = 0;
  nCA = 0;
  for (ires = 0; ires < Nres; ires++) {
    if (ali[ires] == '-') {
      /*
       * If the residue is missing in ATOM records use -999.999 for
       * the CA coordinates
       */
      for (k = 0; k < 3; k++) {
        coo_CA[nCA][k] = -999.999;
      }
      nCA++;
    } else {
      /*
       * If the residue exists in ATOM records, i.e., if ali[ires] != '-',
       * then scan the PDB structure for the coordinates of its CA atom
       * which is atomname and must be equal to " CA " and chainId  must
       * correspond to the current chain. Check also for alternate locations.
       * Two cases exist:
       * 1) there are hetero atoms in SEQRES
       * 2) there is no hetero atom in SEQRES
       * For case 1 both HETATM and ATOM records must be scanned.
       * For case 2 only ATOM records must be scanned.
       */
      if (hetatmInSeqres) {
        while (pdb->chainID[iat] != chainId
            || strcmp(pdb->atomname[iat], " CA ") != 0
            || (pdb->altLoc[iat] != pdb->selectedAltLoc[nc]
              && pdb->altLoc[iat] != ' ')) {
          iat++;
          if (iat >= pdb->nat) {
            break;
          }
        }
      } else { /* No hetero atom, so skip HETATM records */
        while (strcmp(pdb->atomtype[iat], "HETATM") == 0
            || pdb->chainID[iat] != chainId
            || strcmp(pdb->atomname[iat], " CA ") != 0
            || (pdb->altLoc[iat] != pdb->selectedAltLoc[nc]
              && pdb->altLoc[iat] != ' ')) {
          iat++;
          if (iat >= pdb->nat) {
            break;
          }
        }
      }

      if (iat >= pdb->nat) {
        ERROR_TAG;
        Erreur(1, "Error: cannot find CA for residue %c (%d) in PDB "
            "structure\n", ali[ires], ires + 1);
      }

      /*
       * Check that residue names match in pdb and ali
       */
      if (residue_type(pdb->resname[iat]) == ali[ires]) {
/*
        printf("nCA = %d\n", nCA);
        fflush(stdout);
*/
        for (k = 0; k < 3; k++) {
          coo_CA[nCA][k] = pdb->coo[iat][k];
        }
        nCA++;
        iat++;
      } else {
        ERROR_TAG;
        Erreur(1, "Error: For atom %d, resname = '%c' and ali[%d] = '%c' "
            "for chain '%c'\n", iat, residue_type(pdb->resname[iat]), ires,
            ali[ires], pdb->chainID[iat]);
      }
    }
  }
}
