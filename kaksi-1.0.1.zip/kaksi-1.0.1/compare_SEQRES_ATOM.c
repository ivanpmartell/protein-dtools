/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

#define EPS 0.001

/*******************************************************************************
 * LOCAL DATA STRUCTURES
 ******************************************************************************/
struct NW_data
{
  double cost_mat[21][21];
  double gap_open;
  double gap_ext;
};

/*******************************************************************************
 * LOCAL FUNCTIONS
 ******************************************************************************/
static void correctAlignmentErrors(pdb_t *pdb, char *ali1, char *ali2);
static int correctForward(int gapbeg, int gapend, char *ali1, char *ali2,
    pdb_t *pdb);
static void correctBackward(int gapbeg, int gapend, char *ali1, char *ali2,
    pdb_t *pdb);
static double calcDist(pdb_t *pdb, int prevRes, int Res);
static int getPDBnum(pdb_t *pdb, char *ali2, int resnum);
static int getPrevCa(pdb_t *pdb, int res);
static int getNextCa(pdb_t *pdb, int res);
static void checkSequences(char *seq1, char *seq2, char *ali1, char *ali2);
static void Align(double **aa, int i, int j, int ikeep, int jkeep, int *naln,
    int len1, char *seq1, int len2, char *seq2, char **path, char *ali1,
    char *ali2);
static int seq_indx(int c);
#ifdef DEBUG
static void printmat1(FILE * fpout, char *title, char **aa, int len1,
    char *seq1, int len2, char *seq2);
static void printmat(FILE * fpout, char *title, double **aa, int len1,
    char *seq1, int len2, char *seq2);
#endif

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Compare the sequences found in SEQRES and those
 * found in ATOM. To do this a sequence alignment
 * between the SEQRES and ATOM sequences is carried
 * out. Then several checks are performed to make
 * sure that the 2 sequences are consistent
 */

void compare_SEQRES_ATOM(struct MiscTransfer *MT, pdb_t *pdb,
    struct RecordTransfer *SEQRESrec, struct RecordTransfer *ATOMrec)
{
  int i;
  int ncA; /**< number of chains for the ATOM field */
  int ncS; /**< number of chains for the SEQRES field */
  char *ali_error;
  int nerr;

/*
 * Check number of correct chains BEFORE
 */
  for (i = 0, ncS = 0; i < SEQRESrec->Nchain; i++) {
    if (MT->nucleic[i] == 0) {
      ncS++;
    }
  }
  for (i = 0, ncA = 0; i < ATOMrec->Nchain; i++) {
    if (MT->validATOMchains[i] == 1) {
      ncA++;
    }
  }
  if (ncS != ncA) {
    ERROR_TAG;
    Erreur(1, "Error: The number of chains in the SEQRES record (%d) is "
        "different than the number of chains in the ATOM record (%d)\n",
        ncS, ncA);
  }
  if (ncS == 0) {
    ERROR_TAG;
    Erreur(1, "Error: Unable to match correct chains between SEQRES and ATOM\n");
  }

/*
 * It is possible for the number of  residues in ATOM records to be less 
 * than the corresponding number in SEQRES records. The converse should
 * never occur. In that case, the chain is skipped.
 */
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    if (MT->nucleic[ncS] == 1) {
      continue;
    }

    ncA = getATOMchainNumber(ncS, MT, ATOMrec, SEQRESrec);

    if (ATOMrec->chain_nres[ncA] > SEQRESrec->chain_nres[ncS]) {
      Erreur(0, "Warning: For chain '%c' the number of residues in SEQRES "
          "records (%d) is less than the number of residues in ATOM "
          "records (%d), skipping this chain...\n", SEQRESrec->chainName[ncS],
          SEQRESrec->chain_nres[ncS], ATOMrec->chain_nres[ncA]);
      MT->validATOMchains[ncA] = 0;
      MT->nucleic[ncS] = 1;
    }
  }

  CALLOC(MT->ali2, ATOMrec->Nchain);
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    if (MT->nucleic[ncS] == 1) {
      continue;
    }

    ncA = getATOMchainNumber(ncS, MT, ATOMrec, SEQRESrec);

    ALLOC(MT->ali2[ncA], 2 * SEQRESrec->chain_nres[ncS] + 1);
    MT->ali2[ncA][0] = '\0';
  }

/*
 * In theory the alignment cannot be longer than the sequence in SEQRES
 * but to be conservative twice this space is allocated for ali1[i] and
 * ali2[i]. Note that ali2[i] must have the same length as ali1[i]
 */
  ALLOC(MT->ali1, SEQRESrec->Nchain);
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    if (MT->nucleic[ncS] == 1) {
      continue;
    }
    ALLOC(MT->ali1[ncS], 2 * SEQRESrec->chain_nres[ncS] + 1);
    MT->ali1[ncS][0] = '\0';
  }

/*
 * Perform sequence alignment between the SEQRES and ATOM sequences
 */
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    if (MT->nucleic[ncS] == 1) {
      continue;
    }

    ncA = getATOMchainNumber(ncS, MT, ATOMrec, SEQRESrec);

    checkSequences(SEQRESrec->seq[ncS], ATOMrec->seq[ncA], MT->ali1[ncS],
        MT->ali2[ncA]);
    correctAlignmentErrors(pdb, MT->ali1[ncS], MT->ali2[ncA]);
  }

/*
 * Check that everything is ok
 */
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    if (MT->nucleic[ncS] == 1) {
      continue;
    }

    ncA = getATOMchainNumber(ncS, MT, ATOMrec, SEQRESrec);

    ALLOC(ali_error, 2 * SEQRESrec->chain_nres[ncS] + 1);
    memset(ali_error, ' ', 2 * SEQRESrec->chain_nres[ncS]);
    ali_error[2 * SEQRESrec->chain_nres[ncS]] = '\0';

    nerr = 0;
    for (i = 0; MT->ali1[ncS][i] != '\0'; i++) {
      if (MT->ali1[ncS][i] == '-') {
        Erreur(0, "For chain '%c' at position %d insertion in "
            "SEQRES sequence!\n", SEQRESrec->chainName[ncS], i);
        nerr++;
      }
      if (MT->ali2[ncA][i] != '-' && MT->ali1[ncS][i] != MT->ali2[ncA][i]) {
        Erreur(0, "For chain '%c' at position %d SEQRES "
            "sequence = '%c' ATOM sequence = '%c'\n", ATOMrec->chainName[ncA], i,
            MT->ali1[ncS][i], MT->ali2[ncA][i]);
        ali_error[i] = '?';
        nerr++;
      }
    }

    if (nerr != 0) {
      fprintf(stderr, "\nAlignment between sequences in SEQRES and "
          "ATOM for chain %c\n", SEQRESrec->chainName[ncS]);
      fprintf(stderr, "%s\tSEQRES\n", MT->ali1[ncS]);
      fprintf(stderr, "%s\n", ali_error);
      fprintf(stderr, "%s\tATOM\n\n", MT->ali2[ncA]);
      Erreur(0, "Warning: too many errors for this chain (%d), "
          "skipping it...\n", nerr);
      MT->validATOMchains[ncA] = 0;
      MT->nucleic[ncS] = 1;
    }

    FREE(ali_error);
  }

/*
 * Check number of correct chains AFTER
 */
  for (i = 0, ncS = 0; i < SEQRESrec->Nchain; i++) {
    if (MT->nucleic[i] == 0) {
      ncS++;
    }
  }
  for (i = 0, ncA = 0; i < ATOMrec->Nchain; i++) {
    if (MT->validATOMchains[i] == 1) {
      ncA++;
    }
  }
  if (ncS != ncA) {
    ERROR_TAG;
    Erreur(1, "Error: The number of chains in the SEQRES record (%d) is "
        "different than the number of chains in the ATOM record (%d)\n",
        ncS, ncA);
  }
  if (ncS == 0) {
    ERROR_TAG;
    Erreur(1, "Error: No matching chains between SEQRES and ATOM\n");
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * This routines is intended to correct alignment errors such as those shown below. 
 *
 *            130       140       150       160       170       180
 *     TGEQALEICDALARSGAVDVIVVDSVAALTPKAEIEGEIGDSHMGLAARMMSQAMRKLAG <-- ali1 == SEQRES records
 *     :::::::::::::::::::::::::::::::::::::        :::::::::::::::                           
 *     TGEQALEICDALARSGAVDVIVVDSVAALTPKAEIEg--------LAARMMSQAMRKLAG <-- ali2 == ATOM records  
 *    120       130       140       150    ^       ^  160       170
 *                                         |       |
 *                                         |       |
 *                                         g------>G
 * The first g should in fact be aligned with the last G before LAAR. There is no 
 * way for the alignment program to distinguish these 2 cases and thus the error 
 * must be corrected in this function. This kind of error occurs only when the
 * sequences bordering the gap are identical.
 * To fix the problem the idea is to check the CA-CA distance between the first
 * residue after the gap (here L) and the previous residue in the ATOM record
 * (here the offending G). If the CA-CA distance is less than 4.0 A the 2 residues
 * are neigbors and the residue should be moved in ali2 just before L (and replaced
 * by a '-'at its old position). (Note: this is the forward case)
 * 
 * The symmetric (backward) case can also be found, for instance in the alignment below:
 *
 *             70        80        90       100       110       120
 *     RLRSAFIPDDDKVRIGFAYAPKCAPSPWWTVVEDEQEGLSVKLSEDESTQFDYPFKFEQV <-- ali1 == SEQRES records
 *     ::::::::::::::::::::::::::::::::    ::::::::::::::::::::::::                           
 *     RLRSAFIPDDDKVRIGFAYAPKCAPSPWWTVV----eGLSVKLSEDESTQFDYPFKFEQV <-- ali2 == ATOM records  
 *             70        80        90  ^   ^    100       110      
 *                                     |   |
 *                                     |   |
 *                                     E<--e
 * the e at position 97 before GLSVKL... should in fact be placed at position 93 after the 
 * last V of ...WWTVV.
 *
 */
static void correctAlignmentErrors(pdb_t *pdb, char *ali1, char *ali2)
{
  int naln;
  int i;
  int start, stop;
  int gapbeg, gapend;
  int change;
  naln = strlen(ali2);

/*
 * Skip the Nterm and Cterm gaps if any
 */
  start = 0;
  for (i = 0; i < naln; i++) {
    if (ali2[i] != '-') {
      start = i;
      break;
    }
  }
  stop = naln - 1;
  for (i = naln - 1; i >= 0; i--) {
    if (ali2[i] != '-') {
      stop = i;
      break;
    }
  }

/*
 * Look for gaps inside the sequence 
 */
  gapbeg = gapend = -1;
  for (i = start; i <= stop; i++) {
    if (ali2[i] == '-') {
      if (gapbeg < 0) {
        gapbeg = i;
      }
    } else {
      if (gapbeg > -1) { /* Found a zone of gaps */
        gapend = i;
        change = correctForward(gapbeg, gapend, ali1, ali2, pdb);
#ifdef DEBUG
        printf("\ngap found %d %d\n", gapbeg, gapend);
        printf("after forward\n%s\n", ali2);
#endif
        if (change == 0) {
          correctBackward(gapbeg, gapend, ali1, ali2, pdb);
#ifdef DEBUG
          printf("after backward\n%s\n", ali2);
#endif
        }
        gapbeg = gapend = -1;
      }
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static int correctForward(int gapbeg, int gapend, char *ali1, char *ali2,
    pdb_t *pdb)
{
  int k;
  int change = 0; /* indicates whether a correction has been made or not */
  int Nsimil;
  int Res, nextRes;

/*
 * Check whether the sequence are similar on the gap borders
 */
  k = 0;
  while (gapbeg - (k + 1) >= 0 &&
      ali1[gapbeg - (k + 1)] == ali1[gapend - (k + 1)]) {
    k++;
  }
  Nsimil = k;

/*
 * Nsimil residues are similar on the gap borders! Check the CA-CA distances
 */
  if (Nsimil > 0) {
    for (k = 1; k <= Nsimil; k++) {
      Res = getPDBnum(pdb, ali2, gapbeg - k);
      nextRes = getNextCa(pdb, Res);
      /*
       * If the distance between 2 consecutive CAs is more than 3.8 A 
       * then the CAs cannot be neighbors in the sequence
       */
      if (calcDist(pdb, nextRes, Res) > 4.0) {
        break;
      }
      /*
       * ...else move the residue in the alignment array to its proper place
       */
      ali2[gapend - k] = ali2[gapbeg - k];
      ali2[gapbeg - k] = '-';
      change = 1;
    }
  }
  return change;
}

/*******************************************************************************
 *
 ******************************************************************************/
static void correctBackward(int gapbeg, int gapend, char *ali1, char *ali2,
    pdb_t *pdb)
{
  int k;
  int Nsimil;
  int Res, prevRes;

/*
 * Check whether the sequence are similars on the gap borders
 */
  k = 0;
  while ((gapbeg + k) < (int) strlen(ali1)
      && ali1[gapbeg + k] == ali1[gapend + k]) {
    k++;
  }
  Nsimil = k;

/*
 * Nsimil residues are similar on the gap borders! Check the CA-CA distances
 */
  if (Nsimil > 0) {
    for (k = 0; k < Nsimil; k++) {
      Res = getPDBnum(pdb, ali2, gapend + k);
      prevRes = getPrevCa(pdb, Res);
      /*
       * If the distance between 2 consecutive CAs is more than 3.8 A 
       * then the CAs cannot be neighbors in the sequence
       */
      if (calcDist(pdb, prevRes, Res) > 4.0) {
        break;
      }
      /*
       * ...else move the residue in the alignment array to its proper place
       */
      ali2[gapbeg + k] = ali2[gapend + k];
      ali2[gapend + k] = '-';
    }
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
static double calcDist(pdb_t *pdb, int prevRes, int Res)
{
  double dist;
  int k;

  dist = 0.0;
  for (k = 0; k < 3; k++) {
    dist +=
        (pdb->coo[prevRes][k] - pdb->coo[Res][k]) * (pdb->coo[prevRes][k] -
        pdb->coo[Res][k]);
  }
  dist = sqrt(dist);
  return (dist);

}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Return the number of the CA atom of residue resnum in PDB coordinates
 */
static int getPDBnum(pdb_t *pdb, char *ali2, int resnum)
{
  int i, nca;
  int nres;
  char prev_iCode = '�';
  int prev_numres = -1000000;

  nca = 0;
  for (i = 0; i <= resnum; i++) {
    if (ali2[i] != '-')
      nca++;
  }

  nres = 0;
  for (i = 0; i < pdb->nat; i++) {
    if ((strcmp(pdb->atomname[i], " CA ") == 0) &&
        (pdb->numres[i] != prev_numres || pdb->iCode[i] != prev_iCode)) {
      nres++;
      prev_numres = pdb->numres[i];
      prev_iCode = pdb->iCode[i];
    }
    if (nres == nca) {
      return (i);
    }
  }

  ERROR_TAG;
  Erreur(1, "Error: Unable to find Ca %d in PDB coordinates\n", nca);

  return (-1);

}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Return the number of the CA atom of the residue before residue res
 */
static int getPrevCa(pdb_t *pdb, int res)
{
  int i;

  for (i = res - 1; i >= 0; i--) {
    if (strcmp(pdb->atomname[i], " CA ") == 0) {
      return (i);
    }
  }

  ERROR_TAG;
  Erreur(1, "Error: Unable to find prev Ca in PDB coordinates\n");

  return (-1);

}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Return the number of the CA atom of the residue next to residue res
 */
static int getNextCa(pdb_t *pdb, int res)
{
  int i;

  for (i = res + 1; i < pdb->nat; i++) {
    if (strcmp(pdb->atomname[i], " CA ") == 0) {
      return (i);
    }
  }

  ERROR_TAG;
  Erreur(1, "Error: Unable to find next Ca in PDB coordinates\n");

  return (-1);

}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Carry out a semiglobal alignment between sequences found in SEQRES and ATOM records
 * The matrix used is a diagonal matrix whose elements have a value of 10 and off-diagonal
 * elements a value of 0 (since we are supposed to compare similar sequences...)
 */
static void checkSequences(char *seq1, char *seq2, char *ali1, char *ali2)
{
  int i, j, k;
  int iaa, jaa;
  double **aa = NULL;
  char **path = NULL;
  char **del = NULL, **ins = NULL;
  struct NW_data NWD;
  int len1, len2;
  int naln;
  double values[3];
  double opt_val;
  int jkeep = 0, ikeep = 0;
  int equal[3], neq;
  double maxval;
  int path_filled;

/*
 * Initialise data
 */
  NWD.gap_open = -5.0;
  NWD.gap_ext = -1.0;
  for (i = 0; i < 21; i++) {
    for (j = 0; j < 21; j++) {
      if (i == j) {
        NWD.cost_mat[i][j] = 10.0;
      } else {
        NWD.cost_mat[i][j] = 0.0;
      }
    }
  }
  len1 = strlen(seq1);
  len2 = strlen(seq2);

/*
 * Allocate the work matrices
 */
  CALLOC2(aa, len1 + 1, len2 + 1);
  ALLOC2(path, len1 + 1, len2 + 1);
  ALLOC2(del, len1 + 1, len2 + 1);
  ALLOC2(ins, len1 + 1, len2 + 1);

/*
 * Initialise path, del and ins  matrices
 */
  for (i = 0; i <= len1; i++) {
    for (j = 0; j <= len2; j++) {
      path[i][j] = del[i][j] = ins[i][j] = ' ';
    }
  }

/*
 * Summation over the matrix
 */
  for (i = 1; i <= len1; i++) {
    iaa = seq_indx(seq1[i - 1]);
    for (j = 1; j <= len2; j++) {
      jaa = seq_indx(seq2[j - 1]);
      values[0] = aa[i - 1][j - 1] + NWD.cost_mat[iaa][jaa];
      if (del[i - 1][j] == '|') {
        values[1] = aa[i - 1][j] + NWD.gap_ext;
      } else {
        values[1] = aa[i - 1][j] + NWD.gap_open;
      }
      if (ins[i][j - 1] == '-') {
        values[2] = aa[i][j - 1] + NWD.gap_ext;
      } else {
        values[2] = aa[i][j - 1] + NWD.gap_open;
      }
      /*
       * Get the max value and fill array path, del, ins
       * In case of tie the order in path is: \ | -
       */
      maxval = -1000000000.;
      neq = 0;
      for (k = 0; k < 3; k++) {
        if (values[k] > maxval + EPS) {
          maxval = values[k];
          equal[neq] = k;
        } else if (fabs(values[k] - maxval) < EPS) {
          neq++;
          equal[neq] = k;
        }
      }
      /*
       * Assign the maxval to the current matrix element and record
       * from where this max val was obtained (possibly from several
       * directions).
       */
      aa[i][j] = maxval;
      for (k = 0; k <= neq; k++) {
        path_filled = 0;
        if (equal[k] == 0) {
          path[i][j] = '\\';
          path_filled = 1;
        } else if (equal[k] == 1) {
          del[i][j] = '|';
          if (!path_filled) {
            path[i][j] = '|';
          }
        } else if (equal[k] == 2) {
          ins[i][j] = '-';
          if (!path_filled) {
            path[i][j] = '-';
          }
        }
      }
    }
  }

#ifdef DEBUG
  printmat(stdout, "final matrix aa", aa, len1, seq1, len2, seq2);
  printmat1(stdout, "Matrix path", path, len1, seq1, len2, seq2);
  printmat1(stdout, "Matrix del", del, len1, seq1, len2, seq2);
  printmat1(stdout, "Matrix ins", ins, len1, seq1, len2, seq2);
#endif

/*
 * Look for the maximum value in the last row or last column
 */
  opt_val = aa[len1][1];
  for (j = 2; j <= len2; j++) {
    if (aa[len1][j] > opt_val) {
      opt_val = aa[len1][j];
      ikeep = len1;
      jkeep = j;
    }
  }
  for (i = 1; i <= len1; i++) {
    if (aa[i][len2] > opt_val) {
      opt_val = aa[i][len2];
      ikeep = i;
      jkeep = len2;
    }
  }

/*
 * Get the alignment
 */
  Align(aa, len1, len2, ikeep, jkeep, &naln, len1, seq1, len2, seq2, path, ali1,
      ali2);
  ali1[naln + 1] = '\0';
  ali2[naln + 1] = '\0';

/*
 * Print the score and the alignment
 */
/*
  fprintf(stdout, "Alignment of SEQRES sequence with ATOM sequence "
      "(score = %.0f):\n", opt_val);
  for (i = 0; i <= naln; i++) {
    fprintf(stdout, "%c", ali1[i]);
  }
  fprintf(stdout, "\n");
  for (i = 0; i <= naln; i++) {
    fprintf(stdout, "%c", ali2[i]);
  }
  fprintf(stdout, "\n\n");
*/
#ifdef DEBUG
  printmat1(stdout, "Path in matrix path", path, len1, seq1, len2, seq2);
#endif

/*
 * Free arrays allocated in this function
 */
  FREE2(aa);
  FREE2(path);
  FREE2(del);
  FREE2(ins);
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Obtain recursively the alignment using information stored in path.
 */
static void Align(double **aa, int i, int j, int ikeep, int jkeep, int *naln,
    int len1, char *seq1, int len2, char *seq2, char **path, char *ali1,
    char *ali2)
{
  if (i == 0 && j == 0) {
    *naln = -1;
  } else if (i == 0 && j > 0) {
    Align(aa, i, j - 1, ikeep, jkeep, naln, len1, seq1, len2, seq2, path, ali1,
        ali2);
    *naln += 1;
    ali1[*naln] = '-';
    ali2[*naln] = seq2[j - 1];
  } else if (i > 0 && j == 0) {
    Align(aa, i - 1, j, ikeep, jkeep, naln, len1, seq1, len2, seq2, path, ali1,
        ali2);
    *naln += 1;
    ali1[*naln] = seq1[i - 1];
    ali2[*naln] = '-';
  } else if (i == ikeep && j > jkeep) {
    Align(aa, i, j - 1, ikeep, jkeep, naln, len1, seq1, len2, seq2, path, ali1,
        ali2);
    *naln += 1;
    ali1[*naln] = '-';
    ali2[*naln] = seq2[j - 1];
  } else if (i > ikeep && j == jkeep) {
    Align(aa, i - 1, j, ikeep, jkeep, naln, len1, seq1, len2, seq2, path, ali1,
        ali2);
    *naln += 1;
    ali1[*naln] = seq1[i - 1];
    ali2[*naln] = '-';
  } else if (path[i][j] == '\\' || path[i][j] == '4' || path[i][j] == '5' ||
      path[i][j] == '7') {
    Align(aa, i - 1, j - 1, ikeep, jkeep, naln, len1, seq1, len2, seq2, path,
        ali1, ali2);
    *naln += 1;
    ali1[*naln] = seq1[i - 1];
    ali2[*naln] = seq2[j - 1];
    path[i][j] = '#';
  } else if (path[i][j] == '|' || path[i][j] == '6') {
    Align(aa, i - 1, j, ikeep, jkeep, naln, len1, seq1, len2, seq2, path, ali1,
        ali2);
    *naln += 1;
    ali1[*naln] = seq1[i - 1];
    ali2[*naln] = '-';
    path[i][j] = '#';
  } else if (path[i][j] == '-') {
    Align(aa, i, j - 1, ikeep, jkeep, naln, len1, seq1, len2, seq2, path, ali1,
        ali2);
    *naln += 1;
    ali1[*naln] = '-';
    ali2[*naln] = seq2[j - 1];
    path[i][j] = '#';
  } else {
    ERROR_TAG;
    Erreur(1, "Error: Invalid value of i=%d j=%d, ikeep=%d jkeep=%d\n",
        i, j, ikeep, jkeep);
  }
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * This function returns an integer for each amino acid type.
 */
static int seq_indx(int c)
{

  switch (c) {
  case 'A':
    return (0);
  case 'C':
    return (1);
  case 'D':
    return (2);
  case 'E':
    return (3);
  case 'F':
    return (4);
  case 'G':
    return (5);
  case 'H':
    return (6);
  case 'I':
    return (7);
  case 'K':
    return (8);
  case 'L':
    return (9);
  case 'M':
    return (10);
  case 'N':
    return (11);
  case 'P':
    return (12);
  case 'Q':
    return (13);
  case 'R':
    return (14);
  case 'S':
    return (15);
  case 'T':
    return (16);
  case 'V':
    return (17);
  case 'W':
    return (18);
  case 'Y':
    return (19);
  case 'X':
    return (20);
  default:
    return (20);
  }
}

#ifdef DEBUG
/*******************************************************************************
 *
 ******************************************************************************/
/**
 * This function prints a matrix of doubles (doubleing point numbers)
 */
static void printmat(FILE * fpout, char *title, double **aa, int len1,
    char *seq1, int len2, char *seq2)
{
  int i, j;

  fprintf(fpout, "\n\n%s\n\n", title);

  fprintf(fpout, "      $  ");
  for (j = 0; j < len2; j++) {
    fprintf(fpout, " %c  ", seq2[j]);
  }
  fprintf(fpout, "\n");
  for (i = 0; i <= len1; i++) {
    fprintf(fpout, "%3d ", i);
    for (j = 0; j <= len2; j++) {
      fprintf(fpout, "%3.0f ", aa[i][j]);
    }
    if (i > 0) {
      fprintf(fpout, " %c\n", seq1[i - 1]);
    } else {
      fprintf(fpout, " $\n");
    }
  }
  fprintf(fpout, "    ");
  for (j = 0; j <= len2; j++) {
    fprintf(fpout, "%3d ", j);
  }
  fprintf(fpout, "\n");

}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * This function prints a matrix of characters
 */
static void printmat1(FILE * fpout, char *title, char **aa, int len1,
    char *seq1, int len2, char *seq2)
{
  int i, j;

  fprintf(fpout, "\n\n%s\n\n", title);

  fprintf(fpout, "   ");
  for (j = 0; j < len2; j++) {
    fprintf(fpout, " %c ", seq2[j]);
  }
  fprintf(fpout, "\n");

  for (i = 1; i <= len1; i++) {
    fprintf(fpout, "%2d ", i);
    for (j = 1; j <= len2; j++) {
      fprintf(fpout, " %c ", aa[i][j]);
    }
    fprintf(fpout, " %c\n", seq1[i - 1]);
  }
  fprintf(fpout, "   ");
  for (j = 1; j <= len2; j++) {
    fprintf(fpout, "%2d ", j);
  }
  fprintf(fpout, "\n");

}
#endif
