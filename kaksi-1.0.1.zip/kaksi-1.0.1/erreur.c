#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

void Erreur (int stat, char *fmt, ...)
{
  va_list args;

/*
 * message on stderr
 */
  va_start (args, fmt);
  vfprintf (stderr, fmt, args);
  va_end (args);

/*
 * and possibly exit...
 */
  if (stat != 0) {
    exit (stat);
  }
}
