#include <stdio.h>
#include <math.h>

#include "centroid.h"
#include "error.h"
#include "alloc.h"

/******************************************************************************
 *
 ******************************************************************************/
/**
 * Calculate the centroid of lim2-lim1+1 points stored in array cax.
 *
 * ==> C READY <==
 */
int centroid_(int lim1, int lim2, double *cax, double *cg)
{
  int k, iat;
  double fl;

  for (k = 0; k < 3; ++k) {
    cg[k] = 0.0;
  }

  for (iat = lim1; iat <= lim2; iat++) {
    for (k = 0; k < 3; k++) {
      cg[k] += cax[k + iat * 3];
    }
  }
  fl = (double) (lim2 - lim1 + 1);
  fl = 1.0 / fl;
  for (k = 0; k < 3; k++) {
    cg[k] *= fl;
  }

  return 0;
}

/******************************************************************************
 *
 ******************************************************************************/
/**
 * norm the vector u
 *
 * ==> C READY <==
 */
int vector_norm_(double *u)
{
  double rn;

  rn = u[0] * u[0] + u[1] * u[1] + u[2] * u[2];
  rn = sqrt(rn);
  if (fabs(rn) < 1e-6) {
    ERROR_TAG;
    Erreur(0, "Error: vector norm too small!\n");
  }
  u[0] /= rn;
  u[1] /= rn;
  u[2] /= rn;

  return 0;
}
