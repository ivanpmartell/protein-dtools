#ifndef _ERREUR_H
#define _ERREUR_H 1

void Erreur(int stat, char *fmt, ...);

#endif /* erreur.h */
