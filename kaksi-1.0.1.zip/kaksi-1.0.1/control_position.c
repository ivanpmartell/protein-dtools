/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "kaksi.h"
#include "util.h"

/*******************************************************************************
 *
 ******************************************************************************/
int Is_in_ext(int j, struct SEQUENCE *sseSequence, char c)
{
  if (sseSequence->seq[j] == c
      && (j == 0 || (j > 0 && j < sseSequence->length - 1
        && (sseSequence->seq[j - 1] != c || sseSequence->seq[j + 1] != c))
      || j == sseSequence->length - 1)) {
    return FALSE;
  }

  return TRUE;
}

/*******************************************************************************
 *
 ******************************************************************************/
int Is_in_heart(int j, struct SEQUENCE *sseSequence, char c)
{
  if (sseSequence->seq[j] == c
      && ((j == 1 && sseSequence->seq[j - 1] == c
        && sseSequence->seq[j + 1] == c && sseSequence->seq[j + 2] == c)
      || (j > 1 && j < sseSequence->length - 2 && sseSequence->seq[j - 2] == c
        && sseSequence->seq[j - 1] == c && sseSequence->seq[j + 1] == c
        && sseSequence->seq[j + 2] == c)
      || (j == sseSequence->length - 2 && sseSequence->seq[j + 1] == c
        && sseSequence->seq[j - 1] == c && sseSequence->seq[j - 2] == c))) {
    return FALSE;
  }

  return TRUE;
}

/*******************************************************************************
 *
 ******************************************************************************/
int Is_in_inter(int j, struct SEQUENCE *sseSequence, char c)
{
  if (sseSequence->seq[j] == c
      && ((j == 1 && sseSequence->seq[j - 1] == c
        && sseSequence->seq[j + 1] == c && sseSequence->seq[j + 2] != c)
      || (j > 1 && j < sseSequence->length - 2
        && sseSequence->seq[j - 1] == c && sseSequence->seq[j + 1] == c
        && (sseSequence->seq[j - 2] != c || sseSequence->seq[j + 2] != c))
      || (j == sseSequence->length - 2 && sseSequence->seq[j + 1] == c
        && sseSequence->seq[j - 1] == c && sseSequence->seq[j - 2] != c))) {
    return FALSE;
  }

  return TRUE;
}

/*******************************************************************************
 *
 ******************************************************************************/
int Is_in_C_ext(int j, struct SEQUENCE *sseSequence, char c)
{
  if (sseSequence->seq[j] == c
      && (j == sseSequence->length - 1
      || (j < sseSequence->length - 1 && sseSequence->seq[j + 1] != c))) {
    return FALSE;
  }

  return TRUE;
}

/*******************************************************************************
 *
 ******************************************************************************/
int Is_in_N_ext(int j, struct SEQUENCE *sseSequence, char c)
{
  if (sseSequence->seq[j] == c
      && (j == 0 || (j > 0 && sseSequence->seq[j - 1] != c))) {
    return FALSE;
  }

  return TRUE;
}

/*******************************************************************************
 *
 ******************************************************************************/
int Is_valid_angle(struct PHIPSI *PhiPsi, int index)
{
  if (index >= 0 && index < (PhiPsi->nCA)) {
    if (PhiPsi->Phi[index] <= 180 && PhiPsi->Psi[index] <= 180) {
      return FALSE;
    }
  }

  return TRUE;
}

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Compute the distance in Ramachandran map between two Phi/Psi couples
 * The 1/2 factor has been omitted in the comutation of reference value as well.
 * There is no modulo(180) : it is not a real rmsd angular value, we just to
 * check that the Phi/Psi angles stay near each others ***in the alpha zone***
 */
double distance_Rama(struct PHIPSI *PhiPsi, int index1, int index2)
{
  return sqrt(pow(PhiPsi->Phi[index1] - PhiPsi->Phi[index2],
          2) + pow(PhiPsi->Psi[index1] - PhiPsi->Psi[index2], 2));

}
