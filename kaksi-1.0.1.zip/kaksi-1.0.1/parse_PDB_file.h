/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#ifndef _PARSE_PDB_FILE_H
#define _PARSE_PDB_FILE_H 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <math.h>
#include <libgen.h> /* for basename */

/*******************************************************************************
 * OTHER DATA STRUCTURES AND MACROS
 ******************************************************************************/
#include "alloc.h"
#include "structure.h"

/*******************************************************************************
 *
 ******************************************************************************/

#define MIN_PARSE_SSE_LEN 20

/*******************************************************************************
 * DATA TYPES
 ******************************************************************************/
struct MiscTransfer {
  int *nucleic;          /* 0 the chain is a protein; 1 a nucleic acid */
  int *hetatmInSeqres;   /* 0 no hetero atoms in sequence; 1 there exist hetero atoms in sequence (in non standard residue) */
  int *validATOMchains;  /* Indicates if the chain in ATOM record must be processed (real chain, not hetatm at the end) */
  char **ali1;           /* alignment of sequence in SEQRES record with sequence in ATOM record (which is in ali2) */
  char **ali2;           /* alignment of sequence in ATOM record with sequence in SEQRES record (which is in ali1) */
  int **numres;          /* residue number in SEQRES numbering scheme (i.e., missing residues in ATOM are indicated by -1) */
  char **iCode;          /* insertion code in SEQRES numbering scheme (i.e., missing residues are indicated by '�') */
};

/**
 * This structure is used to transfer data between functions.
 * It stores similar data found in SEQRES and ATOM records.
 */
struct RecordTransfer {
  int Nchain;       /* Number of chains */
  int *chain_nres;  /* Number of residues in the chains */
  char *chainName;  /* Chain names */
  char **seq;       /* Chain sequences (1 letter code) */
};

/**
 * Structure to store the raw SEQRES field from the PDB file
 */
struct CHUNK {
  char chainId;
  int nres;
  char line[52];
  struct CHUNK *next;
};

/**
 * Structures (NODE & NODES) to store the raw HELIX, SHEET & TURN PDB fields
 */
struct NODE {
  char *line;
  struct NODE *next;
};

struct NODES {
  struct NODE *headHelix;
  struct NODE *headSheet;
  struct NODE *headTurn;
};

#endif /* parse_PDB_file.h */
