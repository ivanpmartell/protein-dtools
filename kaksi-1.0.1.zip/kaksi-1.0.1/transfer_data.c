/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Here everything is ok so transfer data to PDB structure.
 */
void transfer_data(pdb_t *pdb, struct MiscTransfer *MT,
    struct RecordTransfer *SEQRESrec, struct RecordTransfer *ATOMrec)
{
  int ncA, ncS;

  pdb->Nchains = SEQRESrec->Nchain;

  ALLOC(pdb->chainNames, SEQRESrec->Nchain + 1);
  strcpy(pdb->chainNames, SEQRESrec->chainName);

  ALLOC(pdb->chain_nres, SEQRESrec->Nchain);
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    pdb->chain_nres[ncS] = SEQRESrec->chain_nres[ncS];
  }

  CALLOC(pdb->ali, SEQRESrec->Nchain);
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    if (MT->nucleic[ncS] == 1) {
      continue;
    }

    ncA = getATOMchainNumber(ncS, MT, ATOMrec, SEQRESrec);

    ALLOC(pdb->ali[ncS], pdb->chain_nres[ncS] + 1);
    if ((int) strlen(MT->ali2[ncA]) > pdb->chain_nres[ncS]) {
      ERROR_TAG;
      Erreur(1, "Error: Alignment length= %d for chain '%c' exceeds "
          "corresponding seq length=%d (in SEQRES)\n", strlen(MT->ali2[ncA]),
          pdb->chainNames[ncS], pdb->chain_nres[ncS]);
    }
    strcpy(pdb->ali[ncS], MT->ali2[ncA]);
  }

  ALLOC(pdb->status, SEQRESrec->Nchain);
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    pdb->status[ncS] = MT->nucleic[ncS];
  }

  ALLOC(pdb->hetatmInSeqres, SEQRESrec->Nchain);
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    pdb->hetatmInSeqres[ncS] = MT->hetatmInSeqres[ncS];
  }

  CALLOC(pdb->seq, SEQRESrec->Nchain);
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    ALLOC(pdb->seq[ncS], pdb->chain_nres[ncS] + 1);
    strcpy(pdb->seq[ncS], SEQRESrec->seq[ncS]);
  }

/*
 * Find max residue number for all valid chains
 */
  pdb->max_nrS = 0;
  for (ncS = 0; ncS < SEQRESrec->Nchain; ncS++) {
    if (MT->nucleic[ncS] == 1) {
      continue;
    }
    if (SEQRESrec->chain_nres[ncS] > pdb->max_nrS) {
      pdb->max_nrS = SEQRESrec->chain_nres[ncS];
    }
  }
}
