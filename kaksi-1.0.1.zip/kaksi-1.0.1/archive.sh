#!/bin/sh

PKG_NAME="kaksi"
RELEASE=`grep "define VERSION" kaksi.c | cut -d '"' -f 2`
LOCAL_DIR=`pwd | tr '/' '\n' | tail -n 1`
TMP_DIR=${LOCAL_DIR}.archive_tmp
PKG_DIR="${PKG_NAME}-${RELEASE}"

cd ..
# Rename the local directory in case it has the same name as PKG_DIR
\mv -i $LOCAL_DIR $TMP_DIR
# Make a copy to work on
\cp -ri $TMP_DIR $PKG_DIR
# Remove the CVS directory
\rm -fr $(find $PKG_DIR -name CVS)
# Pack it all
tar cf ${PKG_DIR}.tar $PKG_DIR
gzip -9 ${PKG_DIR}.tar
# Remove the PKG directory
\rm -fr $PKG_DIR
# Move back the original directory
\mv -i $TMP_DIR $LOCAL_DIR
cd $LOCAL_DIR
