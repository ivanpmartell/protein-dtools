/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#ifndef _STRUCTURE_H
#define _STRUCTURE_H 1

/*******************************************************************************
 * DATA TYPES
 ******************************************************************************/
typedef struct ppf_args_s {
  char *pdb_dir;
  char pdb_fname[256];
  char pdb_code[16];
  char user_chain_id;
  int length_H;                      /**< minimum length for an alpha helix */
  int length_b;                      /**< minimum length for a beta strand */
  int turn;
  int separate_sse;                  /**< if 1, separate contiguous SSEs
                                          with a coil */
  int remove_sse;                    /**< if 1, remove SSEs with length
                                          inferior to length_H and length_b */
} ppf_args_t;

struct PHIPSI {
  int nCA;     /* tableau avec le nombre de carbones alpha dans chaque chaine */
  double *Phi;  /* tableau de tableau avec les angles dans chaque chaine */
  double *Psi;
  char *Omega;    /**< Is it a cis bond ? */
  int *index;
  char *chainID;
  char *resName;
  char *iCode;
};

struct SEQUENCE {
  int length;
  char *seq;
};

/**
 * nc = number of chains
 * nr = number of residues
 * na = number of atoms
 */
typedef struct pdb_s {
  char pdb_code[16];     /**< PDB code read in the PDB file */
  int max_nrS;           /**< maximum number of residues in SEQRES
                              for all chains */

/*
 * chain dependant variables
 */
  int prot_Nchains;      /**< Number of protein chains */
  int Nchains;           /**< Number of chains */
  char *chainNames;      /**< Chain names */
  int *chain_nres;       /**< Number of residues for each chain */
  int *status;           /**< Chain status:
                              0 : chain is ok
                              1 : chain is a nucleic acid
                              2 : chain is too small */
  int *hetatmInSeqres;   /**< 0 means no hetero atoms in sequence, 1 otherwise */
  char *selectedAltLoc;  /**< contain the name of the selected
                              alternate location to use */
  int *sep_sse_count;    /**< for each chain, count the number of SSEs
                              separated afterward with a coil */
  int *rem_sse_count;    /**< for each chain, count the number of SSEs
                              removed afterward (because it is too small) */

/*
 * chain and residue dependant variables [nc][nr]
 */
  double **curvature;     /**< local curvature */
  char **seq;            /**< SEQRES sequence in 1 letter code */
  char **ali;            /**< alignment between ATOM and SEQRES */
  char **sse;            /**< PDB defined secondary structure */
  int **SEQRESnumres;    /**< residue number for each chain */
  char **SEQRESiCode;    /**< insertion code for each chain */

/*
 * atom dependant variables
 */
  int nat;               /**< Number of atoms in all chains */
  int *numatom;          /**< atom number */
  char **atomtype;       /**< atom type = 'ATOM  ' or 'HETATM' */
  char **atomname;       /**< atom name */
  char *altLoc;          /**< alternate location name */
  char **resname;        /**< residue name */
  char *chainID;         /**< chain name */
  int *numres;           /**< residue number */
  char *iCode;           /**< insertion code */
  double **coo;          /**< CA coordinates */
  double *tfactor;        /**< temperature factor */
  double *occupancy;      /**< occupancy */
} pdb_t;

#endif /* structure.h */
