/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

/*******************************************************************************
 *
 ******************************************************************************/
/**
 * Process the sequences found in SEQRES records
 */
void process_SEQRES_record(struct CHUNK *headchunk,
    struct RecordTransfer *SEQRESrec, struct MiscTransfer *MT)
{
  int i;
  int nc;
  int nr1;
  char prevchainId;
  struct CHUNK *ch;
  char aa[4] = "aaa";

  if (headchunk == NULL) {
    fprintf(stderr, "Error: no SEQRES field in PDB file!\n");
    exit(1);
  }

/*
 * Initialize MT->nucleic at FALSE
 */
  for (i = 0; i < SEQRESrec->Nchain; i++) {
    MT->nucleic[i] = 0;
  }

/*
 * Determine the name and the number of residues
 * for each chain according to the SEQRES records.
 */
  SEQRESrec->chainName[0] = headchunk->chainId;
  SEQRESrec->chain_nres[0] = headchunk->nres;
  prevchainId = SEQRESrec->chainName[0];
  nc = 0;
  for (ch = headchunk; ch != NULL; ch = ch->next) {
    if (ch->chainId != prevchainId) {
      nc++;
      SEQRESrec->chainName[nc] = ch->chainId;
      SEQRESrec->chain_nres[nc] = ch->nres;
    }
    prevchainId = ch->chainId;
  }

/*
 * Read in SEQRESrec->seq the chain sequences
 */
  ALLOC(SEQRESrec->seq, SEQRESrec->Nchain);
  for (i = 0; i < SEQRESrec->Nchain; i++) {
    ALLOC(SEQRESrec->seq[i], SEQRESrec->chain_nres[i] + 1);
  }

/*
 * Check if the sequence length is ok
 */
  prevchainId = SEQRESrec->chainName[0];
  nr1 = 0;
  nc = 0;
  for (ch = headchunk; ch != NULL; ch = ch->next) {
    if (ch->chainId != prevchainId) {
      if (nr1 < MIN_PARSE_SSE_LEN) {
        MT->nucleic[nc] = 1;
      }
      if (nr1 != SEQRESrec->chain_nres[nc]) {
        fprintf(stderr, "Warning: in SEQRES records for chain '%c' the "
            "number of residues indicated is %d but the number of residues "
            "really read in is %d\n", prevchainId, SEQRESrec->chain_nres[nc],
            nr1);
        fprintf(stderr, "The number of residues is reset to what has "
            "been read in SEQRES\n");
        if (nr1 > SEQRESrec->chain_nres[nc]) {
          SEQRESrec->seq[nc] = realloc(SEQRESrec->seq[nc],
              (nr1 + 1) * sizeof(char));
        }
        SEQRESrec->chain_nres[nc] = nr1;
      }
      nr1 = 0;
      nc++;
    }
    for (i = 0; i < 52; i += 4) {
      strncpy(aa, ch->line + i, 3);
      aa[3] = '\0';
      if (strcmp(aa, "ACE") == 0 || strcmp(aa, "NH2") == 0) {
        SEQRESrec->chain_nres[nc]--;
        continue;
      }
      if (strcmp(aa, "   ") == 0 || aa[0] == '\n'
          || strcmp(aa, "\0\0\0") == 0) {
        break;
      }
      nr1++;
    }
    prevchainId = ch->chainId;
  }
/* last chain */
  if (nr1 < MIN_PARSE_SSE_LEN) {
    MT->nucleic[nc] = 1;
  }
  if (nr1 != SEQRESrec->chain_nres[nc]) {
    fprintf(stderr, "Warning: in SEQRES records for "
        "chain '%c' the number of residues indicated is %d but the number "
        "of residues really read in is %d\n", prevchainId,
        SEQRESrec->chain_nres[nc], nr1);
    fprintf(stderr, "The number of residues is reset to what has been read "
        "in SEQRES\n");
    if (nr1 > SEQRESrec->chain_nres[nc]) {
      SEQRESrec->seq[nc] = realloc(SEQRESrec->seq[nc],
          (nr1 + 1) * sizeof(char));
    }
    SEQRESrec->chain_nres[nc] = nr1;
  }

/*
 * Really fill the structure
 */
  prevchainId = SEQRESrec->chainName[0];
  nr1 = 0;
  nc = 0;
  for (ch = headchunk; ch != NULL; ch = ch->next) {
    if (ch->chainId != prevchainId) {
      SEQRESrec->seq[nc][nr1] = '\0';
      nr1 = 0;
      nc++;
    }
    for (i = 0; i < 52; i += 4) {
      strncpy(aa, ch->line + i, 3);
      aa[3] = '\0';
      if (strcmp(aa, "ACE") == 0 || strcmp(aa, "NH2") == 0) {
        continue;
      }
      if (strcmp(aa, "   ") == 0 || aa[0] == '\n'
          || strcmp(aa, "\0\0\0") == 0) {
        break;
      }
      SEQRESrec->seq[nc][nr1] = residue_type(aa);
      nr1++;
    }
    prevchainId = ch->chainId;
  }
/* last chain */
  SEQRESrec->seq[nc][nr1] = '\0';

/*
 * If more than 50% of the residues are X the chain,
 * tag the chain to skip it later.
 */
  for (nc = 0; nc < SEQRESrec->Nchain; nc++) {
    MT->hetatmInSeqres[nc] = 0;
    for (i = 0; i < SEQRESrec->chain_nres[nc]; i++) {
      if (SEQRESrec->seq[nc][i] == 'X')
        MT->hetatmInSeqres[nc]++;
    }
    if ((double) MT->hetatmInSeqres[nc] / (double) SEQRESrec->chain_nres[nc] > 0.5) {
      MT->nucleic[nc] = 1;
    }
/*
    printf("SEQRES chain %2d '%c', nr = %5d, nucleic = %d\n", nc,
        SEQRESrec->chainName[nc], SEQRESrec->chain_nres[nc], MT->nucleic[nc]);
    fflush(stdout);
*/
  }
}
