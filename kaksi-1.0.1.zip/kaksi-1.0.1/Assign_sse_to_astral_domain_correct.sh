SHELL=/bin/bash

################"

###############"
# Fournir en argument d'entree : un  fichier liste de domaines astral
##############
##############
# ATTENTION a l'option sep 1 ou sep 0

######## A changer ###########################
SCOP_CLA=/db/natif/scop/dir.cla.scop.txt_1.65
PARSE=/home/gibrat/PHI_PSI/parse_PDB_file				# extraction de la sequence et calcul des phi psi
REASSIGN=/home/gibrat/ASSIGN_SSE/kaksi	                                # utilise "identity.mat" � mettre dans le .bash_profile
RESULT_DIR=RES_DIR     							# repertoire temporaire ou sont stockes les resultats 
MASK_AWK=/home/gibrat/ASSIGN_SSE/angles.awk      			# masque dans le fichiers d'angles phi-psi les regions qui ne font pas partie du domaine

mkdir $RESULT_DIR

for i in $(\cat $1)
do     
     	echo "$i"     
	PDBCODE=`echo $i | cut -c2,3,4,5  `   # get PDB CODE, CHAINID  from the astral_id
	CHAINID=`echo $i | cut -c6  `
	RAB=`echo $i | cut -c7  `
     	
	if [ $i = ^e* ]
	then
	echo "  >$i pas traite" 
	echo $i >> domain_error.list
	elif 	[ $i = ^g* ]
	then
	echo "  >$i pas traite" 
	echo $i >> domain_error.list	
       # special case of domain 1dv1a2 #######################
       elif [ $i = "d1dv1a2" ]
       then
	echo " cas particulier"
	$PARSE -pdb $PDBCODE -cid $CHAINID -sep 0  # compute phi/psi
	mv  $PDBCODE*.fasta $RESULT_DIR/$i.fasta
	mv  $PDBCODE*.pdbnum $RESULT_DIR/$i.pdbnum
	mv  $PDBCODE*.sse $RESULT_DIR/$i.sse
	mv  $PDBCODE*.coo $RESULT_DIR/$i.coo
	
	mv $PDBCODE*.angles angles.tmp             	    
	NAME=$i.angles	       
	awk ' ((NF<=2) ) { printf $0 "\n";}'  angles.tmp  >> $NAME    # masque les regions hors du domaine
	awk -f $MASK_AWK  inf="2" sup="114" angles.tmp >> $NAME
	
	
	$REASSIGN -fcoo  $RESULT_DIR/$i.coo -fa $NAME    # assign sec struct
	mv $PDBCODE*.sse.new $RESULT_DIR/${i%%.angles}.sse.new
	mv $PDBCODE*.strandOrient $RESULT_DIR/${i%%.angles}.strandOrient
	mv $PDBCODE*.strandContact $RESULT_DIR/${i%%.angles}.strandContact
        mv $PDBCODE*.curv $RESULT_DIR/${i%%.angles}.curv
        mv temp1.pdb $RESULT_DIR/${i%%.angles}.curv.pdb
	mv $NAME $RESULT_DIR  # move new angles file
        rm -f angles.tmp			
	#####################################################
	
	
	#####################################################		
       elif [ $RAB = _ ]  # easy case :  like 1dlwa_ , the domain is the whole chain A  - just execute and move the output files
       then 	
	
		if $PARSE  -pdb $PDBCODE -cid $CHAINID  -sep 0 # check that files have been generated
		then		
		mv  $PDBCODE*.angles $RESULT_DIR/$i.angles
   		mv  $PDBCODE*.fasta $RESULT_DIR/$i.fasta
   		mv  $PDBCODE*.pdbnum $RESULT_DIR/$i.pdbnum
   		mv  $PDBCODE*.sse $RESULT_DIR/$i.sse
		mv  $PDBCODE*.coo $RESULT_DIR/$i.coo
		
		$REASSIGN -fcoo $RESULT_DIR/$i.coo  -fa $RESULT_DIR/$i.angles # assign sec struct
		mv $PDBCODE*.sse.new $RESULT_DIR/${i%%.angles}.sse.new
		mv $PDBCODE*.strandOrient $RESULT_DIR/${i%%.angles}.strandOrient
		mv $PDBCODE*.strandContact $RESULT_DIR/${i%%.angles}.strandContact
		mv $PDBCODE*.curv $RESULT_DIR/${i%%.angles}.curv
		mv temp1.pdb $RESULT_DIR/${i%%.angles}.curv.pdb
		else 
		echo "execution failed"
		echo $i >> domain_error.list
		fi			       
 	#######################################################
	
	 ########################################################"	 	 		
       else	# last case : like  d1adt_1 : the domain is a part of the chain   ATTENTION !!!! the domain can also #	      
       	        # be made of TWO parts frm the SAME CHAIN (hence the NUM loop)# 
	NUMREG=`grep $i $SCOP_CLA | awk '{printf($3)}' | awk 'BEGIN { FS = "," }{ printf NF}' `
	REG_INDEX=1
	
		if $PARSE  -pdb $PDBCODE -cid $CHAINID -sep 0  
		then
		mv -f $PDBCODE*.fasta $RESULT_DIR/$i.fasta
		mv -f $PDBCODE*.pdbnum $RESULT_DIR/$i.pdbnum
		mv -f $PDBCODE*.sse $RESULT_DIR/$i.sse
		mv -f $PDBCODE*.coo $RESULT_DIR/$i.coo
		
		mv $PDBCODE*.angles angles.tmp		

		CHAINID=`echo $CHAINID | tr '[:lower:]' '[:upper:]'` # create name for the new angles file
		NAME=$i.angles
		awk ' ((NF<=2) ) { printf $0 "\n";}'  angles.tmp  >> $NAME	
		BEGINREG=""
		ENDREG=""					
			while [ $REG_INDEX -le $NUMREG ]
			do			
			REG=`grep $i $SCOP_CLA | awk '{printf($3)}' | awk 'BEGIN { FS = "," }{ printf $n}' n=$REG_INDEX `				
		 
		 # post-process : cut the .angles, to keep only the region of interest		 								
					if [  `echo $REG | cut  -f2 -d: | cut -c1` = - ]
					#special case when the region starts at a negative position
					then 
					echo "region commencant par un indice negatif "
					BEGINREG="-`echo $REG | cut  -f2 -d: | cut -f2 -d- | tr '[:lower:]' '[:upper:]'` $BEGINREG"
					ENDREG="`echo $REG | cut  -f2 -d: | cut -f3 -d- | tr '[:lower:]' '[:upper:]'` $ENDREG" 													
		 			else
					echo "region commencant par un indice positif"
		 			BEGINREG="`echo $REG | cut  -f2 -d: | cut -f1 -d- | tr '[:lower:]' '[:upper:]' ` $BEGINREG " 
					ENDREG="` echo $REG | cut  -f2 -d: | cut -f2 -d- | tr '[:lower:]' '[:upper:]'` $ENDREG" 					
					fi																	
			echo "REGION " $REG	
			echo "DEBUT "$BEGINREG
			echo "FIN "$ENDREG		
			REG_INDEX=`expr $REG_INDEX + 1 `					
			done
				if  test "$ENDREG" = ""  && test "$BEGINREG" = "" 
				then echo "BIZARRE !!! chaine entiere ??"
				mv angles.tmp $NAME
				$REASSIGN -fcoo $RESULT_DIR/$i.coo  -fa $NAME
				mv $PDBCODE*.sse.new $RESULT_DIR/${i%%.angles}.sse.new
				mv $PDBCODE*.strandOrient $RESULT_DIR/${i%%.angles}.strandOrient
				mv $PDBCODE*.strandContact $RESULT_DIR/${i%%.angles}.strandContact
                 		mv $PDBCODE*.curv $RESULT_DIR/${i%%.angles}.curv
				mv temp1.pdb $RESULT_DIR/${i%%.angles}.curv.pdb
				mv $NAME $RESULT_DIR 						
				else 	
				awk -f $MASK_AWK  inf="$BEGINREG" sup="$ENDREG" angles.tmp  >> $NAME	
				$REASSIGN -fcoo $RESULT_DIR/$i.coo  -fa $NAME
				mv $PDBCODE*.sse.new $RESULT_DIR/${i%%.angles}.sse.new
				mv $PDBCODE*.strandOrient $RESULT_DIR/${i%%.angles}.strandOrient
				mv $PDBCODE*.strandContact $RESULT_DIR/${i%%.angles}.strandContact
                 		mv $PDBCODE*.curv $RESULT_DIR/${i%%.angles}.curv
				mv temp1.pdb $RESULT_DIR/${i%%.angles}.curv.pdb
				mv $NAME $RESULT_DIR  # move new angles file	
				fi
		 
		rm -f angles.tmp # and delete old	 
		else echo "     >execution failed "
			echo $i>> domain_error.list
		fi									
      fi     
done    
   
echo " all files in $LISTESCOP have been processed !" 
date
