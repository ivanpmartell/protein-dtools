/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#ifndef _M1QN3_H
#define _M1QN3_H 1

int m1qn3_(int (*simul) (), int (*prosca) (), int *n, double *x, double *f,
    double *g, double *dxmin, double *df1, double *epsg, int *impres, int *io,
    int *mode, int *niter, int *nsim, int *iperso, double *trav, int *ntrav,
    int *izs, double *rzs, double *dzs);

int m1qn3a_(int (*simul) (), int (*prosca) (), int *n, double *x, double *f,
    double *g, double *dxmin, double *df1, double *epsg, int *impres, int *io,
    int *mode, int *niter, int *nsim, int *iperso, int *m, double *d__,
    double *xx, double *gg, double *precon, double *aux, double *alpha,
    double *ybar, double *sbar, int *izs, double *rzs, double *dzs);

int strang2_(int (*prosca) (), int *n, int *nm, double *depl, int *jmin,
    int *jmax, double *precon, double *alpha, double *ybar, double *sbar,
    int *izs, double *rzs, double *dzs);

int mlis0_(int *n, int (*simul) (), int (*prosca) (), double *xn, double *fn,
    double *fpn, double *t, double *tmin, double *tmax, double *d__, double *g,
    double *amd, double *amf, int *imp, int *io, int *logic, int *nap,
    int *napmax, double *x, int *iter, int *izs, double *rzs, double *dzs);

int ecube_(double *t, double *f, double *fp, double *ta, double *fa,
    double *fpa, double *tg, double *td);

int prosca_(int n, double *a, double *b, double *ps);

#endif /* m1qn3.h */
