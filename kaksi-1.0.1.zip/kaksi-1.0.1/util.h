/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"

#ifndef _UTIL_H
#define _UTIL_H 1

#define MIN2(a,b) ((a) < (b) ? (a) : (b))
#define MAX2(a,b) ((a) > (b) ? (a) : (b))
#define TRUE 1
#define FALSE 0

int getATOMchainNumber(int current_nc, struct MiscTransfer *MT,
    struct RecordTransfer *ATOMrec, struct RecordTransfer *SEQRESrec);

char *aa1_to_aa3(char aa1);

void set_pdb_file(char *pdb_file, char *pdb_dir, char *pdb_code);

void vector3_product(double *vect_norm, double *vect1, double *vect2);

double distance3(double **coo_CA, int index1, int index2);

double scalar3_product(double *vect1, double *vect2);

void read_mat(int mat[36][36], char *fileName);

char residue_type(char *str1);

void string_tolower(char *s);

void init_ppf_arguments(ppf_args_t *args);

#endif /* util.h */
