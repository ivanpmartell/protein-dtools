/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#include "parse_PDB_file.h"
#include "util.h"

#define PI 3.14159
#define D0 1.56    /*distance CO--NH (1.3 A +20 %) */
#define D1 1.74    /*distance CA--NH (1.45A + 20%) */
#define D2 1.824   /*distance CA--NH (1.52A + 20%) */

/*******************************************************************************
 *
 ******************************************************************************/
double dihedral(pdb_t *pdb, int CAIndex, int NIndex, int CIndex, int auxindex);
void vector(pdb_t *pdb, int a, int b, double *vector);
char Residue_type(char *str1);
double norme(double *vector);

/*******************************************************************************
 *
 ******************************************************************************/
void compute_phi_psi(pdb_t *pdb, struct PHIPSI *PhiPsi)
{
  int nat, i, j, numres, Nchains;
  int CAIndex, CIndex, NIndex, CPrecIndex, NSuivIndex, OIndex;
  int seqIndex, nc;
  char prevChainID;
  char iCode;

  nat = pdb->nat;
  Nchains = pdb->Nchains;

/* initialisation of PhiPsi structure */
  for (i = 0; i < Nchains; i++) {
    numres = pdb->chain_nres[i];
    PhiPsi[i].nCA = numres;
    ALLOC(PhiPsi[i].index, numres);
    ALLOC(PhiPsi[i].Phi, numres);
    ALLOC(PhiPsi[i].Psi, numres);
    ALLOC(PhiPsi[i].Omega, numres);
    ALLOC(PhiPsi[i].chainID, numres);
    ALLOC(PhiPsi[i].resName, numres);
    ALLOC(PhiPsi[i].iCode, numres);
    for (j = 0; j < numres; j++) {
      PhiPsi[i].index[j] = pdb->SEQRESnumres[i][j];
      PhiPsi[i].Phi[j] = 999;
      PhiPsi[i].Psi[j] = 999;
      PhiPsi[i].Omega[j] = ' ';
      PhiPsi[i].chainID[j] = pdb->chainID[i];
      PhiPsi[i].resName[j] = pdb->seq[i][j];
      PhiPsi[i].iCode[j] = pdb->SEQRESiCode[i][j];
    }
  }

  prevChainID = pdb->chainID[0];
  nc = 0;
  seqIndex = 0;

  nc = 0;
  while (nc < pdb->Nchains - 1 && pdb->chainID[0] != pdb->chainNames[nc])
    nc++;

  for (i = 0; i < nat; i++) {
    if (prevChainID != pdb->chainID[i]) {
      prevChainID = pdb->chainID[i];
      seqIndex = 0;
      nc = 0;
      while (nc < pdb->Nchains - 1 && pdb->chainID[i] != pdb->chainNames[nc])
        nc++;
    }

    if (pdb->chainID[i] == pdb->chainNames[nc]) { /* valid chain */
      numres = *(pdb->numres + i); /*memorize which residue is treated */
      iCode = *(pdb->iCode + i);

      /*first look for a Calpha ; if the file contains alternate locations, be sure you are considering the good one */
      if (strcmp(pdb->atomname[i], " CA ") == 0
          && (pdb->altLoc[i] == ' '
            || pdb->altLoc[i] == pdb->selectedAltLoc[nc])) {
        CAIndex = i;

        /*Now that we have located a Calpha, look in wich line of the PhiPsi structure the angles are to be written */
        if (seqIndex == PhiPsi[nc].nCA - 1) {
          seqIndex = 0;
        }
        /*first reset the counter to zero if it's already equal to the number of residues */

        while ((pdb->SEQRESnumres[nc][seqIndex] != numres
            || pdb->SEQRESiCode[nc][seqIndex] != iCode)
            && seqIndex < PhiPsi[nc].nCA - 1) {
          seqIndex++;
        }
        /*then look for the right seqIndex, if not found, seqIndex is equal to  PhiPsi->nCA[nc] at the end of the loop */

        if (pdb->SEQRESnumres[nc][seqIndex] == numres &&
            pdb->SEQRESiCode[nc][seqIndex] == iCode) {
/*
 * we found seqIndex such as pdb->SEQRESnumres[nc][seqIndex] == numres
 * && pdb->SEQRESiCode[nc][seqIndex] == iCode
 */
          /*fprintf(stderr, " CA trouve \n"); *//*check that the NH exists */
          NIndex = CAIndex;
          while (NIndex >= 0
              && !(*(pdb->numres + NIndex) == numres
              && *(pdb->iCode + NIndex) == iCode
              && strcmp(pdb->atomname[NIndex], " N  ") == 0
              && (pdb->altLoc[NIndex] == pdb->selectedAltLoc[nc]
                || pdb->altLoc[NIndex] == ' '))) {
            NIndex--;
          }

          if (NIndex >= 0
              && *(pdb->numres + NIndex) == numres
              && *(pdb->iCode + NIndex) == iCode
              && strcmp(pdb->atomname[NIndex], " N  ") == 0
              && (pdb->altLoc[NIndex] == pdb->selectedAltLoc[nc]
                || pdb->altLoc[NIndex] == ' ')) {
            /*
             * If the  NH exists, check that the CO exists
             */
            CIndex = CAIndex;
            while (CIndex < nat
                && !(*(pdb->numres + CIndex) == numres
                && *(pdb->iCode + CIndex) == iCode
                && strcmp(pdb->atomname[CIndex], " C  ") == 0
                && (pdb->altLoc[CIndex] == pdb->selectedAltLoc[nc]
                  || pdb->altLoc[CIndex] == ' '))) {
              CIndex++;
            }

            if (CIndex < nat
                && *(pdb->numres + CIndex) == numres
                && *(pdb->iCode + CIndex) == iCode
                && strcmp(pdb->atomname[CIndex], " C  ") == 0
                && (pdb->altLoc[CIndex] == pdb->selectedAltLoc[nc]
                  || pdb->altLoc[CIndex] == ' ')) {
              /*
               * If NH and CO exist, check that there is the C
               * of a preceeding residue
               */
              CPrecIndex = CAIndex;
              while (CPrecIndex >= 0
                  && !(strcmp(pdb->atomname[CPrecIndex], " C  ") == 0
                  && (pdb->altLoc[CPrecIndex] == pdb->selectedAltLoc[nc]
                    || pdb->altLoc[CPrecIndex] == ' ')
                  && pdb->chainID[CPrecIndex] == pdb->chainID[CAIndex])) {
                CPrecIndex--;
              }

              if (CPrecIndex >= 0
                  && strcmp(pdb->atomname[CPrecIndex], " C  ") == 0
                  && (pdb->altLoc[CPrecIndex] == pdb->selectedAltLoc[nc]
                    || pdb->altLoc[CPrecIndex] == ' ')
                  && pdb->chainID[CPrecIndex] == pdb->chainID[CAIndex]
                  && distance3(pdb->coo, NIndex, CPrecIndex) < D0) {
/* verify (1) : that all atoms belong the same chain and 
          (2) : compute a  test on the distance between N-Cprec(to prevent from gaps in coordinates standard dist=1.33A) */
                PhiPsi[nc].Phi[seqIndex] = (double)
                    dihedral(pdb, CIndex, CAIndex, NIndex, CPrecIndex);

                OIndex = i;
                while (OIndex >= 0
                    && !(strcmp(pdb->atomname[OIndex], " O  ") == 0
                    && (pdb->altLoc[OIndex] == pdb->selectedAltLoc[nc]
                      || pdb->altLoc[OIndex] == ' ')))
                  OIndex--;

                if (OIndex >= 0
                    && strcmp(pdb->atomname[OIndex], " O  ") == 0
                    && (pdb->altLoc[OIndex] == pdb->selectedAltLoc[nc]
                      || pdb->altLoc[OIndex] == ' ')
                    && (dihedral(pdb, OIndex, CPrecIndex, NIndex,
                      CAIndex) > 90
                      || dihedral(pdb, OIndex, CPrecIndex, NIndex,
                      CAIndex) < -90))
                  PhiPsi[nc].Omega[seqIndex] = 'C';
              }
/*check that there is the N of the following residue */
              NSuivIndex = i;
              while (NSuivIndex < nat
                  && !(strcmp(pdb->atomname[NSuivIndex], " N  ") == 0
                  && (pdb->altLoc[NSuivIndex] == pdb->selectedAltLoc[nc]
                    || pdb->altLoc[NSuivIndex] == ' ')))
                NSuivIndex++;

              if (NSuivIndex < nat
                  && strcmp(pdb->atomname[NSuivIndex], " N  ") == 0
                  && (pdb->altLoc[NSuivIndex] == pdb->selectedAltLoc[nc]
                    || pdb->altLoc[NSuivIndex] == ' ')
                  && pdb->chainID[NSuivIndex] == pdb->chainID[CAIndex]
                  && distance3(pdb->coo, CIndex, NSuivIndex) < D0) {
                PhiPsi[nc].Psi[seqIndex] = (double)
                    dihedral(pdb, NIndex, CAIndex, CIndex, NSuivIndex);
              }
            } /* end of C found */
          } /* end of if NH found */
        } /* seqIndex */
      } /* CA search  if */
    } /* end of valid chain if */
  } /* end of for (i = 0; i < nat; i++) */
}

/*******************************************************************************
 *
 ******************************************************************************/
double dihedral(pdb_t *pdb, int index1, int index2, int index3, int index4)
{
  double vector1[3], vector2[3], vectorNorm1[3], vectorNorm2[3];
  double cosAngle, Angle, buf;

  vector(pdb, index1, index2, vector1);
  vector(pdb, index2, index3, vector2);

  vector3_product(vectorNorm1, vector1, vector2);

  vector(pdb, index2, index3, vector1);
  vector(pdb, index3, index4, vector2);

  vector3_product(vectorNorm2, vector1, vector2);

  cosAngle = scalar3_product(vectorNorm1, vectorNorm2)
      / (norme(vectorNorm1) * norme(vectorNorm2));

  /* prevent for machine error */
  Angle = (acos(cosAngle)) * 180 / PI;

  if (cosAngle <= -1) {
    Angle = 180;
  }
  if (cosAngle >= 1) {
    Angle = 0;
  }

  vector(pdb, index1, index2, vector1);

  buf = scalar3_product(vector1, vectorNorm2);
  if (buf < 0) {
    Angle = -1 * Angle;
  }
  return Angle;
}

/*******************************************************************************
 *
 ******************************************************************************/
void vector(pdb_t *pdb, int a, int b, double *vector)
{
  vector[0] = *(pdb->coo[b] + 0) - *(pdb->coo[a] + 0);
  vector[1] = *(pdb->coo[b] + 1) - *(pdb->coo[a] + 1);
  vector[2] = *(pdb->coo[b] + 2) - *(pdb->coo[a] + 2);
}

/*******************************************************************************
 *
 ******************************************************************************/
double norme(double *vector)
{
  return sqrt(vector[0] * vector[0] + vector[1] * vector[1]
      + vector[2] * vector[2]);
}
