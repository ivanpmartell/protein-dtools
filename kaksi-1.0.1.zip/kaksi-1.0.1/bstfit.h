/*
 * KAKSI is a protein secondary structure assignment program
 * Copyright (C) 2004-2005
 * Juliette MARTIN, Jean-Fran�ois GIBRAT, Antoine MARIN and
 * the INRA (Insitut National de la Recherche Agronomique).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * You can contact the main authors via mail or email at:
 * Juliette MARTIN or Jean-Fran�ois GIBRAT or Antoine MARIN
 * (first name (dot) last name (at) jouy (dot) inra (dot) fr)
 * Math�matique, Informatique & G�nome
 * INRA - Domaine de Vilvert
 * 78350 Jouy-en-Josas cedex
 * France
 */
#ifndef _BSTFIT_H
#define _BSTFIT_H 1

int bstftx_(int *n, double *co1, double *co2, int *iflag, int *ims,
    double *rms, double *r__, double *xc1, double *xc2, int *ierr);

int bstft0_(int *n, double *co2, double *a, double *r__, int *ierr);

double double_precision();

int svdd_(double *a, int *ka, int *m, int *n, int *isw, double *q, double *u,
    int *ku, double *v, int *kv, double *w, int *ind);

#endif /* bstfit.h */
